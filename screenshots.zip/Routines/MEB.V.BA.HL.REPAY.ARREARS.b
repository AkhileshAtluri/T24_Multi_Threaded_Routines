    SUBROUTINE MEB.V.BA.HL.REPAY.ARREARS
*-------------------------------------------------------------------------
* Developed By    : Capgemini India Pvt Ltd
* Program Name    : MEB.V.BA.HL.REPAY.ARREARS
* Purpose         : This routine triggers the loan repayment if the loan
*                   is in arrears while performing Interest adjustment
*-------------------------------------------------------------------------
* Subroutine Type : Version before auth routine
* Attached To     : VERSION>FUNDS.TRANSFER,MEB.AA.ACVQ
* Attached As     : Before Auth Routine
* In Parameter    : -NA-
* Out Parameter   : -NA- 
*-------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date:         Reference              Developed By    Change Description
* 20-Mar-19     SPT1-1972              Anand           Intitial Draft
* 01-Jul-19    R18 Upgrade          Prashen A         INCLUDE to INSERT
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.ACCOUNT
    $INSERT I_F.AA.ARRANGEMENT
    $INSERT I_F.EB.LOOKUP
*-------------------------------------------------------------------------
    GOSUB OPEN.FILES
    GOSUB PROCESS
    RETURN
*-------------------------------------------------------------------------
OPEN.FILES:
***********
    FN.EB.LOOKUP = 'F.EB.LOOKUP'
    F.EB.LOOKUP = ''
    CALL OPF(FN.EB.LOOKUP,F.EB.LOOKUP)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.AA.ARRANGEMENT = 'F.AA.ARRANGEMENT'
    F.AA.ARRANGEMENT = ''
    CALL OPF(FN.AA.ARRANGEMENT,F.AA.ARRANGEMENT)

    RETURN
*-------------------------------------------------------------------------
PROCESS:
********

    EB.LOOKUP.ID = 'MEB.HL.INT.ADJ*TXN.TYPE'
    R.EB.LOOKUP = ''
    EB.LOOKUP.ERR = ''
    CALL F.READ(FN.EB.LOOKUP,EB.LOOKUP.ID,R.EB.LOOKUP,F.EB.LOOKUP,EB.LOOKUP.ERR)

    TRANSACTION.TYPE = R.NEW(FT.TRANSACTION.TYPE)

    LOCATE TRANSACTION.TYPE IN R.EB.LOOKUP<EB.LU.DATA.VALUE,1> SETTING POS THEN
        ACCOUNT.ID = R.NEW(FT.CREDIT.ACCT.NO)
        R.ACCOUNT = ''
        ACCOUNT.ERR = ''
        CALL F.READ(FN.ACCOUNT,ACCOUNT.ID,R.ACCOUNT,F.ACCOUNT,ACCOUNT.ERR)

        AA.ARRANGEMENT.ID = R.ACCOUNT<AC.ARRANGEMENT.ID>
        R.AA.ARRANGEMENT = ''
        AA.ARRANGEMENT.ERR = ''
        CALL F.READ(FN.AA.ARRANGEMENT,AA.ARRANGEMENT.ID,R.AA.ARRANGEMENT,F.AA.ARRANGEMENT,AA.ARRANGEMENT.ERR)
        IF R.AA.ARRANGEMENT<AA.ARR.PRODUCT.GROUP> EQ 'HOME.LOAN' THEN
            BALANCE.TYPE = 'TOTALDUE'
            REQUEST.DATE = TODAY
            ARREARS.AMT = ''
            RETURN.ERR = ''
            CALL AA.GET.ECB.BALANCE.AMOUNT(ACCOUNT.ID,BALANCE.TYPE,REQUEST.DATE,ARREARS.AMT,RETURN.ERR)
            ARREARS.AMT = ABS(ARREARS.AMT)
            IF ARREARS.AMT THEN
                GOSUB POST.FT.OFS
            END
        END
    END
    RETURN
*-------------------------------------------------------------------------
POST.FT.OFS:
************
    INT.ADJ.AMT = R.NEW(FT.DEBIT.AMOUNT)
    IF ARREARS.AMT GE INT.ADJ.AMT THEN
        DEBIT.AMOUNT = INT.ADJ.AMT
    END ELSE
        DEBIT.AMOUNT = ARREARS.AMT
    END
    APP.NAME = 'FUNDS.TRANSFER'
    PROCESS = 'PROCESS'
    OFS.VERSION = 'FUNDS.TRANSFER,AA.ACLB'
    OFS.FUNCTION = 'I'
    GTS.MODE = ''
    NO.OF.AUTH = '0'
    TRANSACTION.ID = ''
    OFS.MESSAGE = ''
    R.APP.RECORD = ''
    R.APP.RECORD<FT.DEBIT.AMOUNT> = DEBIT.AMOUNT
    CALL OFS.BUILD.RECORD(APP.NAME,OFS.FUNCTION,PROCESS,OFS.VERSION,GTS.MODE,NO.OF.AUTH,TRANSACTION.ID,R.APP.RECORD,OFS.MESSAGE)
    OFS.ERROR = ''
    CALL ofs.addLocalRequest(OFS.MESSAGE,'ADD',OFS.ERROR)

    RETURN
END
*-------------------------------------------------------------------------
