* @ValidationCode : MjotMTY2ODIzODM1NTpDcDEyNTI6MTU1NDcxNjYzMDE5MTptZTgwMDU4OF90c3Q6LTE6LTE6MDowOmZhbHNlOk4vQTpSMThfU1AyLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 08 Apr 2019 19:43:50
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : me800588_tst
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R18_SP2.0
*-----------------------------------------------------------------------------
* <Rating>-20</Rating>
*-----------------------------------------------------------------------------
************************************************************************
* Generic Comments    : The purpose of this routine is to trigger the new FT by debiting from PL51500
*                       Account and crediting to Clearing account 9000000032 during merging of loans to
*                       reconcile GL entries and to pass the Customer details of loan to the DES.PYMT.DESC field.
*------------------------------------------------------------------------
* Company Name        : M E BANK.
* Developer Name      : Capgemini india Pvt. Ltd.
* ODR/JIRA Number     : SPT1-485
* Subroutine Type     : version Before Auth Routine
* Attached as         : Before Auth routine to VERSION > FUNDS.TRANSFER,MERG.ACPO
* Incoming Parameters : NA
* Outgoing Parameters : NA
* Development Date    : 15-FEB-2018
*-------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date:                    Reference                  Developed By:
* 15-Feb-2018              SPT1-485                   Deepti Kulkarni
*                         (BHL/FHL T24 to SUNGL mapping corrections - Split and Merge)
* UPGCHANGE - T Sidharth - 20190408 -replaced the MEB.COMMON.PARM to AUMB.COMMON.PARAM
*-------------------------------------------------------------------------
    SUBROUTINE MEB.V.BA.MERGE.ADJ.BAL
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.EB.LOOKUP
    $INSERT I_F.AUMB.COMMON.PARAM
    $INSERT I_F.ACCOUNT


    GOSUB INITIALISE
    GOSUB PROCESS

    RETURN

INITIALISE:

    FN.EB.LOOKUP = 'F.EB.LOOKUP'
    F.EB.LOOKUP = ''
    CALL OPF(FN.EB.LOOKUP,F.EB.LOOKUP)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.AUMB.COMMON.PARAM = 'F.AUMB.COMMON.PARAM'
    F.AUMB.COMMON.PARAM = ''
    CALL OPF(FN.AUMB.COMMON.PARAM,F.AUMB.COMMON.PARAM)

    R.EB.LOOKUP=''
    CALL F.READ(FN.EB.LOOKUP,"MERGE.ADJ*SETUP",R.EB.LOOKUP,F.EB.LOOKUP,E.EB.LOOKUP)
    EB.LOOKUP.DATA.LIST=R.EB.LOOKUP<EB.LU.DATA.NAME>
    LOCATE "MERGE.ACCOUNT.PL" IN EB.LOOKUP.DATA.LIST<1,1> SETTING SUSP.POS THEN
        DR.ACCOUNT=R.EB.LOOKUP<EB.LU.DATA.VALUE,SUSP.POS>
    END
    LOCATE "TRANSACTION.TYPE" IN EB.LOOKUP.DATA.LIST<1,1> SETTING TXN.POS THEN
        TXN.TYPE=R.EB.LOOKUP<EB.LU.DATA.VALUE,TXN.POS>
    END

    Y.APPLN = 'FUNDS.TRANSFER':FM:'ACCOUNT'
    Y.LOC.REF = 'DES.ACCT.BSB':VM:'DES.PYMT.DESC':FM:'LEGAL.ENTITY'
    Y.LOC.POS = ''
    Y.BSB.POS = ''
    Y.DESC.POS = ''
    Y.LEG.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APPLN,Y.LOC.REF,Y.LOC.POS)
    Y.BSB.POS = Y.LOC.POS<1,1>
    Y.DESC.POS = Y.LOC.POS<1,2>
    Y.LEG.POS = Y.LOC.POS<2,1>

    CR.ACCOUNT = R.NEW(FT.DEBIT.ACCT.NO)
    IF R.NEW(FT.CREDIT.AMOUNT) THEN
        TXN.AMOUNT = R.NEW(FT.CREDIT.AMOUNT)
    END ELSE
        TXN.AMOUNT = R.NEW(FT.DEBIT.AMOUNT)
    END

    RETURN

PROCESS:
*
    COMP.ID = ID.COMPANY
    R.AUMB.COMMON.PARAM = '' ; ERR = ''
    CALL CACHE.READ('F.AUMB.COMMON.PARAM',COMP.ID,R.AUMB.COMMON.PARAM,ERR)

    Y.CRD.ACC = R.NEW(FT.CREDIT.ACCT.NO)
    R.ACC = ''
    ACC.ERR = ''
    CALL F.READ(FN.ACCOUNT,Y.CRD.ACC,R.ACC,F.ACCOUNT,ACC.ERR)
    Y.PARTY.ID = R.ACC<AC.CUSTOMER>
    Y.CATGRY = R.ACC<AC.CATEGORY>
    Y.LEGAL.ENT = R.ACC<AC.LOCAL.REF,Y.LEG.POS>
    Y.CR.ALT.ID = R.ACC<AC.ALT.ACCT.ID,1>
* Y.DES.NAME.VAR = Y.CR.ALT.ID:"#":Y.PARTY.ID:"#":Y.LEGAL.ENT:"#":Y.CATGRY
    Y.DES.NAME.VAR = Y.CR.ALT.ID:"%|%":Y.PARTY.ID:"%|%":Y.LEGAL.ENT:"%|%":Y.CATGRY

    R.FT = ''
    R.FT<FT.TRANSACTION.TYPE> = TXN.TYPE
    R.FT<FT.DEBIT.ACCT.NO>    = DR.ACCOUNT
    R.FT<FT.CREDIT.ACCT.NO>   = CR.ACCOUNT
    R.FT<FT.DEBIT.AMOUNT>     = TXN.AMOUNT
    R.FT<FT.DEBIT.CURRENCY> = "AUD"
    R.FT<FT.CREDIT.CURRENCY> = "AUD"
    R.FT<FT.DEBIT.VALUE.DATE>=R.NEW(FT.DEBIT.VALUE.DATE)
    R.FT<FT.CREDIT.VALUE.DATE>=R.NEW(FT.CREDIT.VALUE.DATE)
    R.FT<FT.DEBIT.THEIR.REF> = "Merge":R.NEW(FT.CREDIT.ACCT.NO)
    R.FT<FT.ORDERING.BANK> = R.NEW(FT.ORDERING.BANK)
    R.FT<FT.PROFIT.CENTRE.DEPT> = R.NEW(FT.PROFIT.CENTRE.DEPT)
    R.FT<FT.LOCAL.REF,Y.BSB.POS> =R.AUMB.COMMON.PARAM<MCP.T24BSB.IDENTI.CODE>
    R.FT<FT.LOCAL.REF,Y.DESC.POS> = Y.DES.NAME.VAR


    COMP.ID = ID.COMPANY
    R.AUMB.COMMON.PARAM = '' ; ERR = ''
    CALL CACHE.READ('F.AUMB.COMMON.PARAM',COMP.ID,R.AUMB.COMMON.PARAM,ERR)


    Y.APP.NAME = 'FUNDS.TRANSFER'
    Y.APP.VERSION = 'FUNDS.TRANSFER,MEB.MERGE.AUTH'
    CALL OFS.BUILD.RECORD(Y.APP.NAME,'I','PROCESS',Y.APP.VERSION,'','0','',R.FT,OFSSTRING)


    OFS.ERROR= ''
    CALL ofs.addLocalRequest(OFSSTRING, 'ADD',  OFS.ERROR)
    IF OFS.ERROR NE '' THEN
        ETEXT = OFS.ERROR

    END



    RETURN
END








