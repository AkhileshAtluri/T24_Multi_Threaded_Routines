SUBROUTINE MEB.V.CR.ALLOW.PROSP.CUS
*-------------------------------------------------------------------------
* Developed By    : T Sidharth
* Purpose         : T24UP-184
*                   To enable Prospect customer processing through EB.FREE.MESSAGE without changing customer type prospect customer to active customer.
*------------------------------------------------------------------------
* Subroutine Type : Check Record Routine.
* Attached to     : EB.FREE.MESSAGE,DOC.RESEND
*		            EB.FREE.MESSAGE,DOC
*                   EB.FREE.MESSAGE,MEB.DOC
*                   EB.FREE.MESSAGE,OFS.MSG.ACT
* Attached as     : Check Record Routine
* In Parameter    : -NA-
* Out Parameter   : -NA-
*
*-------------------------------------------------------------------------
* Modification History :
*-----------------------
* UPGCHANGE - <developer> - <date> - <change description>
*------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.EB.FREE.MESSAGE
    COM/CRBLOCK/CR$BLOCKED.APP.LIST

    IF V$FUNCTION EQ 'I' THEN
       Y.EXI.BLOCKED.LIST = CR$BLOCKED.APP.LIST
    
       IF Y.EXI.BLOCKED.LIST THEN
          CR$BLOCKED.APP.LIST = Y.EXI.BLOCKED.LIST:FM:'EB.FREE.MESSAGE'
       END ELSE
          Y.NEW.LIST = 'CUSTOMER':FM:'PW.PROCESS':FM:'EB.FREE.MESSAGE'
          CR$BLOCKED.APP.LIST = Y.NEW.LIST
       END
    END
RETURN
*------------------------------------------------------------------------
END