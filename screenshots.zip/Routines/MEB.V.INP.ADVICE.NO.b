*-----------------------------------------------------------------------------
* <Rating>-35</Rating>
*-----------------------------------------------------------------------------
* Developed By    : Techmill Technologies Pvt. Ltd.
* Program Name    : MEB.V.INP.ADVICE.NO
* Purpose         : To Update User field and Values
*-------------------------------------------------------------------------
* Subroutine Type : S
* Attached To     : VERSION>EB.FREE.MESSAGE,DOC
* Attached As     : Input Routine
* In Parameter    : -NA-
* Out Parameter   : -NA-
*-------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date:         Reference                     Developed By:
* 05/09/2013    Added condition to check
*               whether USR.FLD has inputted
*               in DE.MESSAGE
*-------------------------------------------------------------------------
    SUBROUTINE MEB.V.INP.ADVICE.NO
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DE.MESSAGE
    $INSERT I_F.EB.ADVICES
    $INSERT I_F.EB.FREE.MESSAGE
    $INSERT I_GTS.COMMON
*-------------------------------------------------------------------------
    GOSUB INIT
    GOSUB PROCESS
*-------------------------------------------------------------------------
    RETURN
*-------------------------------------------------------------------------
INIT:
!
    FN.EB.ADVICES = 'F.EB.ADVICES'
    F.EB.ADVICES = ''
    CALL OPF(FN.EB.ADVICES,F.EB.ADVICES)
!
    FN.DE.MESSAGE = 'F.DE.MESSAGE'
    F.DE.MESSAGE = ''
    CALL OPF(FN.DE.MESSAGE,F.DE.MESSAGE)
!
    APPLN = 'EB.FREE.MESSAGE'
    FIELD.NAME = 'USER.FIELD':VM:'USER.VALUE'
    FIELD.POS = ''
    CALL MULTI.GET.LOC.REF(APPLN,FIELD.NAME,FIELD.POS)
    USR.FLD.POS = FIELD.POS<1,1>
    USR.VAL.POS = FIELD.POS<1,2>
!
    ADVICE.ID = R.NEW(EB.FM.EB.ADVICE.NO)
    CALL F.READ(FN.EB.ADVICES,ADVICE.ID,R.ADVICES,F.EB.ADVICES,ADV.ERR)
!
    DOC.ID = R.ADVICES<EB.ADV.MESSAGE.TYPE,1>
    CALL F.READ(FN.DE.MESSAGE,DOC.ID,R.DE.MESSAGE,F.DE.MESSAGE,MSG.ERR)
!
    USR.FLD.NAME = R.DE.MESSAGE<DE.MSG.USR.FIELD.NAME>
    USR.FLD.TYPE = R.DE.MESSAGE<DE.MSG.USR.PRINT.TYPE>
    USR.FLD.LEN  = R.DE.MESSAGE<DE.MSG.USR.LENGTH>
    USR.FLD.MAND = R.DE.MESSAGE<DE.MSG.USR.MANDATORY>
    CHANGE VM TO SM IN USR.FLD.NAME
    CHANGE VM TO SM IN USR.FLD.TYPE
    CHANGE VM TO SM IN USR.FLD.LEN
*-------------------------------------------------------------------------
    RETURN
*-------------------------------------------------------------------------
PROCESS:
!
    IF USR.FLD.NAME NE '' THEN
*Setting field names
        R.NEW(EB.FM.LOCAL.REF)<1,USR.FLD.POS> = USR.FLD.NAME
!
*Setting Input/Noinput fields
        T.LOCREF<USR.FLD.POS, 7> = "NOINPUT"
        T.LOCREF<USR.VAL.POS, 7> = ""
!
*Setting field character type
        T.LOCREF<USR.VAL.POS, 3> = USR.FLD.TYPE
!
*Setting field legnth and mandatory
        T.LOCREF<USR.VAL.POS, 2> = USR.FLD.LEN
!
        IF OFS$OPERATION NE 'VALIDATE' THEN
            Y.I = 1
            LOOP
!
                REMOVE FLD.MAND FROM USR.FLD.MAND SETTING MAND.POS
            WHILE FLD.MAND:MAND.POS
!
                GOSUB CALL.ERROR
!
                Y.I +=1
!
            REPEAT
        END
!
    END
!
    CALL REFRESH.FIELD(EB.FM.LOCAL.REF,'')
!
*-------------------------------------------------------------------------
    RETURN
*-------------------------------------------------------------------------
CALL.ERROR:
!
    IF FLD.MAND NE 'NO' AND R.NEW(EB.FM.LOCAL.REF)<1,USR.VAL.POS,Y.I> EQ '' THEN
        AF = EB.FM.LOCAL.REF
        AV = USR.VAL.POS
        AS = Y.I
        ETEXT = 'EB-INP.MISS'
        CALL STORE.END.ERROR
    END
*-------------------------------------------------------------------------
    RETURN
*-------------------------------------------------------------------------
END
*-------------------------------------------------------------------------


