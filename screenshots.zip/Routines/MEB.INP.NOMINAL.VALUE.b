*-------------------------------------------------------------------------
* <Rating>-24</Rating>
*-------------------------------------------------------------------------
    SUBROUTINE MEB.INP.NOMINAL.VALUE
*________________________________________________________________________

* Developed By    : Techmill Technologies Pvt. Ltd.
* Program Name    : MEB.FM.USER.VAR.MAP.R2
* Purpose         : To write user values into HANDOFF Record
*-------------------------------------------------------------------------
* Subroutine Type : S
* Attached To     : COLLATERAL,MEB.PROP
*                   COLLATERAL,MEB.OTH.PROP
* Attached As     : INPUT ROUTINE
* In Parameter    :
* Out Parameter   : -NA-
*-------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date:         Reference              Developed By:
*-------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.COLLATERAL

*    IF MESSAGE NE 'VAL' THEN
    Y.COL.CODE = R.NEW(COLL.COLLATERAL.TYPE)
*    IF ( Y.COL.CODE GE 1 AND Y.COL.CODE LE 100) OR ( Y.COL.CODE GE 201 AND Y.COL.CODE LE 201) THEN
        GOSUB INITIALISE
        GOSUB PROCESS
*    END
*    END

    RETURN

**********
INITIALISE:
**********
*
    Y.NOMINAL.VALUE = '0.0'
*
    APPL = 'COLLATERAL'
*    FLD.NAME = 'VAL.VALUE':VM:'MG.VALUE'
    FLD.NAME = 'CUR.VAL.VALUE':VM:'MG.VALUE'
    FLD.POS = ''
    CALL MULTI.GET.LOC.REF(APPL,FLD.NAME,FLD.POS)
*
    VAL.VALUE.POS = FLD.POS<1,1>
    MG.VALUE.POS  = FLD.POS<1,2>
*
    RETURN
*
********
PROCESS:
********
*
    Y.VAL = '' ; X.LIST = ''
*
    Y.VAL = R.NEW(COLL.LOCAL.REF)<1,VAL.VALUE.POS>
*
    X.LIST = R.NEW(COLL.LOCAL.REF)<1,MG.VALUE.POS>
*
    Y.MG.CNT = DCOUNT(X.LIST,SM)
    X.VAL = X.LIST<1,1,Y.MG.CNT>
*
    Y.NOMINAL.VALUE = (Y.VAL - X.VAL)

*    R.NEW(COLL.NOMINAL.VALUE) = Y.NOMINAL.VALUE
    COMI = Y.NOMINAL.VALUE
    RETURN
END


 
