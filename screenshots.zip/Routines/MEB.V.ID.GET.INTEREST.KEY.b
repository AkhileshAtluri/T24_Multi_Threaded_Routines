*-----------------------------------------------------------------------------
* <Rating>-20</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE MEB.V.ID.GET.INTEREST.KEY
*-------------------------------------------------------------------------------
* Generic Comments    : ID Routine attached in the BASIC.INTEREST,MEB.WS and PERIODIC.INTEREST,MEB.WS versions
* This routine is to get latest Interest record even if there are INAU records. Refer PACS PACS00850255
*---------------------------------------------------------------------------------
*-------------------------------------------------------------------------
* Modification History:-
*-------------------------------------------------------------------------
*Developed by :Krithika Muralidharan
*Date :29th June 2020
*------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.BASIC.INTEREST
    $INSERT I_F.BASIC.INTEREST.DATE
!

    GOSUB INIT

    IF V$FUNCTION EQ 'S' THEN
        GOSUB BASIC.PROCESS
    END


    RETURN
*--------------
INIT:
*--------------
!
    FN.BASIC.INTEREST = 'F.BASIC.INTEREST'
    F.BASIC.INTEREST = ''
    CALL OPF(FN.BASIC.INTEREST,F.BASIC.INTEREST)

    FN.BASIC.INTEREST.DATE = 'F.BASIC.INTEREST.DATE'
    F.BASIC.INTEREST.DATE = ''
    CALL OPF(FN.BASIC.INTEREST.DATE,F.BASIC.INTEREST.DATE)

    R.BASIC.INTEREST.DATE = ''
    R.BASIC.INTEREST = ''
    BASIC.INTEREST.DATE.ERR = ''

!
    RETURN
*========================================================================
BASIC.PROCESS:
*----------------

    Y.ID = COMI
    Y.ID.LENGTH = LEN(Y.ID)
    Y.ID.COPY = Y.ID[1,Y.ID.LENGTH -8]

    CALL F.READ(FN.BASIC.INTEREST,Y.ID,R.BASIC.INTEREST,F.BASIC.INTEREST,INT.ERR)
    IF R.BASIC.INTEREST EQ "" THEN
        CALL F.READ(FN.BASIC.INTEREST.DATE,Y.ID.COPY,R.BASIC.INTEREST.DATE,F.BASIC.INTEREST.DATE,BASIC.INTEREST.DATE.ERR)

        Y.DATE.REC = RIGHT(Y.ID,8)
        Y.TEMP.VAR =R.BASIC.INTEREST.DATE

        Y.POS = ''
        LOCATE Y.DATE.REC IN Y.TEMP.VAR<1> BY "DN" SETTING Y.POS THEN

            Y.ARRAY = Y.TEMP.VAR<Y.POS>
        END ELSE
            Y.ARRAY =Y.TEMP.VAR<Y.POS>
            COMI =Y.ID.COPY:Y.ARRAY
        END
    END
    RETURN
*=================================================================================

END



