* @ValidationCode : MjotOTc2NDQwMTI0OkNwMTI1MjoxNTU0NzE3Mzc2MTgxOm1lODAwNTg4X3RzdDotMTotMTowOjA6ZmFsc2U6Ti9BOlIxOF9TUDIuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 08 Apr 2019 19:56:16
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : me800588_tst
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R18_SP2.0
*R13-recompiled source 29/08/2013
*-----------------------------------------------------------------------------
* <Rating>-61</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE MEB.V.VAL.BENF.ACCT.DEF
*-------------------------------------------------------------------------
* Developed By    : Techmill Technologies
* Program Name    : MEB.V.VAL.ACTR.CRD.AC
* Purpose         :
*-------------------------------------------------------------------------
* Subroutine Type : S
* Attached To     : Version - FUNDS.TRANSFER,ACTR.ME
* Attached As     : Validation Routine
* In Parameter    : -NA-
* Out Parameter   : -NA- 
*-------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date:         Reference              Developed By:
*-------------------------------------------------------------------------
* 27-May-2013                        Raghunandan PD
* UPGCHANGE - T Sidharth - 20190408 -replaced the MEB.COMMON.PARM to AUMB.COMMON.PARAM
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.STANDING.ORDER
    $INSERT I_F.AUMB.COMMON.PARAM
!
    GOSUB INITIALISE
    GOSUB PROCESS
    RETURN
*-------------------------------------------------------------------------
INITIALISE:
*-------------------------------------------------------------------------
    FN.AUMB.COMMON.PARAM = 'F.AUMB.COMMON.PARAM'   ;   F.AUMB.COMMON.PARAM = ''
    CALL OPF(FN.AUMB.COMMON.PARAM,F.AUMB.COMMON.PARAM)
!
    FN.ACCOUNT = 'F.ACCOUNT'                     ;   F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)
!
    FN.ALTERNATE.ACCOUNT = 'F.ALTERNATE.ACCOUNT'
    F.ALTERNATE.ACCOUNT = ''
    CALL OPF(FN.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT)
!
    FN.ACCOUNT.HIS = 'F.ACCOUNT$HIS'
    F.ACCOUNT.HIS =''
    CALL OPF(FN.ACCOUNT.HIS,F.ACCOUNT.HIS)

    Y.FLAG = 0
    Y.DES.BSB = ''
!
    Y.APP='STANDING.ORDER'
    Y.FLD = 'DES.ACCT.MEB.NO':VM:'DES.ACCT.BSB':VM:'DES.ACCT.NO':VM:'DES.ACCT.NAME'
    Y.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP,Y.FLD,Y.POS)
    Y.DES.ACCT.MEB.NO = Y.POS<1,1>
    Y.DES.ACCT.BSB = Y.POS<1,2>
    Y.DES.ACCT.NO = Y.POS<1,3>
    Y.DES.ACCT.NAME=Y.POS<1,4>
    COMP.ID = ID.COMPANY
    RETURN
*-------------------------------------------------------------------------
PROCESS:
*-------------------------------------------------------------------------

    Y.DES.ACT.MEB.NO = R.NEW(STO.LOCAL.REF)<1,Y.DES.ACCT.MEB.NO>
!
    IF Y.DES.ACT.MEB.NO EQ '' THEN
        Y.DES.BSB = R.NEW(STO.LOCAL.REF)<1,Y.DES.ACCT.BSB>
!
        R.AUMB.COMMON.PARAM = ''
        CALL F.READ(FN.AUMB.COMMON.PARAM,COMP.ID,R.AUMB.COMMON.PARAM,F.AUMB.COMMON.PARAM,MEB.ERR)
        IF R.AUMB.COMMON.PARAM THEN
            Y.ACCT.ID=COMI
            GOSUB CHECK.ACCT
            IF Y.FLAG NE 1 THEN
                GOSUB DEFAULT.BENF.ACCT
            END
        END
    END
    RETURN
*-------------------------------------------------------------------------
DEFAULT.BENF.ACCT:
*-------------------------------------------------------------------------
    IF Y.DES.BSB EQ R.AUMB.COMMON.PARAM<MCP.T24BSB.IDENTI.CODE> THEN
        R.NEW(STO.CPTY.ACCT.NO) = Y.ACCT.ID
        R.NEW(STO.LOCAL.REF)<1,Y.DES.ACCT.NAME>=Y.NAME
        OFS$ENRI<STO.LOCAL.REF,Y.DES.ACCT.NO>=Y.NAME
    END ELSE
        LOCATE Y.DES.BSB IN R.AUMB.COMMON.PARAM<MCP.BSB.IDENTI.CODE,1> SETTING Y.POS1 THEN
            R.NEW(STO.CPTY.ACCT.NO) = R.AUMB.COMMON.PARAM<MCP.INTERN.SYS.ACCT,Y.POS1>
        END ELSE
            Y.FT.TYPE = R.NEW(STO.PAY.METHOD)
            LOCATE Y.FT.TYPE IN R.AUMB.COMMON.PARAM<MCP.TRANSACTION.TYP,1> SETTING Y.POS2 THEN
                R.NEW(STO.CPTY.ACCT.NO) = R.AUMB.COMMON.PARAM<MCP.CLEARING.AC,Y.POS2>
            END
        END
    END

    RETURN
*-------------------------------------------------------------------------
CHECK.ACCT:
*-------------------------------------------------------------------------
    R.ACCOUNT = ''
    CALL F.READ(FN.ACCOUNT,Y.ACCT.ID,R.ACCOUNT,F.ACCOUNT,ERROR.ACC)
    IF R.ACCOUNT EQ '' THEN
        GOSUB GET.ALT.ID
    END ELSE
        Y.ACC.NAME=R.ACCOUNT<AC.SHORT.TITLE>
        Y.NAME=Y.ACC.NAME[1,32]
        IF Y.DES.BSB EQ '' THEN
            Y.DES.BSB = R.AUMB.COMMON.PARAM<MCP.T24BSB.IDENTI.CODE>
            R.NEW(STO.LOCAL.REF)<1,Y.DES.ACCT.BSB> = Y.DES.BSB
        END
    END
    Y.T24.BSB = R.AUMB.COMMON.PARAM<MCP.T24BSB.IDENTI.CODE>
    IF (Y.DES.BSB EQ Y.T24.BSB AND R.ACCOUNT EQ '') THEN
        GOSUB ACCT.HISTORY
    END
    RETURN

**************
ACCT.HISTORY:
**************
    CALL EB.READ.HISTORY.REC(F.ACCOUNT.HIS,Y.ACCT.ID,R.ACCOUNT,Y.ACC.HIS.ERR)
    IF R.ACCOUNT THEN
        Y.FLAG=1
        ETEXT = "AC-ACCOUNT.CLOSED.STATUS"
        CALL STORE.END.ERROR
    END ELSE
        Y.FLAG=1
        ETEXT='EB-MEB.BSB.ACC.INVALID'
        CALL STORE.END.ERROR
    END
    RETURN

GET.ALT.ID:
**********
    ACCT.ERR = ''
    R.ACCOUNT = ''
    CALL F.READ(FN.ALTERNATE.ACCOUNT,Y.ACCT.ID,R.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT,ACCT.ERR)
    IF R.ALTERNATE.ACCOUNT THEN
        Y.ACCT.ID = R.ALTERNATE.ACCOUNT<1>
        GOSUB CHECK.ACCT
    END

    RETURN

END
*--------------------------------END OF ROUTINE-----------------------------------------





