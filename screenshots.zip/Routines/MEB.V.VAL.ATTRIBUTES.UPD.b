* @ValidationCode : MjotMjAxNDk2Mzg3OTpDcDEyNTI6MTU4Njg2NjY5NzYwMzptZTgwMTU4MV90c3Q6LTE6LTE6MDowOmZhbHNlOk4vQTpSMThfU1AxMy4wOi0xOi0x
* @ValidationInfo : Timestamp         : 14 Apr 2020 22:18:17
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : me801581_tst
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R18_SP13.0
*-----------------------------------------------------------------------------
* <Rating>-140</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE MEB.V.VAL.ATTRIBUTES.UPD
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------
*
* T24UP-5345 - Sweta - 20200414 - For a deceased customer when attrib name RelationshipSubCode is passed in th request
*                                 R.NEW was not updated with this value and hence was throwing error.
*T24UP-10895   Manavi	20201021	While updating the EB.RELATION.DETS record via OFS, null values are updating in the last multi value set
*				
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.EB.RELATION.DETS

    IF ID.OLD NE '' THEN
        Y.SYS.ATTR = R.NEW(EB.REL26.SYS.ATTR.NAME)
        Y.CUS.ATTR = R.NEW(EB.REL26.REL.ATTR.CUS)
        Y.ACC.ATTR = R.NEW(EB.REL26.REL.ATTR.ACC)
        Y.DATE.ATTR = R.NEW(EB.REL26.REL.ATTR.DATE)
        Y.REC.ATTR = R.NEW(EB.REL26.REL.ATTR.REC)
        Y.PROD.ATTR = R.NEW(EB.REL26.REL.ATTR.PROD)
        Y.OTH.ATTR = R.NEW(EB.REL26.REL.ATTR.OTH)


        GOSUB PROCESS.SYS
        GOSUB PROCESS.CUS
        GOSUB PROCESS.ACC
        GOSUB PROCESS.DATE
        GOSUB PROCESS.REC
        GOSUB PROCESS.PROD
        GOSUB PROCESS.OTH

    END
RETURN

PROCESS.SYS:
************

    IF Y.SYS.ATTR THEN
        Y.NEW.ATTR.ARRAY = ''
        Y.NEW.VAL.ARRAY = ''
        Y.OLD.SYS.ATTR = R.OLD(EB.REL26.SYS.ATTR.NAME)
        Y.NEW.SYS.ATTR = R.NEW(EB.REL26.SYS.ATTR.NAME)
        Y.OLD.SYS.CNT = DCOUNT(R.OLD(EB.REL26.SYS.ATTR.NAME),VM)
        Y.NEW.SYS.CNT = DCOUNT(R.NEW(EB.REL26.SYS.ATTR.NAME),VM)
        Y.I = 0
        LOOP
            Y.I += 1
        WHILE Y.I LE Y.OLD.SYS.CNT
            GOSUB PROCESS.SYS.VAL
        REPEAT

        R.NEW(EB.REL26.SYS.ATTR.NAME) = Y.NEW.ATTR.ARRAY
        R.NEW(EB.REL26.SYS.GEN.ATTR.VALUE) = Y.NEW.VAL.ARRAY
    END

RETURN

PROCESS.SYS.VAL:
****************
    Y.OLD.ATTR = R.OLD(EB.REL26.SYS.ATTR.NAME)<1,Y.I>
    Y.OLD.ATTR.VAL = R.OLD(EB.REL26.SYS.GEN.ATTR.VALUE)<1,Y.I>
    Y.NEW.VAL = Y.OLD.ATTR.VAL
    Y.K = 0
    LOOP
        Y.K += 1
    WHILE Y.K LE Y.NEW.SYS.CNT
        Y.NEW.ATTR = R.NEW(EB.REL26.SYS.ATTR.NAME)<1,Y.K>
        Y.NEW.ATTR.VAL = R.NEW(EB.REL26.SYS.GEN.ATTR.VALUE)<1,Y.K>
        IF Y.OLD.ATTR EQ Y.NEW.ATTR THEN
            IF Y.OLD.ATTR.VAL NE Y.NEW.ATTR.VAL THEN
                Y.NEW.VAL = Y.NEW.ATTR.VAL
            END
        END
    REPEAT
    Y.NEW.ATTR.ARRAY<1,Y.I> = R.OLD(EB.REL26.SYS.ATTR.NAME)<1,Y.I>
    Y.NEW.VAL.ARRAY<1,Y.I> = Y.NEW.VAL

RETURN

PROCESS.CUS:
************
    IF Y.CUS.ATTR THEN
        Y.NEW.ATTR.ARRAY = ''
        Y.NEW.VAL.ARRAY = ''
        Y.OLD.CUS.ATTR = R.OLD(EB.REL26.REL.ATTR.CUS)
        Y.NEW.CUS.ATTR = R.NEW(EB.REL26.REL.ATTR.CUS)
        Y.OLD.CUS.CNT = DCOUNT(R.OLD(EB.REL26.REL.ATTR.CUS),VM)
        Y.NEW.CUS.CNT = DCOUNT(R.NEW(EB.REL26.REL.ATTR.CUS),VM)
        Y.I = 0
        LOOP
            Y.I += 1
        WHILE Y.I LE Y.OLD.CUS.CNT
            GOSUB PROCESS.CUS.VAL
        REPEAT

        R.NEW(EB.REL26.REL.ATTR.CUS) = Y.NEW.ATTR.ARRAY
        R.NEW(EB.REL26.REL.ATTR.CUS.VAL) = Y.NEW.VAL.ARRAY
    END

RETURN

PROCESS.CUS.VAL:
****************
    Y.OLD.ATTR = R.OLD(EB.REL26.REL.ATTR.CUS)<1,Y.I>
    Y.OLD.ATTR.VAL = R.OLD(EB.REL26.REL.ATTR.CUS.VAL)<1,Y.I>
    Y.NEW.VAL = Y.OLD.ATTR.VAL
    Y.K = 0
    LOOP
        Y.K += 1
    WHILE Y.K LE Y.NEW.CUS.CNT
        Y.NEW.ATTR = R.NEW(EB.REL26.REL.ATTR.CUS)<1,Y.K>
        Y.NEW.ATTR.VAL = R.NEW(EB.REL26.REL.ATTR.CUS.VAL)<1,Y.K>
        IF Y.OLD.ATTR EQ Y.NEW.ATTR THEN
            IF Y.OLD.ATTR.VAL NE Y.NEW.ATTR.VAL THEN
                Y.NEW.VAL = Y.NEW.ATTR.VAL
            END
        END
    REPEAT
    Y.NEW.ATTR.ARRAY<1,Y.I> = R.OLD(EB.REL26.REL.ATTR.CUS)<1,Y.I>
    Y.NEW.VAL.ARRAY<1,Y.I> = Y.NEW.VAL

RETURN

PROCESS.ACC:
************
    IF Y.ACC.ATTR THEN
        Y.NEW.ATTR.ARRAY = ''
        Y.NEW.VAL.ARRAY = ''
        Y.OLD.ACC.ATTR = R.OLD(EB.REL26.REL.ATTR.ACC)
        Y.NEW.ACC.ATTR = R.NEW(EB.REL26.REL.ATTR.ACC)
        Y.OLD.ACC.CNT = DCOUNT(R.OLD(EB.REL26.REL.ATTR.ACC),VM)
        Y.NEW.ACC.CNT = DCOUNT(R.NEW(EB.REL26.REL.ATTR.ACC),VM)
        Y.I = 0
        LOOP
            Y.I += 1
        WHILE Y.I LE Y.OLD.ACC.CNT
            GOSUB PROCESS.ACC.VAL
        REPEAT

        R.NEW(EB.REL26.REL.ATTR.ACC) = Y.NEW.ATTR.ARRAY
        R.NEW(EB.REL26.REL.ATTR.ACC.VAL) = Y.NEW.VAL.ARRAY
    END

RETURN

PROCESS.ACC.VAL:
****************
    Y.OLD.ATTR = R.OLD(EB.REL26.REL.ATTR.ACC)<1,Y.I>
    Y.OLD.ATTR.VAL = R.OLD(EB.REL26.REL.ATTR.ACC.VAL)<1,Y.I>
    Y.NEW.VAL = Y.OLD.ATTR.VAL
    Y.K = 0
    LOOP
        Y.K += 1
    WHILE Y.K LE Y.NEW.ACC.CNT
        Y.NEW.ATTR = R.NEW(EB.REL26.REL.ATTR.ACC)<1,Y.K>
        Y.NEW.ATTR.VAL = R.NEW(EB.REL26.REL.ATTR.ACC.VAL)<1,Y.K>
        IF Y.OLD.ATTR EQ Y.NEW.ATTR THEN
            IF Y.OLD.ATTR.VAL NE Y.NEW.ATTR.VAL THEN
                Y.NEW.VAL = Y.NEW.ATTR.VAL
            END
        END
    REPEAT
    Y.NEW.ATTR.ARRAY<1,Y.I> = R.OLD(EB.REL26.REL.ATTR.ACC)<1,Y.I>
    Y.NEW.VAL.ARRAY<1,Y.I> = Y.NEW.VAL

RETURN

PROCESS.DATE:
*************
    IF Y.DATE.ATTR THEN
        Y.NEW.ATTR.ARRAY = ''
        Y.NEW.VAL.ARRAY = ''
        Y.OLD.DATE.ATTR = R.OLD(EB.REL26.REL.ATTR.DATE)
        Y.NEW.DATE.ATTR = R.NEW(EB.REL26.REL.ATTR.DATE)
        Y.OLD.DATE.CNT = DCOUNT(R.OLD(EB.REL26.REL.ATTR.DATE),VM)
        Y.NEW.DATE.CNT = DCOUNT(R.NEW(EB.REL26.REL.ATTR.DATE),VM)
        Y.I = 0
        LOOP
            Y.I += 1
        WHILE Y.I LE Y.OLD.DATE.CNT
            GOSUB PROCESS.DATE.VAL
        REPEAT

        R.NEW(EB.REL26.REL.ATTR.DATE) = Y.NEW.ATTR.ARRAY
        R.NEW(EB.REL26.REL.ATTR.DATE.VAL) = Y.NEW.VAL.ARRAY
    END

RETURN

PROCESS.DATE.VAL:
****************
    Y.OLD.ATTR = R.OLD(EB.REL26.REL.ATTR.DATE)<1,Y.I>
    Y.OLD.ATTR.VAL = R.OLD(EB.REL26.REL.ATTR.DATE.VAL)<1,Y.I>
    Y.NEW.VAL = Y.OLD.ATTR.VAL
    Y.K = 0
    LOOP
        Y.K += 1
    WHILE Y.K LE Y.NEW.DATE.CNT
        Y.NEW.ATTR = R.NEW(EB.REL26.REL.ATTR.DATE)<1,Y.K>
        Y.NEW.ATTR.VAL = R.NEW(EB.REL26.REL.ATTR.DATE.VAL)<1,Y.K>
        IF Y.OLD.ATTR EQ Y.NEW.ATTR THEN
            IF Y.OLD.ATTR.VAL NE Y.NEW.ATTR.VAL THEN
                Y.NEW.VAL = Y.NEW.ATTR.VAL
            END
        END
    REPEAT
    Y.NEW.ATTR.ARRAY<1,Y.I> = R.OLD(EB.REL26.REL.ATTR.DATE)<1,Y.I>
    Y.NEW.VAL.ARRAY<1,Y.I> = Y.NEW.VAL

RETURN

PROCESS.REC:
************
    IF Y.REC.ATTR THEN
        Y.NEW.ATTR.ARRAY = ''
        Y.NEW.VAL.ARRAY = ''
        Y.OLD.REC.ATTR = R.OLD(EB.REL26.REL.ATTR.REC)
        Y.NEW.REC.ATTR = R.NEW(EB.REL26.REL.ATTR.REC)
        Y.OLD.REC.CNT = DCOUNT(R.OLD(EB.REL26.REL.ATTR.REC),VM)
        Y.NEW.REC.CNT = DCOUNT(R.NEW(EB.REL26.REL.ATTR.REC),VM)
        Y.I = 0
        LOOP
            Y.I += 1
        WHILE Y.I LE Y.OLD.REC.CNT
            GOSUB PROCESS.REC.VAL
        REPEAT

        R.NEW(EB.REL26.REL.ATTR.REC) = Y.NEW.ATTR.ARRAY
        R.NEW(EB.REL26.REL.ATTR.REC.VAL) = Y.NEW.VAL.ARRAY
    END


RETURN

PROCESS.REC.VAL:
****************
    Y.OLD.ATTR = R.OLD(EB.REL26.REL.ATTR.REC)<1,Y.I>
    Y.OLD.ATTR.VAL = R.OLD(EB.REL26.REL.ATTR.REC.VAL)<1,Y.I>
    Y.NEW.VAL = Y.OLD.ATTR.VAL
    Y.K = 0
    LOOP
        Y.K += 1
    WHILE Y.K LE Y.NEW.REC.CNT
        Y.NEW.ATTR = R.NEW(EB.REL26.REL.ATTR.REC)<1,Y.K>
        Y.NEW.ATTR.VAL = R.NEW(EB.REL26.REL.ATTR.REC.VAL)<1,Y.K>
        IF Y.OLD.ATTR EQ Y.NEW.ATTR THEN
            IF Y.OLD.ATTR.VAL NE Y.NEW.ATTR.VAL THEN
                Y.NEW.VAL = Y.NEW.ATTR.VAL
            END
        END
    REPEAT
    Y.NEW.ATTR.ARRAY<1,Y.I> = R.OLD(EB.REL26.REL.ATTR.REC)<1,Y.I>
    Y.NEW.VAL.ARRAY<1,Y.I> = Y.NEW.VAL

RETURN

PROCESS.PROD:
*************
    IF Y.PROD.ATTR THEN
        Y.NEW.ATTR.ARRAY = ''
        Y.NEW.VAL.ARRAY = ''
        Y.OLD.PROD.ATTR = R.OLD(EB.REL26.REL.ATTR.PROD)
        Y.NEW.PROD.ATTR = R.NEW(EB.REL26.REL.ATTR.PROD)
        Y.OLD.PROD.CNT = DCOUNT(R.OLD(EB.REL26.REL.ATTR.PROD),VM)
        Y.NEW.PROD.CNT = DCOUNT(R.NEW(EB.REL26.REL.ATTR.PROD),VM)
        Y.I = 0
        LOOP
            Y.I += 1
        WHILE Y.I LE Y.OLD.PROD.CNT
            GOSUB PROCESS.PROD.VAL
        REPEAT

        R.NEW(EB.REL26.REL.ATTR.PROD) = Y.NEW.ATTR.ARRAY
        R.NEW(EB.REL26.REL.ATTR.PROD.VAL) = Y.NEW.VAL.ARRAY
    END


RETURN

PROCESS.PROD.VAL:
****************
    Y.OLD.ATTR = R.OLD(EB.REL26.REL.ATTR.PROD)<1,Y.I>
    Y.OLD.ATTR.VAL = R.OLD(EB.REL26.REL.ATTR.PROD.VAL)<1,Y.I>
    Y.NEW.VAL = Y.OLD.ATTR.VAL
    Y.K = 0
    LOOP
        Y.K += 1
    WHILE Y.K LE Y.NEW.PROD.CNT
        Y.NEW.ATTR = R.NEW(EB.REL26.REL.ATTR.PROD)<1,Y.K>
        Y.NEW.ATTR.VAL = R.NEW(EB.REL26.REL.ATTR.PROD.VAL)<1,Y.K>
        IF Y.OLD.ATTR EQ Y.NEW.ATTR THEN
            IF Y.OLD.ATTR.VAL NE Y.NEW.ATTR.VAL THEN
                Y.NEW.VAL = Y.NEW.ATTR.VAL
            END
        END
    REPEAT
    Y.NEW.ATTR.ARRAY<1,Y.I> = R.OLD(EB.REL26.REL.ATTR.PROD)<1,Y.I>
    Y.NEW.VAL.ARRAY<1,Y.I> = Y.NEW.VAL

RETURN

PROCESS.OTH:
************
    IF Y.OTH.ATTR THEN
        Y.NEW.ATTR.ARRAY = ''
        Y.NEW.VAL.ARRAY = ''
        Y.OLD.OTH.ATTR = R.OLD(EB.REL26.REL.ATTR.OTH)
        Y.NEW.OTH.ATTR = R.NEW(EB.REL26.REL.ATTR.OTH)
        Y.OLD.OTH.CNT = DCOUNT(R.OLD(EB.REL26.REL.ATTR.OTH),VM)
        Y.NEW.OTH.CNT = DCOUNT(R.NEW(EB.REL26.REL.ATTR.OTH),VM)
        Y.I = 0
        LOOP
            Y.I += 1
        WHILE Y.I LE Y.OLD.OTH.CNT
            GOSUB PROCESS.OTH.VAL
        REPEAT
    
*T24UP-5345
        GOSUB UPD.NEW.ATTRIB  ;* When new attibutes are input in the request should be updated in R.NEW
*T24UP-5345
       R.NEW(EB.REL26.REL.ATTR.OTH) = Y.NEW.ATTR.ARRAY
       R.NEW(EB.REL26.REL.ATTR.OTH.VAL) = Y.NEW.VAL.ARRAY
        
    END

RETURN

UPD.NEW.ATTRIB:
***************
    Y.NEW.OTH.ARR = ''
    Y.NEW.OTH.VAL.ARR = ''
    Y.J = 1
    LOOP
    WHILE Y.J LE Y.NEW.OTH.CNT
        Y.NEW.REL.OTH = R.NEW(EB.REL26.REL.ATTR.OTH)<1,Y.J>
        LOCATE Y.NEW.REL.OTH IN Y.OLD.OTH.ATTR<1,1> SETTING NEW.POS ELSE
            Y.NEW.OTH.ARR<1,-1> = Y.NEW.REL.OTH
            Y.NEW.OTH.VAL.ARR<1,-1> = R.NEW(EB.REL26.REL.ATTR.OTH.VAL)<1,Y.J>
        END
        Y.J +=1
    REPEAT
    IF Y.NEW.OTH.ARR OR Y.NEW.OTH.VAL.ARR THEN	;* T24UP-10895
       Y.NEW.ATTR.ARRAY<1,-1> = Y.NEW.OTH.ARR
       Y.NEW.VAL.ARRAY<1,-1> = Y.NEW.OTH.VAL.ARR
    END		;* T24UP-10895

RETURN
PROCESS.OTH.VAL:
****************
    Y.OLD.ATTR = R.OLD(EB.REL26.REL.ATTR.OTH)<1,Y.I>
    Y.OLD.ATTR.VAL = R.OLD(EB.REL26.REL.ATTR.OTH.VAL)<1,Y.I>
    Y.NEW.VAL = Y.OLD.ATTR.VAL
    Y.K = 0
    LOOP
        Y.K += 1
    WHILE Y.K LE Y.NEW.OTH.CNT
        Y.NEW.ATTR = R.NEW(EB.REL26.REL.ATTR.OTH)<1,Y.K>
        Y.NEW.ATTR.VAL = R.NEW(EB.REL26.REL.ATTR.OTH.VAL)<1,Y.K>
        IF Y.OLD.ATTR EQ Y.NEW.ATTR THEN
            IF Y.OLD.ATTR.VAL NE Y.NEW.ATTR.VAL THEN
                Y.NEW.VAL = Y.NEW.ATTR.VAL
            END
        END
    REPEAT
    Y.NEW.ATTR.ARRAY<1,Y.I> = R.OLD(EB.REL26.REL.ATTR.OTH)<1,Y.I>
    Y.NEW.VAL.ARRAY<1,Y.I> = Y.NEW.VAL

RETURN

END



