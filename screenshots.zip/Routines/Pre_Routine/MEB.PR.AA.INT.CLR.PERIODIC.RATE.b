*-----------------------------------------------------------------------------
* <Rating>-23</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE MEB.PR.AA.INT.CLR.PERIODIC.RATE
*-----------------------------------------------------------------------------
* Developed By : Capgemini pvt ltd
* Purpose      : Routine to remove the PERIODIC RATE if the loan has started using the FLOATING or FIXED RATE
* Date         : 09 APR 2018
* Attached to  : ACTIVITY.API condition for LENDING
* Attached as  : Pre-Validation Routine in activity api listed under INTEREST MAINTAIN condition
*--------------------------------------------------------------------------------------------
* Modification History
*------------------------------------------------------------------------------------------------
* Modified By :
*---------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_AA.APP.COMMON
    $INSERT I_AA.LOCAL.COMMON
    $INSERT I_F.AA.ACTIVITY.HISTORY
    $INSERT I_AA.ACTION.CONTEXT
    $INSERT I_F.AA.ARRANGEMENT.ACTIVITY
    $INSERT I_F.AA.INTEREST


    IF c_arrActivityStatus EQ 'AUTH-REV' OR c_arrActivityStatus EQ 'REVERSE' THEN
        RETURN
    END
    GOSUB INITIALISE
    GOSUB PROCESS

    RETURN
*-----------------------------------------------------------------------------
INITIALISE:
*-----------------------------------------------------------------------------
    ARR.ACTIVITY.ID = c_arrActivityId   ;* Arrangement Activity Id
    R.ACTIVITY = c_arrActivityRec       ;* Arrangement Activity record.
    REPLAY.MODE = ''

    CURR.ACTIVITY  = c_aalocActivityId
    ARRANGEMENT.ID = c_aalocArrId
    AA.ARR.ACT.ID  = c_aalocArrActivityId
    EFFECTIVE.DATE = c_aalocActivityEffDate

    INT.FIXED.RATE = ''
    INT.FLOATING.INDEX = '' ; INT.PERIODIC.RATE = ''
    OTH.INT.RATE.FLAG = ''

    RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-----------------------------------------------------------------------------
    INT.FIXED.RATE = R.NEW(AA.INT.FIXED.RATE)
    INT.FLOATING.INDEX = R.NEW(AA.INT.FLOATING.INDEX)
    INT.PERIODIC.RATE = R.NEW(AA.INT.PERIODIC.RATE)
    INT.PERIODIC.INDEX = R.NEW(AA.INT.PERIODIC.INDEX)

    IF INT.PERIODIC.RATE THEN ;*** if PERIODIC RATE exists ; Felcia
        GOSUB CHECK.OTH.INT.RATES
        IF OTH.INT.RATE.FLAG THEN       ;*** if either FIXED or FLOATING RATE exists
            R.NEW(AA.INT.PERIODIC.RATE) = ''      ;*** blank out so that the patch AA_Interest_87 doesn't raise er
            R.NEW(AA.INT.PERIODIC.INDEX) = ''
            R.NEW(AA.INT.PERIODIC.PERIOD) = ''
            R.NEW(AA.INT.PERIODIC.METHOD) = ''
        END
    END

    RETURN
*-------------------------------------------------------------------------------------------
CHECK.OTH.INT.RATES:
*-------------------------------------------------------------------------------------------
    OTH.INT.RATE.FLAG = ''

    BEGIN CASE

    CASE INT.FLOATING.INDEX
        OTH.INT.RATE.FLAG = 1
    CASE INT.FIXED.RATE
        OTH.INT.RATE.FLAG = 1
    END CASE

    RETURN
END


