*R13-recompiled source 29/08/2013
*-------------------------------------------------------------------------
* <Rating>0</Rating>
*-------------------------------------------------------------------------
    SUBROUTINE MEB.V.CR.CONTACT.LOG.MKG
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.CR.CONTACT.LOG

    FN.CR.CONTACT.LOG = "F.CR.CONTACT.LOG"
    F.CR.CONTACT.LOG = ''

    CALL OPF(FN.CR.CONTACT.LOG,F.CR.CONTACT.LOG)

    Y.POS = ''

    CALL MULTI.GET.LOC.REF("CR.CONTACT.LOG","MKG.SOURCE",Y.POS)

    IF R.NEW(CR.CONT.LOG.LOCAL.REF)<1,Y.POS> = '' THEN

        AF = CR.CONT.LOG.LOCAL.REF
        AV = Y.POS

         ETEXT = "EB-MAND.INP"
         CALL STORE.END.ERROR
     END
     RETURN
 END
