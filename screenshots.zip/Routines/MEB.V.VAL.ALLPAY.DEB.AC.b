*-----------------------------------------------------------------------------
* <Rating>-50</Rating>
*------------------------------------------------------------------------------
    SUBROUTINE MEB.V.VAL.ALLPAY.DEB.AC
*------------------------------------------------------------------------------
* Developed By    : Techmill Technologies
* Program Name    : MEB.V.VAL.ACTR.DEB.AC
* Purpose         : This routine is to default the DEebit Account Number.
*-----------------------------------------------------------------------------
* Subroutine Type : S
* Attached To     : Version - FUNDS.TRANSFER,MEB.ALL.PAYMENTS
* Attached As     : Validation Routine.
* In Parameter    : -NA-
* Out Parameter   : -NA-
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date:         Reference              Developed By:
*-----------------------------------------------------------------------------
* 27-May-2013                        vijaykumar.ks@techmilltechnologies.com
*
* 13-Jul-2016   Changed for issue    rathan.r@techmilltechnologies.com
*               2313
*
* UPGCHANGE - Sweta - 20190402 - Replaced MEB.COMMON.PARAM to AUMB.COMMON.PARAM
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.ACCOUNT
    * ..\T24_BP
    $INSERT I_F.CATEGORY
    $INSERT I_F.AUMB.COMMON.PARAM

    GOSUB INITIALISE
    GOSUB PROCESS

    RETURN
*-----------------------------------------------------------------------------
INITIALISE:
*-----------------------------------------------------------------------------
    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT, F.ACCOUNT)

    FN.ALTERNATE.ACCOUNT = 'F.ALTERNATE.ACCOUNT'
    F.ALTERNATE.ACCOUNT = ''
    CALL OPF(FN.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT)

    FN.CATEGORY = 'F.CATEGORY'
    F.CATEGORY = ''
    CALL OPF(FN.CATEGORY,F.CATEGORY)

    Y.FLAG=0

    COMP.ID = ID.COMPANY
    Y.APP = 'FUNDS.TRANSFER'
    Y.FIELD = 'SRC.ACCT.BSB':VM:'SRC.ACCT.NO':VM:'SRC.ACCT.MEB.NO':VM:'SRC.ACCT.NAME':VM:'INSTR.MEBPID'
    Y.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP,Y.FIELD,Y.POS)
    Y.SRC.ACCT.BSB = Y.POS<1,1>
    Y.SRC.ACCT.NO = Y.POS<1,2>
    Y.SRC.ACCT.MEB.NO = Y.POS<1,3>
    Y.SRC.ACCT.NAME=Y.POS<1,4>
    Y.INSTR.MEBPID.POS = Y.POS<1,5>

    RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-----------------------------------------------------------------------------
*
    Y.SRC.ACT.MEB.NO = R.NEW(FT.LOCAL.REF)<1,Y.SRC.ACCT.MEB.NO>
    IF Y.SRC.ACT.MEB.NO EQ '' THEN
        Y.FT.TYPE = R.NEW(FT.TRANSACTION.TYPE)
        Y.SRC.BSB = R.NEW(FT.LOCAL.REF)<1,Y.SRC.ACCT.BSB>
        R.AUMB.COMMON.PARAM = '' ; ERR = ''
        CALL CACHE.READ('F.AUMB.COMMON.PARAM',COMP.ID,R.AUMB.COMMON.PARAM,ERR)
        IF R.AUMB.COMMON.PARAM THEN
            Y.T24.BSB = R.AUMB.COMMON.PARAM<MCP.T24BSB.IDENTI.CODE>
            IF Y.SRC.BSB EQ '' THEN
                Y.SRC.BSB = Y.T24.BSB
                R.NEW(FT.LOCAL.REF)<1,Y.SRC.ACCT.BSB> = Y.T24.BSB
            END
            Y.ACCT.ID=COMI
            IF Y.ACCT.ID EQ '' THEN
                Y.ACCT.ID = R.NEW(FT.LOCAL.REF)<1,Y.SRC.ACCT.NO>
            END
*            IF Y.ACCT.ID EQ '' THEN
*                Y.ACCT.ID = System.getVariable("CURRENT.CR.ACCOUNT")
*            END
            IF COMI[1,2] EQ 'PL' THEN
                GOSUB PL.PROCESS
            END ELSE
                GOSUB CHECK.ACCT


                IF Y.FLAG NE 1 THEN
                    GOSUB DEFAULT.DEBIT.ACCT
                END
            END
        END
    END

    RETURN
*-----------------------------------------------------------------------------
DEFAULT.DEBIT.ACCT:
*-----------------------------------------------------------------------------
    IF Y.SRC.BSB EQ R.AUMB.COMMON.PARAM<MCP.T24BSB.IDENTI.CODE> THEN
        R.NEW(FT.DEBIT.ACCT.NO) =  Y.ACCT.ID
        R.NEW(FT.LOCAL.REF)<1,Y.SRC.ACCT.NAME> = Y.NAME
        OFS$ENRI<FT.LOCAL.REF,Y.SRC.ACCT.NO> = Y.NAME
    END ELSE
        LOCATE Y.SRC.BSB IN R.AUMB.COMMON.PARAM<MCP.BSB.IDENTI.CODE,1> SETTING Y.POS1 THEN
            R.NEW(FT.DEBIT.ACCT.NO) = R.AUMB.COMMON.PARAM<MCP.INTERN.SYS.ACCT,Y.POS1>
        END ELSE
            LOCATE Y.FT.TYPE IN R.AUMB.COMMON.PARAM<MCP.TRANSACTION.TYP,1> SETTING Y.POS2 THEN
                R.NEW(FT.DEBIT.ACCT.NO) = R.AUMB.COMMON.PARAM<MCP.CLEARING.AC,Y.POS2>
            END
        END
    END

    RETURN
*-----------------------------------------------------------------------------
*Added below gosub for Issue 2313
PL.PROCESS:
*-----------------------------------------------------------------------------
!

    R.CATEGORY = '' ; CATEG.ERR = ''  ; CATEG.ID = COMI[3,-1]
    CALL F.READ(FN.CATEGORY, CATEG.ID, R.CATEGORY, F.CATEGORY, CATEG.ERR)
!
    IF R.CATEGORY THEN

        R.NEW(FT.LOCAL.REF)<1,Y.SRC.ACCT.NAME>   = R.CATEGORY<EB.CAT.DESCRIPTION>
        OFS$ENRI<FT.LOCAL.REF,Y.SRC.ACCT.NO> = R.CATEGORY<EB.CAT.DESCRIPTION>
        R.NEW(FT.DEBIT.ACCT.NO) = Y.ACCT.ID
    END ELSE
        Y.FLAG = 1
        ETEXT = 'FT-INVALID.CAT.CODE'
        CALL STORE.END.ERROR
    END
!
    RETURN

*-----------------------------------------------------------------------------
CHECK.ACCT:
*-----------------------------------------------------------------------------
    R.ACCOUNT = '' ; ERR.ACC = ''
    CALL F.READ(FN.ACCOUNT,Y.ACCT.ID,R.ACCOUNT,F.ACCOUNT,ERR.ACC)
    IF R.ACCOUNT EQ '' THEN
        GOSUB GET.ALT.ID
    END

    IF R.ACCOUNT THEN
        Y.ACC.NAME = R.ACCOUNT<AC.SHORT.TITLE>
        Y.NAME = Y.ACC.NAME[1,32]
    END

    IF (Y.SRC.BSB EQ Y.T24.BSB) AND (R.ACCOUNT EQ '') THEN
        Y.FLAG = 1
        ETEXT = 'EB-MEB.BSB.ACC.INVALID'
        CALL STORE.END.ERROR
    END

    RETURN

GET.ALT.ID:
**********
    R.ALTERNATE.ACCOUNT = '' ; ACCT.ERR = ''
    CALL F.READ(FN.ALTERNATE.ACCOUNT,Y.ACCT.ID,R.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT,ACCT.ERR)
    IF R.ALTERNATE.ACCOUNT THEN
        Y.ACCT.ID = R.ALTERNATE.ACCOUNT<1>
        R.ACCOUNT = '' ; ERR.ACC = ''
        CALL F.READ(FN.ACCOUNT,Y.ACCT.ID,R.ACCOUNT,F.ACCOUNT,ERR.ACC)
    END

    RETURN
*-----------------------------------------------------------------------------
END







