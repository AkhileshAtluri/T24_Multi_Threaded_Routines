*-------------------------------------------------------------------------
* <Rating>-21</Rating>
*-------------------------------------------------------------------------
    SUBROUTINE MEB.V.VAL.BANK.CHQ.AC.FLD.CHK
*-------------------------------------------------------------------------
* Developed By    : Techmill Technologies
* Program Name    : MEB.V.VAL.BANK.CHQ.AC.FLD.CHK
* Purpose         :
*--------------------------------------------------------------------------
* Subroutine Type : S
* Attached To     : Version - CR.CONTACT.LOG,MEB.BANK.CHQ
* Attached As     : INPUT Routine
* Dependency      : EB.MAPPING.SOURCE
* Description     : API to check the value of the of the field CONTACT.TYPE and make the account field as mandatory when the contact type = BANK.CHQ.CUSTOMER
* In Parameter    : -NA-
* Out Parameter   : -NA-
*-------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date:         Reference              Developed By:
*-------------------------------------------------------------------------
**
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_System
    $INSERT I_F.ACCOUNT
    $INSERT I_F.CR.CONTACT.LOG
    $INSERT I_F.MEB.BANK.CHQ.PARAMETER

    GOSUB INITIALISE
    GOSUB PROCESS
*
    RETURN
*-------------------------------------------------------------------------
INITIALISE:
*-------------------------------------------------------------------------

    Y.APP='CR.CONTACT.LOG'
    Y.FIELD='ACCOUNT'
    Y.POS=''

    CALL MULTI.GET.LOC.REF(Y.APP,Y.FIELD,Y.POS)
    Y.ACCOUNT.POS = Y.POS<1,1>

    FN.CR.CONTACT.LOG = 'F.CR.CONTACT.LOG'
    F.CR.CONTACT.LOG = ''
    CALL OPF(FN.CR.CONTACT.LOG,F.CR.CONTACT.LOG)

    FN.MEB.BANK.CHQ.PARAM = 'F.MEB.BANK.CHQ.PARAMETER'
    F.MEB.BANK.CHQ.PARAM = ''
    CALL OPF(FN.MEB.BANK.CHQ.PARAM,F.MEB.BANK.CHQ.PARAM)
    CHQ.SYS.ID = ID.COMPANY:'-SYSTEM'
    CALL F.READ(FN.MEB.BANK.CHQ.PARAM,CHQ.SYS.ID,R.CHQ.SYS.PARAM,F.MEB.BANK.CHQ.PARAM,CHQ.ERR)


    RETURN
*-------------------------------------------------------------------------
PROCESS:
*-------------------------------------------------------------------------


*    CALL F.READ(FN.CR.CONTACT.LOG,Y.CR.ID,R.CR.REC,F.CR.CONTACT.LOG,CR.ERR)57

    Y.CR.CONT.TYPE = R.NEW(CR.CONT.LOG.CONTACT.TYPE)

    IF Y.CR.CONT.TYPE EQ R.CHQ.SYS.PARAM<MEB.BCP.BCHQ.CUS.TYPE> THEN
        Y.TEMP = R.NEW(CR.CONT.LOG.LOCAL.REF)<1,Y.ACCOUNT.POS>
        IF  Y.TEMP EQ '' THEN
            AF = CR.CONT.LOG.LOCAL.REF
            AV =Y.ACCOUNT.POS
            ETEXT = 'EB-MEB.AC.FLD.MANDATORY'
            CALL STORE.END.ERROR
        END
    END

    RETURN

END

 
