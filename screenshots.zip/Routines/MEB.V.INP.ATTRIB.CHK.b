*-----------------------------------------------------------------------------
* <Rating>769</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE MEB.V.INP.ATTRIB.CHK
*-------------------------------------------------------------------------
* Modification History:
*
* UPGCHANGE - Sweta - 20190311 - Corrected the code to read RELATION.TYPE from R.NEW
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.EB.RELATIONSHIP.DEF
    $INSERT I_F.EB.RELATION.DETS

    FN.EbRelationDefn = 'F.EB.RELATIONSHIP.DEF'
    F.EbRelationDefn  = ''
    CALL OPF(FN.EbRelationDefn, F.EbRelationDefn)
!*
* (Start-UPGCHANGE-20190311)
    RelDefnID = R.NEW(EB.REL26.RELATION.TYPE)
*RelDefnID = R.NEW(EB.REL92.REL.NAME)	
* (End-UPGCHANGE-20190311)

    CALL F.READ(FN.EbRelationDefn, RelDefnID, R.RelationDefn, F.EbRelationDefn, DefnReadErr)

    AttributeFldNames  = EB.REL26.SYS.ATTR.NAME : FM : EB.REL26.REL.ATTR.CUS : FM : EB.REL26.REL.ATTR.ACC  : FM
    AttributeFldNames := EB.REL26.REL.ATTR.DATE : FM : EB.REL26.REL.ATTR.REC : FM : EB.REL26.REL.ATTR.PROD : FM
    AttributeFldNames := EB.REL26.REL.ATTR.OTH

    LOOP
        REMOVE AttributeFld FROM AttributeFldNames SETTING FldPos
    WHILE AttributeFld NE ''

        IF R.NEW(AttributeFld) NE '' THEN
            FldCount = DCOUNT(R.NEW(AttributeFld), VM)
            Counter = 1
            LOOP
            WHILE R.NEW(AttributeFld)<1,Counter> NE ''
                AF = AttributeFld
                AV = Counter
                LOCATE R.NEW(AttributeFld)<1,Counter> IN R.RelationDefn<EB.REL92.ATTR.NAME,1> SETTING AttribPos THEN
                    BEGIN CASE
                    CASE AttributeFld EQ EB.REL26.SYS.ATTR.NAME
                        IF R.RelationDefn<EB.REL92.ATTR.SYS.USER,AttribPos> EQ 'SYSTEM' ELSE
                            ETEXT = 'EB-ATTRIB.NOT.SYS.TYPE'
                            CALL STORE.END.ERROR
                        END
                    CASE AttributeFld EQ EB.REL26.REL.ATTR.CUS
                        IF R.RelationDefn<EB.REL92.ATTR.SYS.USER,AttribPos> EQ 'CUSTOMER' ELSE
                            ETEXT = 'EB-ATTRIB.NOT.CUS.TYPE'
                            CALL STORE.END.ERROR
                        END
                    CASE AttributeFld EQ EB.REL26.REL.ATTR.ACC
                        IF R.RelationDefn<EB.REL92.ATTR.SYS.USER,AttribPos> EQ 'ACCOUNT' ELSE
                            ETEXT = 'EB-ATTRIB.NOT.ACC.TYPE'
                            CALL STORE.END.ERROR
                        END
                    CASE AttributeFld EQ EB.REL26.REL.ATTR.DATE
                        IF R.RelationDefn<EB.REL92.ATTR.SYS.USER,AttribPos> EQ 'DATE' ELSE
                            ETEXT = 'EB-ATTRIB.NOT.DATE.TYPE'
                            CALL STORE.END.ERROR
                        END
                    CASE AttributeFld EQ EB.REL26.REL.ATTR.REC
                        IF R.RelationDefn<EB.REL92.ATTR.SYS.USER,AttribPos> EQ 'RECURRENCE' ELSE
                            ETEXT = 'EB-ATTRIB.NOT.REC.TYPE'
                            CALL STORE.END.ERROR
                        END
                    CASE AttributeFld EQ EB.REL26.REL.ATTR.PROD
                        IF R.RelationDefn<EB.REL92.ATTR.SYS.USER,AttribPos> EQ 'PRODUCT' ELSE
                            ETEXT = 'EB-ATTRIB.NOT.PROD.TYPE'
                            CALL STORE.END.ERROR
                        END
                    CASE AttributeFld EQ EB.REL26.REL.ATTR.OTH
                        IF R.RelationDefn<EB.REL92.ATTR.SYS.USER,AttribPos> EQ 'OTHER' ELSE
                            ETEXT = 'EB-ATTRIB.NOT.OTH.TYPE'
                            CALL STORE.END.ERROR
                        END
                    END CASE

                END ELSE
                    ETEXT = 'EB-ATTRIB.NOT.FOUND'
                    CALL STORE.END.ERROR
                END
                Counter +=1
            REPEAT
        END

    REPEAT

    RETURN
END

