* @ValidationCode : MjotMTMyNjg2OTIyMjpDcDEyNTI6MTU1NDI2NzAyNzg3NzptZTgwMDU4OF90c3Q6LTE6LTE6MDowOmZhbHNlOk4vQTpSMThfU1AyLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 03 Apr 2019 15:50:27
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : me800588_tst
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R18_SP2.0
*R13-recompiled source 29/08/2013
*-----------------------------------------------------------------------------
* <Rating>-53</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE MEB.V.VAL.ACTR.SRC.AC
*-----------------------------------------------------------------------------
* Developed By    : Techmill Technologies.
* Program Name    : MEB.V.VAL.ACTR.SRC.AC
* Purpose         : When Source MEB account is selected , routine will default
*                   SRC.ACCT.BSB,SRC.ACCT.NO,SRC.ACCT.NAME
*-------------------------------------------------------------------------
* Subroutine Type : S
* Attached To     : Version - FUNDS.TRANSFER,ACTR.ME
* Attached As     : Validation Routine
* In Parameter    : -NA-
* Out Parameter   : -NA-
*-------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date:         Reference              Developed By:
*-------------------------------------------------------------------------
* 27-May-2013                           vijaykumar.ks@techmilltechnologies.com
* 29-Mar-2019 - UPGCHANGE             - T Sidharth  -  replaced the MEB.COMMON.PARAM to AUMB.COMMON.PARAM
* 23-Jul-2021 - T24UP-13121           - Sweta       -   Error when SRC.ACCT.MEB.NO is chosen from enquiry  
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_GTS.COMMON
    $INSERT I_F.AUMB.COMMON.PARAM
    $INSERT I_F.CUSTOMER
    $INSERT I_F.ACCOUNT

    IF OFS$OPERATION EQ "BUILD" THEN
        GOSUB INITIALISE
        GOSUB PROCESS
        GOSUB PROCESS.NEXT
    END

RETURN
*-----------------------------------------------------------------------------
INITIALISE:
*-----------------------------------------------------------------------------
    COMP.ID = ID.COMPANY
    Y.FLAG = 0

    Y.APP = "FUNDS.TRANSFER"
    Y.FIELDS = "SRC.ACCT.MEB.NO":VM:"SRC.ACCT.NO":VM:"SRC.ACCT.BSB":VM:"SRC.ACCT.NAME"
    Y.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP,Y.FIELDS,Y.POS)
    Y.MEB.NO.POS = Y.POS<1,1>
    Y.SRC.ACCT.NO.POS = Y.POS<1,2>
    Y.SRC.ACCT.BSB.POS = Y.POS<1,3>
    Y.SRC.ACCT.NAME.POS = Y.POS<1,4>

    FN.AUMB.COMMON.PARAM = 'F.AUMB.COMMON.PARAM'
    F.AUMB.COMMON.PARAM = ''
    CALL OPF(FN.AUMB.COMMON.PARAM,F.AUMB.COMMON.PARAM)

*T24UP-13121(S)	
	FN.ALTERNATE.ACCOUNT = 'F.ALTERNATE.ACCOUNT'
    F.ALTERNATE.ACCOUNT = ''
    CALL OPF(FN.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT)
*T24UP-13121(E)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-----------------------------------------------------------------------------
* Below fields are defaulted from GET ACCOUNT interface.
* Once interface is developed fields will be defaulted accordinlg.

    Y.SRC.MEB.NO = COMI
    IF Y.SRC.MEB.NO THEN

        COMI = FIELD(Y.SRC.MEB.NO, ' ',2,1)

        R.NEW(FT.LOCAL.REF)<1,Y.SRC.ACCT.BSB.POS> = FIELD(Y.SRC.MEB.NO,' ',1,1)
        R.NEW(FT.LOCAL.REF)<1,Y.SRC.ACCT.NO.POS> = FIELD(Y.SRC.MEB.NO,' ',2,1)
        R.NEW(FT.LOCAL.REF)<1,Y.SRC.ACCT.NAME.POS> = FIELD(Y.SRC.MEB.NO,' ',3,99)

    END
RETURN
*************
PROCESS.NEXT:
*************
    Y.SRC.ACT.MEB.NO = FIELD(Y.SRC.MEB.NO, ' ',2,1)

    IF Y.SRC.ACT.MEB.NO NE '' THEN
        Y.FT.TYPE = R.NEW(FT.TRANSACTION.TYPE)
        Y.SRC.BSB = R.NEW(FT.LOCAL.REF)<1,Y.SRC.ACCT.BSB.POS>
        R.AUMB.COMMON.PARAM = ''
        CALL F.READ(FN.AUMB.COMMON.PARAM,COMP.ID,R.AUMB.COMMON.PARAM,F.AUMB.COMMON.PARAM,ERR)
        IF R.AUMB.COMMON.PARAM THEN
            GOSUB CHECK.ACCT
            IF Y.FLAG NE 1 THEN
                GOSUB DEFAULT.DEBIT.ACCT
            END
        END
    END
RETURN

***********
CHECK.ACCT:
***********
    R.ACCOUNT = ''
    CALL F.READ(FN.ACCOUNT,Y.SRC.ACT.MEB.NO,R.ACCOUNT,F.ACCOUNT,ERR.ACC)
*T24UP-13121(S)	
    IF R.ACCOUNT EQ '' THEN
	    GOSUB GET.ALT.ID
    END ELSE
*T24UP-13121(E)
        Y.CUS = R.ACCOUNT<AC.CUSTOMER>
        Y.ACC.NAME=R.ACCOUNT<AC.SHORT.TITLE>
        Y.NAME=Y.ACC.NAME[1,32]
        Y.SRC.BSB = R.AUMB.COMMON.PARAM<MCP.T24BSB.IDENTI.CODE>
        R.NEW(FT.LOCAL.REF)<1,Y.SRC.ACCT.BSB.POS> = Y.SRC.BSB
    END

    Y.T24.BSB=R.AUMB.COMMON.PARAM<MCP.T24BSB.IDENTI.CODE>

    IF (Y.SRC.BSB EQ Y.T24.BSB AND R.ACCOUNT EQ '') THEN
        Y.FLAG=1
        ETEXT='EB-MEB.BSB.ACC.INVALID'
        CALL STORE.END.ERROR
    END
RETURN
*******************
DEFAULT.DEBIT.ACCT:
*******************

    IF Y.SRC.BSB EQ R.AUMB.COMMON.PARAM<MCP.T24BSB.IDENTI.CODE> THEN
        R.NEW(FT.DEBIT.ACCT.NO) = Y.SRC.ACT.MEB.NO
        R.NEW(FT.LOCAL.REF)<1,Y.SRC.ACCT.NAME.POS>=Y.NAME
        OFS$ENRI<FT.LOCAL.REF,Y.SRC.ACCT.NO.POS>=Y.NAME
    END ELSE
        LOCATE Y.SRC.BSB IN R.AUMB.COMMON.PARAM<MCP.BSB.IDENTI.CODE,1> SETTING Y.POS1 THEN
            R.NEW(FT.DEBIT.ACCT.NO) = R.AUMB.COMMON.PARAM<MCP.INTERN.SYS.ACCT,Y.POS1>
        END ELSE
            LOCATE Y.FT.TYPE IN R.AUMB.COMMON.PARAM<MCP.TRANSACTION.TYP,1>SETTING Y.POS2 THEN
                R.NEW(FT.DEBIT.ACCT.NO) = R.AUMB.COMMON.PARAM<MCP.CLEARING.AC,Y.POS2>
            END
        END
    END

RETURN

*T24UP-13121(S)
**********
GET.ALT.ID:
**********
    ACCT.ERR = ''
    R.ALTERNATE.ACCOUNT = ''
	R.ACCOUNT = ''
    CALL F.READ(FN.ALTERNATE.ACCOUNT,Y.SRC.ACT.MEB.NO,R.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT,ACCT.ERR)
    IF R.ALTERNATE.ACCOUNT THEN
        Y.SRC.ACT.MEB.NO = R.ALTERNATE.ACCOUNT<1>
        GOSUB CHECK.ACCT
    END

    RETURN
*T24UP-13121(E)
	
END
***------------------------------END OF ROUTINE-----------------------------------------------