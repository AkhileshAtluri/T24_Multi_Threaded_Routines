*-----------------------------------------------------------------------------
* <Rating>-23</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE MEB.V.INP.BLOCK.REVERSAL
*-----------------------------------------------------------------------------
* Developed By : Capgemini pvt ltd
* Purpose      : This routine blocks the reversal of the Interest adjustment transaction.
* Date         : 19 MAR 2019
* Attached to  : VERSION>FT,ACTR.ME
* Attached as  : Input Routine. 
*--------------------------------------------------------------------------------------------
* Modification History
*------------------------------------------------------------------------------------------------
* Modified By :
* Date:         Reference              Developed By    Change Description
* 19-Mar-19     SPT1-1966              Anand           Initial Draft
* 01-Jul-19    R18 Upgrade          Prashen A         INCLUDE to INSERT
*---------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.EB.LOOKUP
*-------------------------------------------------------------------------
    IF V$FUNCTION EQ 'R' THEN
        GOSUB INIT
        GOSUB PROCESS
    END
    RETURN
*---------------------------------------------------------------------------
INIT:
*****
    FN.EB.LOOKUP = 'F.EB.LOOKUP'
    F.EB.LOOKUP = ''
    CALL OPF(FN.EB.LOOKUP,F.EB.LOOKUP)

    RETURN

*-------------------------------------------------------------------------
PROCESS:
********
    EB.LOOKUP.ID = 'MEB.BLOCK.REVERSAL*FTTC'
    R.EB.LOOKUP = ''
    EB.LOOKUP.ERR = ''
    CALL F.READ(FN.EB.LOOKUP,EB.LOOKUP.ID,R.EB.LOOKUP,F.EB.LOOKUP,EB.LOOKUP.ERR)
    Y.FTTC.CODE = CHANGE(R.EB.LOOKUP<EB.LU.DATA.VALUE>,VM,FM)
    LOCATE R.NEW(FT.TRANSACTION.TYPE) IN Y.FTTC.CODE SETTING FTTC.POS THEN
        AF = FT.TRANSACTION.TYPE
        ETEXT = "EB-MEB.BLOCK.REVERSAL"
        CALL STORE.END.ERROR
    END

    RETURN
*---------------------------------------------------------------------------

END



