*-----------------------------------------------------------------------------
* <Rating>-20</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE MEB.V.INP.ADD.TYPE
*-----------------------------------------------------------------------------
* Company Name      :  ME Bank Australia
* Developed By      :  Country Model Bank
* ODR Number        :
* Coded by          :  Venkatachalam L
* Description       :  The Input routine attached in CUSTOMER versions
*                      to check for the duplication of the field ADD.TYPE
*-----------------------------------------------------------------------------
* Subroutine Type   :  S
* Attached to       : VERSION.CONTROL > CUSTOMER
* Attached as       : INPUT ROUTINE
* In Parameter
*         IN.PARAM.NAME      -   -NA-
*         IN.PARAM.ID        -   -NA-
* Out Parameter
*         OUT.PARAM          -   -NA-
*-----------------------------------------------------------------------------
*  Modification Details:
*-----------------------------------------------------------------------------
*
*
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.CUSTOMER
    $INSERT I_F.COUNTRY
    $INSERT I_F.EB.LOOKUP

    GOSUB INIT
    GOSUB PROCESS

    RETURN
*-------------------------------------------------------------------------
INIT:

    LOC.APPL = 'CUSTOMER'
    LOC.FLD = 'ADD.TYPE'
    LOC.POS = ''
    CALL MULTI.GET.LOC.REF(LOC.APPL,LOC.FLD,LOC.POS)
    ADD.TYPE.POS = LOC.POS<1,1>

    FN.EB.LOOKUP = 'F.EB.LOOKUP'
    F.EB.LOOKUP = ''
    CALL OPF(FN.EB.LOOKUP,F.EB.LOOKUP)
    R.EB.LOOK = ''
    L.ERR = ''

    RETURN
*-------------------------------------------------------------------------
PROCESS:

    Y.ADD.TYPE = R.NEW(EB.CUS.LOCAL.REF)<1,ADD.TYPE.POS>

    DCNT = DCOUNT(Y.ADD.TYPE,SM)
    CNT = 1

    LOOP
    WHILE CNT LE DCNT
        Y.VAL = Y.ADD.TYPE<1,1,CNT>
        Y.FLD.VAL = FIELD(Y.ADD.TYPE,SM,CNT+1,DCNT)
        FLD.VAL.POS = ''
        LOCATE Y.VAL IN Y.FLD.VAL<1,1,1> SETTING FLD.VAL.POS THEN
            Y.EB.LKUP = 'CUS.ADDRESS.GROUP*':Y.VAL
            CALL F.READ(FN.EB.LOOKUP,Y.EB.LKUP,R.EB.LOOK,F.EB.LOOKUP,L.ERR)
            Y.DESC = R.EB.LOOK<EB.LU.DESCRIPTION>
            AF = EB.CUS.LOCAL.REF
            AV = ADD.TYPE.POS
            AS = CNT
            ETEXT = 'ST-CUS.ONE.ADD.TYPE.ALLOWED':FM:Y.DESC
            CALL STORE.END.ERROR
        END
        CNT++
    REPEAT

    RETURN
*-------------------------------------------------------------------------
END
*-------------------------------------------------------------------------






