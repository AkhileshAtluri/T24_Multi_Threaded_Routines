* Developed By    : KK
* JIRA            : BPB-1082 ETA as Offset for T24 IO loan
* Purpose         : Updates FT id in the table MEB.T.BACKDATE.FTS, Debit value date or credit value date is greater than today.
*------------------------------------------------------------------------
* Subroutine Type : Auth routine
* Attached to     :VERSION.CONTROL>FUNDS.TRANSFER,VERSION>FUNDS.TRANSFER,INW.INBCS1,FUNDS.TRANSFER,INWCS2,FUNDS.TRANSFER,INWCS2.ACCEPT
* Attached to     :
* Attached as     : Auth routine
* In Parameter    :
* Out Parameter   : -NA-
*
*------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date:         Reference                             Developed By:
*
*
*----------------------------------------------------------------------------


    SUBROUTINE MEB.V.AUT.ACTVT.FOR.BKDT.TXNS
	           

    $INSERT I_EQUATE
    $INSERT I_COMMON

    $INSERT I_F.FUNDS.TRANSFER

    Y.DEBIT.VALUE.DATE = ""
    Y.CREDIT.VALUE.DATE = ""
    Y.DEBIT.VALUE.DATE = R.NEW(FT.DEBIT.VALUE.DATE)
    Y.CREDIT.VALUE.DATE = R.NEW(FT.CREDIT.VALUE.DATE)

    IF Y.DEBIT.VALUE.DATE LT TODAY OR Y.CREDIT.VALUE.DATE LT TODAY THEN
        GOSUB WRITE.BACK.DATE.FT.FILE
    END


    RETURN

WRITE.BACK.DATE.FT.FILE:
*-----------------------
    FN.MEB.T.BACKDATE.FTS = "F.MEB.T.BACKDATE.FTS"
    F.MEB.T.BACKDATE.FTS = ""
    CALL F.WRITE(FN.MEB.T.BACKDATE.FTS,ID.NEW,"")

    RETURN
END




