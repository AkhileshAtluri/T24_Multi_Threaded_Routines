
* Developed By    : KK
* Purpose         : This code will suffix alt id coming in the field ALT.ID.1 with '-C'
*                   and reads the table FUNDS.TRANSFER.ALT.ID.1. If the alt id existing in the table then it will delete the
*                   record from the table.
*------------------------------------------------------------------------
* Subroutine Type : -NA-
* Attached to     : -NA-
* Attached to     : FUNDS.TRANSFER,MEB.WS.CARDADVICE
* Attached as     : Auth routine
* In Parameter    : -NA-
* Out Parameter   : -NA-
*
*------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date:         Reference                             Developed By:
* 8-jun-2018    BPB-880                               KK
*
*-----------------------------------------------------------------------------



    SUBROUTINE MEB.V.AUT.CARD.CONTRA.ALT.DELETE

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER


    GOSUB INITIALISE.AND.FILE.OPEN
    GOSUB READ.CONTRA.ALT.AND.DELETE


    RETURN

INITIALISE.AND.FILE.OPEN:
*------------------------
    FN.FUNDS.TRANSFER.ALT.ID.1 = 'F.FUNDS.TRANSFER.ALT.ID.1'
    F.FUNDS.TRANSFER.ALT.ID.1 = ''
    CALL OPF(FN.FUNDS.TRANSFER.ALT.ID.1,F.FUNDS.TRANSFER.ALT.ID.1)

    APPLN = 'FUNDS.TRANSFER'
    FIELD.NAMES := 'ALT.ID.1'

    FIELD.POS = ''
    CALL MULTI.GET.LOC.REF(APPLN,FIELD.NAMES,FIELD.POS)
    ALT.ID.1.POS = FIELD.POS<1,1>

    CONTRA.ALT.ID = ""

    CONTRA.ALT.ID =  R.NEW(FT.LOCAL.REF)<1,ALT.ID.1.POS>:'-C'


    RETURN

READ.CONTRA.ALT.AND.DELETE:
*--------------
    R.FUNDS.TRANSFER.ALT.ID.1 = ""
    E.FUNDS.TRANSFER.ALT.ID.1 = ""
    CALL F.READ(FN.FUNDS.TRANSFER.ALT.ID.1,CONTRA.ALT.ID,R.FUNDS.TRANSFER.ALT.ID.1,F.FUNDS.TRANSFER.ALT.ID.1,E.FUNDS.TRANSFER.ALT.ID.1)
    IF R.FUNDS.TRANSFER.ALT.ID.1 THEN
        CALL F.DELETE(FN.FUNDS.TRANSFER.ALT.ID.1,CONTRA.ALT.ID)
    END

    RETURN
END





