     SUBROUTINE MEB.V.CR.DEF.WALK.IN.CUST
*-------------------------------------------------------------------------
* Developed By    : Sweta Singh
* Purpose         : JIRA Ref:T24UP-447
*                   To default WALK.IN.CUSTOMER with "YES" in case of Prospect customer, oherw
*------------------------------------------------------------------------
* Subroutine Type : Check Record Routine.
* Attached to     : CR.CONTACT.LOG,MEB.ADMIN
*			CR.CONTACT.LOG,MEB.ADMINISTRATION
*			CR.CONTACT.LOG,MEB.BANK.CHQ.CUST
*			CR.CONTACT.LOG,MEB.BANK.CHQ.ROLE
*			CR.CONTACT.LOG,MEB.BULK.OFS
*			CR.CONTACT.LOG,MEB.CONTACT.NOTE
*			CR.CONTACT.LOG,MEB.FEEDBACK
*			CR.CONTACT.LOG,MEB.FEEDBACK.CR
*			CR.CONTACT.LOG,MEB.SALES.ENQ
*			CR.CONTACT.LOG,MEB.SERVICE.REQ
*			CR.CONTACT.LOG,MEB.SERVICE.REQ.CARDS
*
* Attached as     : Check Record Routine
* In Parameter    : -NA-
* Out Parameter   : -NA-
*
*-------------------------------------------------------------------------
* Modification History :
*-----------------------
* UPGCHANGE - <developer> - <date> - <change description>
*------------------------------------------------------------------------

     $INSERT I_COMMON
     $INSERT I_EQUATE
     $INSERT I_F.CR.CONTACT.LOG
     $INSERT I_F.CUSTOMER

     GOSUB INIT
     GOSUB PROCESS

     RETURN

*********
 INIT:
*********

     FN.CUSTOMER = 'F.CUSTOMER'
     F.CUSTOMER = ''
     CALL OPF(FN.CUSTOMER,F.CUSTOMER)

     Y.CLIENT.ID = ''
     Y.CUS.TYPE = ''
     R.CUSTOMER = ''
     Y.CUS.ERR = ''
	
	 Y.CLIENT.ID = R.NEW(CR.CONT.LOG.CONTACT.CLIENT)
	 IF Y.CLIENT.ID EQ '' THEN
		Y.CLIENT.ID = COMI
	 END

     RETURN
*********
 PROCESS:
*********

     CALL F.READ(FN.CUSTOMER,Y.CLIENT.ID,R.CUSTOMER,F.CUSTOMER,Y.CUS.ERR)
     IF R.CUSTOMER THEN
         Y.CUS.TYPE = R.CUSTOMER<EB.CUS.CUSTOMER.TYPE>
         IF Y.CUS.TYPE EQ "PROSPECT" THEN
            R.NEW(CR.CONT.LOG.WALK.IN.CUSTOMER) = "YES"
        END ELSE
            R.NEW(CR.CONT.LOG.WALK.IN.CUSTOMER) = "NO"
        END
    END

    RETURN
END	
*----------------------------------End of Code--------------------------------------