*
* Generic Comments    : Input Routine
*------------------------------------------------------------------------
* Company Name        : M E BANK
* Developer Name      : Nikhil
* ODR Number          : BPB-1274/1275
* Subroutine Type     : S
* Attached as         : Input Routine to Version related to FUNDS.TRANSFER,ME.DDI
* Incoming Parameters : NA
* Outgoing Parameters : NA
* Development Date    : 29 OCT 2018
*-------------------------------------------------------------------------
* Modification History:-
*-------------------------------------------------------------------------
* Date            Modified by       Reference         Description
* 29/11/2019      Sidharth          PDR-119             To suppress dishonor fee for low fee eligible single applicant ETA
* 24/03/2020      Shakila           UPGCHANGE-MTP	Modified OWNER field to CUSTOMER field
* 13/09/2021      Vidhya            T24UP-13405     Changed the PRODUCT field to be fetched from 1st MV of PRODUCT from AA.ARRANGEMENT
*---------------------------------------------------------------------------------------------------------------------------------------------------

    SUBROUTINE MEB.V.INP.BALANCE.CHECK

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.AA.ARRANGEMENT
    $INSERT I_F.AA.ARRANGEMENT.ACTIVITY
    $INSERT I_F.CUSTOMER

    IF V$FUNCTION EQ 'I' THEN
        GOSUB INIT
        GOSUB PROCESS

    END

    RETURN

INIT:
******

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.ARRANGEMENT = 'F.AA.ARRANGEMENT'
    F.ARRANGEMENT = ''
    CALL OPF(FN.ARRANGEMENT,F.ARRANGEMENT)

    APP.NAME = ""
    OFSFUNCT = ""
    PROCESS = ""
    OFSVERSION = ""
    NO.OF.AUTH = ""
    R.ACCOUNT = ""
    E.ACCOUNT = ""
    OFS.RESP.ID = ""
    LREF.POS = ""
    LOCAL.FLD.NAMES = ""
*PDR-119:S
*    LOCAL.FLD.NAMES = 'SRC.ACCT.NAME'
*    CALL MULTI.GET.LOC.REF('FUNDS.TRANSFER',LOCAL.FLD.NAMES,LREF.POS)
    APPLN = 'FUNDS.TRANSFER':FM:'CUSTOMER'
    LOCAL.FLD.NAMES = 'SRC.ACCT.NAME':FM:'MEB.LFA.ENABLED'
    CALL MULTI.GET.LOC.REF(APPLN,LOCAL.FLD.NAMES,LREF.POS)
    SRC.ACCT.NAME.POS = LREF.POS<1,1>
    Y.LFA.ENABLED.POS = LREF.POS<2,1>

    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ''
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)

    R.CUSTOMER = ''
    ERR.CUSTOMER = ''
    Y.LFA.ENABLED = ''

*PDR-119:E
    RETURN

PROCESS:
*********

    Y.DEBIT.ACCOUNT = R.NEW(FT.DEBIT.ACCT.NO)
    Y.DEBIT.AMT = R.NEW(FT.DEBIT.AMOUNT)
    Y.DEBIT.DATE = R.NEW(FT.DEBIT.VALUE.DATE)
    ACCT.ID = Y.DEBIT.ACCOUNT

    CALL F.READ(FN.ACCOUNT,Y.DEBIT.ACCOUNT,R.ACCOUNT,F.ACCOUNT,ACC.ERR)
    IF R.ACCOUNT THEN
        Y.ARR.ID = R.ACCOUNT<AC.ARRANGEMENT.ID>

        CALL F.READ(FN.ARRANGEMENT,Y.ARR.ID,R.AA.ARR,F.ARRANGEMENT,ARR.ERR)
* T24UP-13405 (S)
*        Y.PRODUCT = R.AA.ARR<AA.ARR.PRODUCT>
         Y.PRODUCT = R.AA.ARR<AA.ARR.PRODUCT,1>
* T24UP-13405 (E)		 
*PDR-119:S
*        Y.OWNER = R.AA.ARR<AA.ARR.OWNER>      ; * Commented for UPGCHANGE-MTP
	 Y.OWNER = R.AA.ARR<AA.ARR.CUSTOMER>    ; * Added for UPGCHANGE-MTP
        Y.OWNER.CNT =  DCOUNT(Y.OWNER,VM)
*PDR-119:E

        IF Y.PRODUCT EQ 'TRANS.ACCOUNT' OR Y.PRODUCT EQ 'IMSA.ACCOUNT' THEN
            GOSUB CHK.IF.CUS.IS.LOW.FEE.ELIGIBLE  ;*PDR-119
            AA.BALANCE = ""
            AA.CR.MVMT = "" ; AA.DR.MVMT = "";  ERR.MSG = ""
            BALANCE.DATE = Y.DEBIT.DATE
            CALL AA.GET.ACCT.BALANCE(ACCT.ID, R.ACCOUNT, "VALUE", BALANCE.DATE, "", AA.BALANCE, AA.CR.MVMT, AA.DR.MVMT, ERR.MSG)
*PDR-119:S
            GOSUB NEXT.PROCESS
*            IF Y.DEBIT.AMT GT AA.BALANCE THEN
*               GOSUB POST.DSHNR
*               ETEXT = 'FT-NO.AVAILABLE.AMOUNT'
*               CALL STORE.END.ERROR
*            END
*PDR-119:E

        END
    END

    RETURN
*----------------------------------------------------------------
NEXT.PROCESS:
*-----------
    IF Y.DEBIT.AMT GT AA.BALANCE THEN
        IF Y.LFA.ENABLED EQ '' THEN
            GOSUB POST.DSHNR
        END

        ETEXT = 'FT-NO.AVAILABLE.AMOUNT'
        CALL STORE.END.ERROR
    END

    RETURN
*-----------------------------------------------------------------
POST.DSHNR:
***********

    APP.NAME               = 'AA.ARRANGEMENT.ACTIVITY'
    OFSFUNCT               = 'I'
    PROCESS                = 'PROCESS'
    OFSVERSION             = 'AA.ARRANGEMENT.ACTIVITY,DMI'
    NO.OF.AUTH             = '0'
    OFSRECORD              = ''
    OFS.MSG.ID             = ''
    OFS.SOURCE.ID          = ''
    OFS.ERR                = ''
    YGTS.MODE              = ''
    Y.AAA.ID = ""
    OFS.MSG.ID = ""

    R.AAA = ""
    R.AAA<AA.ARR.ACT.EFFECTIVE.DATE> = TODAY
    R.AAA<AA.ARR.ACT.ARRANGEMENT> = R.ACCOUNT<AC.ARRANGEMENT.ID>
    R.AAA<AA.ARR.ACT.ACTIVITY> = 'ACCOUNTS-TRIGGER-DDDSHNR'
    R.AAA<AA.ARR.ACT.NARRATIVE> = R.NEW(FT.LOCAL.REF)<1,SRC.ACCT.NAME.POS>:'/':R.NEW(FT.DEBIT.AMOUNT)

    EB.FM.OFSSTRING        = ''
    Y.OFS.SOURCE           = 'INT.RATE.CHG'
    NEXT.ID                = ''
    CALL OFS.BUILD.RECORD(APP.NAME,OFSFUNCT,PROCESS,OFSVERSION,YGTS.MODE,NO.OF.AUTH,Y.AAA.ID,R.AAA,OFSSTRING)

    CALL ALLOCATE.UNIQUE.TIME(OFS.MSG.ID)
    OFS.MSG.ID = DATE():OFS.MSG.ID
    MSG.ID = OFS.MSG.ID:'-':Y.OFS.SOURCE

    OPEN 'F.MEB.OFS.MESSAGE.QUEUE' TO V.MESSAGE.QUEUE ELSE

    END
    WRITE OFSSTRING ON V.MESSAGE.QUEUE,MSG.ID ON ERROR

    END

    RETURN
*-----------------------------------------------------------------------
CHK.IF.CUS.IS.LOW.FEE.ELIGIBLE:
*------------------------------
    IF Y.PRODUCT EQ 'TRANS.ACCOUNT' AND Y.OWNER.CNT EQ '1' THEN
        CALL F.READ(FN.CUSTOMER,Y.OWNER,R.CUSTOMER,F.CUSTOMER,ERR.CUSTOMER)
        IF R.CUSTOMER THEN
            Y.LFA.ENABLED = R.CUSTOMER<EB.CUS.LOCAL.REF><1,Y.LFA.ENABLED.POS>
        END
    END

    RETURN
*--------------------------------------------------------------------------
END


