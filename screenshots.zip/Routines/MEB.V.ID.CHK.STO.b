*-----------------------------------------------------------------------------
    SUBROUTINE MEB.V.ID.CHK.STO
*-----------------------------------------------------------------------------
* Description           : To restrict creating STO for accounts with product "LENDING" OR "DEPOSITS"
* Developed By          : Shaila S, Capgemini
* Developed Date        : 28 Aug 2018
* Development Ref       :
* Attached To           : Version STANDING.ORDER,MEB.FIXAMT
* Attached As           : ID routine
* In Parameter          : NA
* Out Parameter         : NA
*-----------------------------------------------------------------------------
* Modification History:
***********************
* Reference        Modified By           Date of Change    Change Details
*                                        (YYYY-MM-DD)
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Include files


    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.STANDING.ORDER
    $INSERT I_F.AA.ARRANGEMENT
    $INSERT I_F.ACCOUNT
    $INSERT I_F.ALTERNATE.ACCOUNT


    GOSUB INIT
    GOSUB PROCESS
    RETURN


INIT:


    FN.STANDING.ORDER = "F.STANDING.ORDER"
    F.STANDING.ORDER = ""
    CALL OPF(FN.STANDING.ORDER,F.STANDING.ORDER)


    FN.AA.ARRANGEMENT = "F.AA.ARRANGEMENT"
    F.AA.ARRANGEMENT = ""
    CALL OPF(FN.AA.ARRANGEMENT,F.AA.ARRANGEMENT)

    FN.ALT.ACCT = 'F.ALTERNATE.ACCOUNT'
    F.ALT.ACCT = ''
    CALL OPF(FN.ALT.ACCT,F.ALT.ACCT)

    FN.ACC = 'F.ACCOUNT'
    F.ACC = ''
    AC.ERR = ''
    CALL OPF(FN.ACC,F.ACC)

    R.ARR = ""
    ARR.ERR = ""
    R.ACC = ""

    R.ALT.ACCT = ''
    ERR.ALT.ACCT = ''

    RETURN


PROCESS:
    GOSUB CHECK.IF.LOAN.TD
    GOSUB READ.AA.INFO
    GOSUB CHECK.PRD.VALID

    RETURN
*===================
CHECK.IF.LOAN.TD:
*===================
    ID.PASS = COMI
    ID.PASS = FIELD(ID.PASS,'.',1)

    IF ID.PASS[1,2] NE 'AA' THEN
        CALL F.READ(FN.ALT.ACCT,ID.PASS,R.ALT.ACCT,F.ALT.ACCT,ERR.ALT.ACCT)
        IF NOT(ERR.ALT.ACCT) THEN
            ID.PASS = R.ALT.ACCT<AAC.GLOBUS.ACCT.NUMBER>
        END
        CALL F.READ(FN.ACC,ID.PASS,R.ACC,F.ACC,AC.ERR)
        IF R.ACC THEN
            ID.PASS = R.ACC<AC.ARRANGEMENT.ID>
        END
    END

    RETURN
*===================
READ.AA.INFO:
*===================
    R.ARR = ''
    ARR.ERR = ''
    ARR.PROD.LINE = ''
    CALL F.READ(FN.AA.ARRANGEMENT,ID.PASS,R.ARR,F.AA.ARRANGEMENT,ARR.ERR)
    IF R.ARR THEN
        ARR.PROD.LINE = R.ARR<AA.ARR.PRODUCT.LINE>
    END

    RETURN
CHECK.PRD.VALID:

    IF ARR.PROD.LINE EQ "LENDING" OR ARR.PROD.LINE EQ "DEPOSITS" THEN
        E = 'EB-MEB.STO.AC.PRD.ERR'
        CALL STORE.END.ERROR
    END

    RETURN

END



















