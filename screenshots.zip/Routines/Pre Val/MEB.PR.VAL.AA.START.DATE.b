* @ValidationCode : MjotNjA4MTkwNzQ1OkNwMTI1MjoxNjAyMDQyMTQwOTM2Om1lNzE1NDE2Oi0xOi0xOjA6MDpmYWxzZTpOL0E6UjE4X1NQMTMuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 07 Oct 2020 14:42:20
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : me715416
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R18_SP13.0
SUBROUTINE MEB.PR.VAL.AA.START.DATE
*-------------------------------------------------------------------------
* Developed By    : Capgemini India Pvt Ltd
* Program Name    : MEB.PR.VAL.AA.START.DATE
* Purpose         : The purpose of this routine is to validate date format in the field
*                   AA.ARR.PAYMENT.SCHEDULE>START.DATE if AA.ARR.PAYMENT.SCHEDULE>PAYMENT.TYPE is SPECIAL
*-------------------------------------------------------------------------
* Subroutine Type : S
* Attached To     : AA.PRD.DES.ACTIVITY.API>DEPOSITS
* Attached As     : Pre validate routine
* In Parameter    : -NA-
* Out Parameter   : -NA-
*-------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date:         Reference              Developed By    Change Description
* 05-Oct-20     PPDC-2778              Anand           Initial Draft
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_AA.APP.COMMON
    $INSERT I_AA.LOCAL.COMMON
    $INSERT I_F.AA.ARRANGEMENT.ACTIVITY
    $INSERT I_F.AA.PAYMENT.SCHEDULE
*-------------------------------------------------------------------------

    IF c_aalocActivityStatus NE 'UNAUTH' THEN
        RETURN
    END
    
    AA.ARRANGEMENT.ACTIVITY.ID = c_aalocArrActivityId
    R.AA.ARRANGEMENT.ACTIVITY = c_aalocArrActivityRec
    REPLAY.MODE = ''

    CALL AA.CHECK.REPLAY.MODE(AA.ARRANGEMENT.ACTIVITY.ID,R.AA.ARRANGEMENT.ACTIVITY,REPLAY.MODE)

    IF REPLAY.MODE THEN
        RETURN  ;* No need to Replay
    END
    
    IF AA$R.ARRANGEMENT.ACTIVITY<AA.ARR.ACT.REV.MASTER.AAA> NE '' OR AA$R.ARRANGEMENT.ACTIVITY<AA.ARR.ACT.SIM.RUN.REF> NE '' THEN
        RETURN
    END
    
    GOSUB PROCESS
    
RETURN
*-------------------------------------------------------------------------
PROCESS:
********

    PAYMENT.TYPE = R.NEW(AA.PS.PAYMENT.TYPE)
    SPL.POS = ''
    LOCATE 'SPECIAL' IN PAYMENT.TYPE<1,1> SETTING SPL.POS THEN
       
        START.DATE = R.NEW(AA.PS.START.DATE)<1,SPL.POS,1>
        IF START.DATE NE ''  AND START.DATE[1,1] NE 'R' AND START.DATE[1,1] NE 'D' THEN
            AF = AA.PS.START.DATE
            AV = SPL.POS
            ETEXT = 'AA-MEB.TD.INVALID.DATE.FMT'
            CALL STORE.END.ERROR
        END
    END

RETURN
*-------------------------------------------------------------------------
END
*-----------------------------------------------------------------------------
