*-----------------------------------------------------------------------------
* <Rating>-23</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE MEB.PR.VAL.AA.OSA.BONUS
*-----------------------------------------------------------------------------
* Developed By : Capgemini pvt ltd
* Purpose      : This routine validates the MEB.BONUS.ELGBL field value
*                activity effective date for the  activity ACCOUNTS-UPDATE-BONUS.ELIGIBILITY
* Date         : 14 FEB 2019
* Attached to  : ACTIVITY.API condition for ACCOUNTS
* Attached as  : Pre-Validation Routine in activity api listed under INTEREST property class.
*--------------------------------------------------------------------------------------------
* Modification History
*------------------------------------------------------------------------------------------------
* Modified By :
* Date:         Reference              Developed By    Change Description
* 14-Feb-19     SPT1-1600              Deepti          Initial Draft
* 15-Mar-19     SPT1-1941              Deepti          Display of error message when Bonus Interest is opt out.
* 04-Apr-19     SPT1-2297              Deepti          checking of null value for R.OLD value of BONUS.ELIGIBLITY field.
*UPCHANGE - Sangeetha - 20191104 - INCLUDE commented and INSERT added w.r.t TAFJ
*---------------------------------------------------------------------------------------------
*START-UPCHANGE-20191104
    *$INCLUDE ../T24_BP I_COMMON
    *$INCLUDE ../T24_BP I_EQUATE
    *$INCLUDE ../T24_BP I_AA.APP.COMMON
    *$INCLUDE ../T24_BP I_AA.LOCAL.COMMON
    *$INCLUDE ../T24_BP I_F.AA.ACTIVITY.HISTORY
    *$INCLUDE ../T24_BP I_AA.ACTION.CONTEXT
    *$INCLUDE ../T24_BP I_F.AA.ARRANGEMENT.ACTIVITY
    *$INCLUDE ../T24_BP I_F.AA.INTEREST
    *$INCLUDE ../T24_BP I_F.AA.ARRANGEMENT
    *$INCLUDE ../T24_BP I_F.USER
    *$INCLUDE ../T24_BP I_F.EB.LOOKUP
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_AA.APP.COMMON
    $INSERT I_AA.LOCAL.COMMON
    $INSERT I_F.AA.ACTIVITY.HISTORY
    $INSERT I_AA.ACTION.CONTEXT
    $INSERT I_F.AA.ARRANGEMENT.ACTIVITY
    $INSERT I_F.AA.INTEREST
    $INSERT I_F.AA.ARRANGEMENT
    $INSERT I_F.USER
    $INSERT I_F.EB.LOOKUP
    *END - UPCHANGE-20191104

    AAA.STATUS = c_aalocActivityStatus
    GOSUB INITIALISE
    GOSUB PROCESS

    RETURN
*-----------------------------------------------------------------------------
INITIALISE:
*-----------------------------------------------------------------------------
    FN.USER = 'F.USER'
    F.USER = ''
    CALL OPF(FN.USER,F.USER)
*
    FN.EB.LOOKUP = 'F.EB.LOOKUP'
    F.EB.LOOKUP = ''
    CALL OPF(FN.EB.LOOKUP,F.EB.LOOKUP)

    EFFECTIVE.DATE = c_aalocActivityEffDate
    Y.PROD.ID = c_aalocArrProductId
*
    Y.BONUS.POS = ''
    Y.APP = 'AA.ARR.INTEREST'
    Y.FLD = 'MEB.BONUS.ELGBL'
    Y.LOC.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP,Y.FLD,Y.LOC.POS)
    Y.BONUS.POS = Y.LOC.POS<1,1>

    RETURN
*-----------------------------------------------------------------------------
PROCESS:
*--------------------------------------------------------------------------------

    IF Y.PROD.ID NE 'OSA.RETAIL.NONMEMBER' THEN
        AF = AA.ARR.ACT.PRODUCT
        ETEXT = "EB-MEB.ACCT.PRD.OSA"
        CALL STORE.END.ERROR
    END

    Y.TODAY.DATE = TODAY
    IF EFFECTIVE.DATE NE Y.TODAY.DATE THEN
        AF = AA.ARR.ACT.EFFECTIVE.DATE
        ETEXT = "EB-MEB.ACT.EFF.DATE"
        CALL STORE.END.ERROR
    END

**SPT1-1941 --START

    Y.USER = OPERATOR
    R.USER.REC = ''
    USER.ERR = ''
    CALL F.READ(FN.USER,Y.USER,R.USER.REC,F.USER,USER.ERR)
    Y.USER.ROLE = CHANGE(R.USER.REC<EB.USE.USER.ROLES>,SM,FM)
    IF Y.USER.ROLE EQ '' THEN
        RETURN
    END
**SPT1-1941 --END

    Y.BONUS.ELIGIBLE.NEW = R.NEW(AA.INT.LOCAL.REF)<1,Y.BONUS.POS>
    Y.BONUS.ELIGIBLE.OLD = R.OLD(AA.INT.LOCAL.REF)<1,Y.BONUS.POS>
**SPT1-1941 --START
*  IF Y.BONUS.ELIGIBLE.NEW NE Y.BONUS.ELIGIBLE.OLD THEN
*     TEXT = "OV.MEB.ACT.ELIGIBLE.OSA"
*    CALL STORE.OVERRIDE(CURR.NO)
* END

** SPT1-2297 -start

    IF Y.BONUS.ELIGIBLE.NEW EQ '' THEN
** SPT1-2297 -end
        AF = AA.INT.LOCAL.REF
        AV = Y.BONUS.POS
        ETEXT = "EB-MEB.INPUT.MANDATORY"
        CALL STORE.END.ERROR
    END


    IF (Y.BONUS.ELIGIBLE.OLD NE 'NOT.ELIGIBLE') AND (Y.BONUS.ELIGIBLE.NEW EQ 'NOT.ELIGIBLE') THEN
        GOSUB CHECK.USER.ROLE
    END

    IF (Y.BONUS.ELIGIBLE.OLD EQ 'NOT.ELIGIBLE') AND (Y.BONUS.ELIGIBLE.NEW NE 'NOT.ELIGIBLE') THEN
        TEXT = "OV.MEB.ACT.ELIGIBLE.OSA"
        CALL STORE.OVERRIDE(CURR.NO)
    END
**SPT1-1941 --END

    RETURN
*----------------------------------------------------------------------------------
CHECK.USER.ROLE:
****************
    EB.LOOKUP.ID = 'MEB.ALLOWED.USER*ROLES'
    R.EB.LOOKUP = ''
    EB.LOOKUP.ERR = ''
    CALL F.READ(FN.EB.LOOKUP,EB.LOOKUP.ID,R.EB.LOOKUP,F.EB.LOOKUP,EB.LOOKUP.ERR)
    ROLE.VALUE = CHANGE(R.EB.LOOKUP<EB.LU.DATA.VALUE>,VM,FM)
    LOOP
        REMOVE ROLE.ID FROM Y.USER.ROLE SETTING POS
    WHILE ROLE.ID:POS
        LOCATE ROLE.ID IN ROLE.VALUE SETTING USER.POS THEN
            TEXT = "OV.MEB.ACT.ELIGIBLE.OSA"
            CALL STORE.OVERRIDE(CURR.NO)
        END ELSE
            AF = AA.INT.LOCAL.REF
            AV = Y.BONUS.POS
            ETEXT = "EB-MEB.OSA.OPT.OUT"
            CALL STORE.END.ERROR
        END
    REPEAT


    RETURN
*----------------------------------------------------------------------------------

END


