* @ValidationCode : MjoyNjM2MzYzNjY6Q3AxMjUyOjE1NTQ3MTczNDU1NjU6bWU4MDA1ODhfdHN0Oi0xOi0xOjA6MDpmYWxzZTpOL0E6UjE4X1NQMi4wOi0xOi0x
* @ValidationInfo : Timestamp         : 08 Apr 2019 19:55:45
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : me800588_tst
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R18_SP2.0
*-----------------------------------------------------------------------------
* <Rating>-50</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE MEB.V.VAL.BEN.ACCT
*-------------------------------------------------------------------------
* Subroutine Type   :  S
* Attached to       : BENEFICIARY,CREATE.MEB
* Attached as       : Hot Validate Routine to field BEN.ACCT.NO
*-------------------------------------------------------------------------
* Modification History:
*
* UPGCHANGE - T Sidharth - 20190408 -replaced the MEB.COMMON.PARM to AUMB.COMMON.PARAM
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.AUMB.COMMON.PARAM
    $INSERT I_F.ACCOUNT
    $INSERT I_F.BENEFICIARY
    $INSERT I_F.CATEGORY

    GOSUB OPEN.FILES
    GOSUB GET.LOCAL.REF
    GOSUB PROCESS
    RETURN

**********
OPEN.FILES:
**********
    FN.AUMB.COMMON.PARAM = 'F.AUMB.COMMON.PARAM'
    F.AUMB.COMMON.PARAM   = ''
    CALL OPF(FN.AUMB.COMMON.PARAM,F.AUMB.COMMON.PARAM)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT  = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.ALTERNATE.ACCOUNT = 'F.ALTERNATE.ACCOUNT'
    F.ALTERNATE.ACCOUNT = ''
    CALL OPF(FN.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT)

    FN.CATEGORY = 'F.CATEGORY'
    F.CATEGORY = ''
    CALL OPF(FN.CATEGORY,F.CATEGORY)

    Y.COM.ID = ID.COMPANY
    CALL CACHE.READ(FN.AUMB.COMMON.PARAM,Y.COM.ID,R.AUMB.COMMON.PARAM,PARAM.ERR)
    IF R.AUMB.COMMON.PARAM THEN
        Y.MEB.CODE = R.AUMB.COMMON.PARAM<MCP.T24BSB.IDENTI.CODE>
    END
    RETURN
**************
GET.LOCAL.REF:
*************
    APL.ARRAY = APPLICATION:FM:'CATEGORY'
    APL.FIELD = 'BEN.BSB':VM:'BEN.ACCOUNT':VM:'BEN.ACCT.NAME':FM:'INCL.GET.ARLIST'
    FLD.POS   = ''
    CALL MULTI.GET.LOC.REF(APL.ARRAY,APL.FIELD,FLD.POS)
    LOC.BEN.BSB.POS = FLD.POS<1,1>
    LOC.BEN.ACC.POS = FLD.POS<1,2>
    LOC.BEN.ACC.NAME.POS = FLD.POS<1,3>
    INCL.GET.ARLIST.POS = FLD.POS<2,1>

    RETURN
********
PROCESS:
********

    IF COMI EQ '' THEN
        RETURN
    END
    Y.BSB.CODE = R.NEW(ARC.BEN.LOCAL.REF)<1,LOC.BEN.BSB.POS>
    BEGIN CASE
    CASE Y.BSB.CODE EQ ''
        Y.ACCT.ID = COMI
        GOSUB READ.ACCOUNT
        IF R.ACCOUNT EQ '' THEN
            GOSUB GET.ALT.ID
        END
        IF R.ACCOUNT THEN
            R.CATEGORY = ''; CATEG.ERR = ''
            CALL F.READ(FN.CATEGORY,R.ACCOUNT<AC.CATEGORY>,R.CATEGORY,F.CATEGORY,CATEG.ERR)
            IF R.CATEGORY<EB.CAT.LOCAL.REF,INCL.GET.ARLIST.POS>[1,1] EQ 'N' THEN
                R.NEW(ARC.BEN.LOCAL.REF)<1,LOC.BEN.BSB.POS> = '944300'
            END ELSE
                R.NEW(ARC.BEN.LOCAL.REF)<1,LOC.BEN.BSB.POS> = Y.MEB.CODE
            END
        END

    CASE Y.BSB.CODE NE '' AND Y.BSB.CODE EQ Y.MEB.CODE
        Y.ACCT.ID = COMI
        GOSUB READ.ACCOUNT
        IF R.ACCOUNT EQ '' THEN
            GOSUB GET.ALT.ID
        END
        IF ACCT.ERR THEN
            ETEXT = 'EB-INVALID.RECORD.AC'
            AF = ARC.BEN.LOCAL.REF
            AV = LOC.BEN.ACC.POS
        END
    CASE Y.BSB.CODE NE '' AND Y.BSB.CODE NE Y.MEB.CODE
        Y.LEN = LEN(COMI)
        IF Y.LEN GT '20' THEN
            ETEXT = 'EB-BC.SORT.CODE.MAX'
            AF    = ARC.BEN.LOCAL.REF
            AV    = LOC.BEN.ACC.POS
        END
    END CASE
    RETURN
*************
READ.ACCOUNT:
*************
    R.ACCOUNT = ''
    CALL F.READ(FN.ACCOUNT,Y.ACCT.ID,R.ACCOUNT,F.ACCOUNT,ACCT.ERR)
    IF R.ACCOUNT THEN
        R.NEW(ARC.BEN.LOCAL.REF)<1,LOC.BEN.ACC.NAME.POS> = R.ACCOUNT<AC.SHORT.TITLE>
    END

    RETURN

GET.ALT.ID:
**********
    ACCT.ERR = ''
    R.ACCOUNT = ''
    CALL F.READ(FN.ALTERNATE.ACCOUNT,Y.ACCT.ID,R.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT,ACCT.ERR)
    IF R.ALTERNATE.ACCOUNT THEN
        Y.ACCT.ID = R.ALTERNATE.ACCOUNT<1>
        GOSUB READ.ACCOUNT
    END

    RETURN
END

 
