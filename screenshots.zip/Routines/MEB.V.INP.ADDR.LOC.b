    SUBROUTINE MEB.V.INP.ADDR.LOC

* Modification History:-
* UPGCHANGE - Sweta - 20190307 - Converted the insert files
*--------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.CUSTOMER



    GOSUB PROCESS

    RETURN



PROCESS:

    Y.INIT.CNT = 1
    Y.ADDR.LOC.CNT = DCOUNT(R.NEW(EB.CUS.ADDR.LOCATION),VM)
    IF Y.ADDR.LOC.CNT EQ '' OR Y.ADDR.LOC.CNT EQ 0 THEN
        Y.ADDR.LOC.CNT = 1
    END
    LOOP
    WHILE Y.INIT.CNT LE Y.ADDR.LOC.CNT
        IF R.NEW(EB.CUS.ADDR.LOCATION)<1,Y.INIT.CNT> EQ '' THEN
            AF = EB.CUS.ADDR.LOCATION
            AV = Y.INIT.CNT
            ETEXT = 'EB-INP.MISS'
            CALL STORE.END.ERROR
        END
        Y.INIT.CNT += 1

    REPEAT



    RETURN

END



