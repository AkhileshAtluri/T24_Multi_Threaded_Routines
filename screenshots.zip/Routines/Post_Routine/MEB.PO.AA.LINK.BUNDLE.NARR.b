    SUBROUTINE MEB.PO.AA.LINK.BUNDLE.NARR
*------------------------------------------------------------------------
* Generic Comments    :
*------------------------------------------------------------------------
* Company Name        : ME Bank
* Developer Name      : CAPGEMINI-SUDISH RAMAKRISHNAN
* Subroutine Type     : S
* Attached as         : POST ROUTINE
* Attached to         : BUNDLE-LINK-OFFSET & BUNDLE-DELINK-OFFSET with Action = UPDATE & Property = PRODUCT.BUNDLE
* Primary Purpose     : PPLX-268 - This is a POST routine which triggers the LENDING-LINK-OFFSET or LENDING-DELINK-OFFSET via
*                                               OFS message on the associated HOME LOAN depending on the bundle link or de-link activity
*
*------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_AA.APP.COMMON
    $INSERT I_EB.TRANS.COMMON
    $INSERT I_AA.ACTION.CONTEXT
    $INSERT I_GTS.COMMON
    $INSERT I_F.AA.SETTLEMENT
    $INSERT I_F.AA.ARRANGEMENT.ACTIVITY
    $INSERT I_F.AA.PRODUCT.BUNDLE
    $INSERT I_F.AUMB.GENERIC.PARAM
    $INSERT I_F.AA.ARRANGEMENT
    $INSERT I_F.AA.PRODUCT.BUNDLE
    GOSUB CHK.EXIT.CONDN

    IF EXIT.FLAG THEN
        RETURN
    END

    GOSUB OPEN.FILES
    GOSUB READ.BUNDLE.PARAM
    GOSUB GET.ACTIVITY.NAME
    GOSUB GET.HL.ARR.ID
    IF HL.ARR.ID THEN
        GOSUB GENERATE.OFS.MSG
    END

    RETURN
*------------------------------------------------------------------------
CHK.EXIT.CONDN:
*------------------------------------------------------------------------
*** Exit the routine if in RR mode, Activity Status NE 'AUTH'
    EXIT.FLAG = ''
    HL.ARR.ID = ''

    BEGIN CASE
    CASE c_arrActivityStatus NE 'AUTH'
        EXIT.FLAG = 1
    CASE AA$R.ARRANGEMENT.ACTIVITY<AA.ARR.ACT.REV.MASTER.AAA> NE '' OR AA$R.ARRANGEMENT.ACTIVITY<AA.ARR.ACT.SIM.RUN.REF> NE ''
        EXIT.FLAG = 1
    CASE 1
        ARR.ACTIVITY.ID = c_arrActivityId         ;* Arrangement Activity Id
        R.ACTIVITY = c_arrActivityRec   ;* Arrangement Activity record

        REPLAY.MODE = ''
        CALL AA.CHECK.REPLAY.MODE(ARR.ACTIVITY.ID, R.ACTIVITY, REPLAY.MODE)
        IF REPLAY.MODE THEN
            EXIT.FLAG = 1     ;* No need to Replay
        END
    END CASE

    RETURN
*------------------------------------------------------------------------
OPEN.FILES:
*------------------------------------------------------------------------
    F.AUMB.GENERIC.PARAM = ''
    FN.AUMB.GENERIC.PARAM = 'F.AUMB.GENERIC.PARAM'
    CALL OPF(FN.AUMB.GENERIC.PARAM, F.AUMB.GENERIC.PARAM)

    RETURN
*------------------------------------------------------------------------
GET.ACTIVITY.NAME:
*------------------------------------------------------------------------
    PARAM.TYPE = '' ; PARAM.NAME = '' ; PARAM.VALUE = ''
    PRM.CTR = 1
    LOOP
        REMOVE PARAM.TYPE FROM PARAM.TYPE.LIST SETTING PRM.POS
    WHILE PARAM.TYPE : PRM.POS
        PARAM.NAME = PARAM.NAME.LIST<1,PRM.CTR>
        PARAM.VALUE = PARAM.VALUE.LIST<1,PRM.CTR>

        BEGIN CASE
        CASE PARAM.TYPE EQ 'LINK.ETA'
            IF PARAM.NAME EQ AA$CURR.ACTIVITY THEN
                OFS.AA.ACTIVITY = PARAM.VALUE
            END
        CASE PARAM.TYPE EQ 'DELINK.ETA'
            IF PARAM.NAME EQ AA$CURR.ACTIVITY THEN
                OFS.AA.ACTIVITY = PARAM.VALUE
            END
        END CASE
        PRM.CTR ++
    REPEAT

    RETURN
*------------------------------------------------------------------------
GET.HL.ARR.ID:
*------------------------------------------------------------------------
    LOCATE 'HOME.LOAN' IN R.NEW(AA.BUN.PRODUCT.GROUP)<1,1> SETTING HL.POS THEN
        HL.ARR.ID = R.NEW(AA.BUN.ARRANGEMENT)<1,HL.POS>
    END

    RETURN
*------------------------------------------------------------------------
READ.BUNDLE.PARAM:
*------------------------------------------------------------------------
    R.GENERIC.PARAM = '' ; GEN.ERR = ''
    GEN.ID = 'BUNDLE.SERVICE'
    CALL F.READ(FN.AUMB.GENERIC.PARAM, GEN.ID, R.GENERIC.PARAM, F.AUMB.GENERIC.PARAM, GEN.ERR)

    PARAM.TYPE.LIST = R.GENERIC.PARAM<GEN.PARM.PARAM.TYPE>
    PARAM.NAME.LIST = R.GENERIC.PARAM<GEN.PARM.PARAM.NAME>
    PARAM.VALUE.LIST = R.GENERIC.PARAM<GEN.PARM.PARAM.VALUE>

    RETURN
*------------------------------------------------------------------------
GENERATE.OFS.MSG:
*------------------------------------------------------------------------
    APP.NAME = 'AA.ARRANGEMENT.ACTIVITY'
    PROCESS = 'PROCESS'
    OFS.VERSION = 'AA.ARRANGEMENT.ACTIVITY,ZERO.AUTH'
    OFS.FUNCTION = 'I'
    GTS.MODE = ''
    NO.OF.AUTH = '0'
    TRANSACTION.ID = ''
    OFS.MESSAGE = ''
    OFS.SOURCE.ID = 'MEB.BUNDLE.SERVICE'

    R.APP.RECORD = ''
    R.APP.RECORD<AA.ARR.ACT.ARRANGEMENT> = HL.ARR.ID
    R.APP.RECORD<AA.ARR.ACT.ACTIVITY> = OFS.AA.ACTIVITY
    R.APP.RECORD<AA.ARR.ACT.EFFECTIVE.DATE> = AA$ACTIVITY.EFF.DATE
    R.APP.RECORD<AA.ARR.ACT.CUSTOMER> = AA$R.ARRANGEMENT<AA.ARR.CUSTOMER>
    R.APP.RECORD<AA.ARR.ACT.CURRENCY> = AA$R.ARRANGEMENT<AA.ARR.CURRENCY>
    R.APP.RECORD<AA.ARR.ACT.PROPERTY> = 'ACCOUNT'

    CALL OFS.BUILD.RECORD(APP.NAME,OFS.FUNCTION,PROCESS,OFS.VERSION,GTS.MODE,NO.OF.AUTH,TRANSACTION.ID,R.APP.RECORD,OFS.MESSAGE)
    RET.ID = ''
    CALL OFS.POST.MESSAGE(OFS.MESSAGE,RET.ID,OFS.SOURCE.ID,'')

    RETURN
END
*-----------------------------------------------------------------------------



