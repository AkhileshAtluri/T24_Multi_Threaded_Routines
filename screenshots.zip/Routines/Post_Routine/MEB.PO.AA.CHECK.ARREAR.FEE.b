    SUBROUTINE MEB.PO.AA.CHECK.ARREAR.FEE

*------------------------------------------------------------------------
* Generic Comments    :
*------------------------------------------------------------------------
* Company Name        : ME Bank
* Developer Name      : CAPGEMINI-SUDISH RAMAKRISHNAN
* Subroutine Type     : S
* Attached as         : POST ROUTINE
* Attached to         : LENDING-RAISE-ARREARSFEE with Action = UPDATE & Property = ACCOUNT
* Primary Purpose     : Validate the Loan if it is continuously in Arrears for the last 30 days and
*                                               if it is then the activity LENDING-RAISE-ARREARSFEE is raised to charge the
*                                               arrears fee. Arrears Fee amount is fetched from the AUMB.GENERIC.PARAM record 'HL.ARREAR.FEE'
*------------------------------------------------------------------------
      $INSERT I_COMMON
      $INSERT I_EQUATE
      $INSERT I_AA.LOCAL.COMMON
     $INSERT I_F.AA.ARRANGEMENT
      $INSERT I_AA.APP.COMMON
     $INSERT I_F.AA.ACCOUNT.DETAILS
      $INSERT I_F.AA.ACCOUNT
      $INSERT I_F.AA.ARRANGEMENT.ACTIVITY
     $INSERT I_F.AA.SCHEDULED.ACTIVITY
    $INCLUDE  I_F.AUMB.GENERIC.PARAM
      $INSERT I_F.AA.BILL.DETAILS
      $INSERT I_AA.ACTION.CONTEXT
      $INSERT I_F.AA.PAYMENT.SCHEDULE
      $INSERT I_F.AC.BALANCE.TYPE

    GOSUB CHK.EXIT.CONDN
*       IF NOT(EXIT.FLAG) THEN

    IF EXIT.FLAG THEN
        RETURN
    END

    GOSUB INITIALISE
    GOSUB OPEN.FILES
    GOSUB GET.FEE.WAIVER.PERIOD
    GOSUB GET.CONF.ARREAR.FEE
    GOSUB VALIDATE.ARREARS.COND
    GOSUB RAISE.ARREAR.FEE
*       END

    RETURN
*------------------------------------------------------------------------
CHK.EXIT.CONDN:
*------------------------------------------------------------------------
    EXIT.FLAG = ''

    BEGIN CASE
    CASE c_arrActivityStatus NE 'AUTH'
        EXIT.FLAG = 1
    CASE AA$R.ARRANGEMENT.ACTIVITY<AA.ARR.ACT.REV.MASTER.AAA> NE '' OR AA$R.ARRANGEMENT.ACTIVITY<AA.ARR.ACT.SIM.RUN.REF> NE ''
        EXIT.FLAG = 1
    CASE 1
        ARR.ACTIVITY.ID = c_arrActivityId         ;* Arrangement Activity Id
        R.ACTIVITY = c_arrActivityRec   ;* Arrangement Activity record

        REPLAY.MODE = ''
        CALL AA.CHECK.REPLAY.MODE(ARR.ACTIVITY.ID, R.ACTIVITY, REPLAY.MODE)
        IF REPLAY.MODE THEN
            EXIT.FLAG = 1     ;* No need to Replay
        END
    END CASE

    RETURN
*------------------------------------------------------------------------
INITIALISE:
*------------------------------------------------------------------------
    R.EB.LOOKUP = '' ; LOOKUP.ERR = '' ; AUMB.GEN.PARAM.ID = 'HL.ARREAR.FEE'
    ERR.GEN.PARAM = '' ; GEN.PARAM.TYPE = 'FEE.AMOUNT' ; Y.CHG.AMT.VALUE = ''

    FEEWAIVER.START.POS = '' ; FEEWAIVER.END.POS = '' ; ARREAR.FEE.AMT.POS = ''
    FEE.WAIVER.LT.NAME = 'FEEWAIVER.START':VM:'FEEWAIVER.END':VM:'ARREAR.FEE.AMT'
    FEE.WAIVER.LT.POS = ''

    FEEWAIVER.START = '' ; FEEWAIVER.END = ''
    ARREAR.FEE.AMT = ''
    LAST.FEE.CHRG.DATE = ''

    CALL MULTI.GET.LOC.REF('AA.ARR.ACCOUNT',FEE.WAIVER.LT.NAME,FEE.WAIVER.LT.POS)
    FEEWAIVER.START.POS = FEE.WAIVER.LT.POS<1,1>
    FEEWAIVER.END.POS   = FEE.WAIVER.LT.POS<1,2>
    ARREAR.FEE.AMT.POS = FEE.WAIVER.LT.POS<1,3>

    ARR.ID = c_aalocArrId
    T24.DATE = AA$ACTIVITY.EFF.DATE

    RETURN
*------------------------------------------------------------------------
OPEN.FILES:
*------------------------------------------------------------------------
    FN.AA.ACCOUNT.DETAILS = 'F.AA.ACCOUNT.DETAILS'
    F.AA.ACCOUNT.DETAILS = ''
    CALL OPF(FN.AA.ACCOUNT.DETAILS,F.AA.ACCOUNT.DETAILS)

    FN.AA.ACCOUNT.DETAILS.HIST = 'F.AA.ACCOUNT.DETAILS.HIST'
    F.AA.ACCOUNT.DETAILS.HIST = ''
    CALL OPF(FN.AA.ACCOUNT.DETAILS.HIST, F.AA.ACCOUNT.DETAILS.HIST)

    FN.AA.BILL.DETAILS = 'F.AA.BILL.DETAILS'
    F.AA.BILL.DETAILS = ''
    CALL OPF(FN.AA.BILL.DETAILS, F.AA.BILL.DETAILS)

    FN.AA.BILL.DETAILS.HIST = 'F.AA.BILL.DETAILS.HIST'
    F.AA.BILL.DETAILS.HIST = ''
    CALL OPF(FN.AA.BILL.DETAILS.HIST, F.AA.BILL.DETAILS.HIST)

    FN.AA.SCHE.ACT = 'F.AA.SCHEDULED.ACTIVITY'
    F.AA.SCHE.ACT = ''
    CALL OPF(FN.AA.SCHE.ACT,F.AA.SCHE.ACT)

    FN.AUMB.GENERIC.PARAM = 'F.AUMB.GENERIC.PARAM'
    F.AUMB.GENERIC.PARAM = ''
    CALL OPF(FN.AUMB.GENERIC.PARAM,F.AUMB.GENERIC.PARAM)

    FN.AC.BALANCE.TYPE = 'F.AC.BALANCE.TYPE'
    F.AC.BALANCE.TYPE = ''
    CALL OPF(FN.AC.BALANCE.TYPE, F.AC.BALANCE.TYPE)

    FN.AA.ARRANGEMENT = 'F.AA.ARRANGEMENT'
    F.AA.ARRANGEMENT = ''
    CALL OPF(FN.AA.ARRANGEMENT, F.AA.ARRANGEMENT)

    RETURN
*------------------------------------------------------------------------
GET.FEE.WAIVER.PERIOD:
*------------------------------------------------------------------------
    PROPERTY.RECORD.DET = ''
    PROPERTY.CLASS = 'ACCOUNT'
    PR.IDS = ''
    ERR.COND = ''
    CALL AA.GET.ARRANGEMENT.CONDITIONS(ARR.ID,PROPERTY.CLASS,'','',PR.IDS,PROPERTY.RECORD.DET,ERR.COND)
    PROPERTY.RECORD = RAISE(PROPERTY.RECORD.DET)

    FEEWAIVER.START = PROPERTY.RECORD<AA.AC.LOCAL.REF,FEEWAIVER.START.POS>
    FEEWAIVER.END = PROPERTY.RECORD<AA.AC.LOCAL.REF,FEEWAIVER.END.POS>

    RETURN
*------------------------------------------------------------------------
GET.PAYMENT.SCHEDULE:
*------------------------------------------------------------------------
    PROPERTY.RECORD.DET = '' ; CURR.PYMT.FREQ = ''
    PROPERTY.CLASS = 'PAYMENT.SCHEDULE'
    PR.IDS = ''
    ERR.COND = ''
    CALL AA.GET.ARRANGEMENT.CONDITIONS(ARR.ID,PROPERTY.CLASS,'','',PR.IDS,PROPERTY.RECORD.DET,ERR.COND)
    PYMT.SCHEDULE.REC = RAISE(PROPERTY.RECORD.DET)
    CURR.PYMT.FREQ = PYMT.SCHEDULE.REC<AA.PS.PAYMENT.FREQ,1>

    GOSUB FIND.PYMT.FREQ

    RETURN
*------------------------------------------------------------------------
FIND.PYMT.FREQ:
*------------------------------------------------------------------------
    CHANGE ' ' TO VM IN CURR.PYMT.FREQ
    PYMT.FREQ = '' ; ARRS.CHK.DAYS = ''
    LOOP.FLAG = 1

    LOOP
        REMOVE FREQ.DATA FROM CURR.PYMT.FREQ SETTING F.D.POS
    WHILE (FREQ.DATA : F.D.POS) AND LOOP.FLAG
        IF FREQ.DATA[1,1] EQ 'e' THEN
            FREQ.VAL = FREQ.DATA[2,10]
            FREQ.VAL.CNT = LEN(FREQ.VAL)
            FREQ.TYPE = FREQ.VAL[FREQ.VAL.CNT,1]
            FREQ.VAL.CNT -= 1
            FREQ.FIG = FREQ.VAL[1,FREQ.VAL.CNT]

            GOSUB SET.PYMT.FREQ
        END
    REPEAT

    RETURN
*------------------------------------------------------------------------
SET.PYMT.FREQ:
*------------------------------------------------------------------------
    BEGIN CASE
    CASE FREQ.TYPE EQ 'M' AND FREQ.FIG EQ '1'
        PYMT.FREQ = 'MONTHLY'
        ARRS.CHK.DAYS = '30'
    CASE FREQ.TYPE EQ 'W' AND FREQ.FIG EQ '1'
        PYMT.FREQ = 'WEEKLY'
        ARRS.CHK.DAYS = '33'
    CASE FREQ.TYPE EQ 'W' AND FREQ.FIG EQ '2'
        PYMT.FREQ = 'FORTNIGHTLY'
        ARRS.CHK.DAYS = '33'
    CASE FREQ.TYPE EQ 'D' AND FREQ.FIG EQ '7'
        PYMT.FREQ = 'WEEKLY'
        ARRS.CHK.DAYS = '33'
    CASE FREQ.TYPE EQ 'D' AND FREQ.FIG EQ '14'
        PYMT.FREQ = 'FORTNIGHTLY'
        ARRS.CHK.DAYS = '33'
    END CASE

    IF PYMT.FREQ THEN
        LOOP.FLAG = 0
    END

    RETURN
*------------------------------------------------------------------------
GET.CONF.ARREAR.FEE:
*------------------------------------------------------------------------
    Y.CHG.AMT.VALUE = '' ; SKIP.CHARGING = ''
    CALL F.READ(FN.AUMB.GENERIC.PARAM,AUMB.GEN.PARAM.ID,R.GENERIC.PARAM,F.AUMB.GENERIC.PARAM,ERR.GEN.PARAM)

    LOCATE GEN.PARAM.TYPE IN R.GENERIC.PARAM<GEN.PARM.PARAM.NAME,1> SETTING CHARGE.POS THEN
        Y.CHG.AMT.VALUE = R.GENERIC.PARAM<GEN.PARM.PARAM.VALUE,CHARGE.POS>
    END

    RETURN
*------------------------------------------------------------------------
CHK.FEEWAIVER.PRD:
*------------------------------------------------------------------------
*    IF FEEWAIVER.START AND FEEWAIVER.END THEN
    IF FEEWAIVER.START AND FEEWAIVER.END AND (T24.DATE GE FEEWAIVER.START) AND (T24.DATE LE FEEWAIVER.END) THEN
        Y.CHARGE.AMOUNT = '0'
        SKIP.CHARGING = 'TRUE'
    END

    RETURN
*------------------------------------------------------------------------
VALIDATE.ARREARS.COND:
*------------------------------------------------------------------------
*** If there is Arrears fee suspension configured and the arrangement is within this period then Skip the charging
    GOSUB CHK.FEEWAIVER.PRD
    IF SKIP.CHARGING THEN
        RETURN
    END

*** If the Arrears Amount is less than or equal to Arrears Fee then skip charging
    GOSUB GET.ARREARS.AMT
    IF TOT.ARREARS.AMT AND Y.CHG.AMT.VALUE AND (TOT.ARREARS.AMT LE Y.CHG.AMT.VALUE) THEN
        SKIP.CHARGING = 'TRUE'
        RETURN
    END

    GOSUB GET.PAYMENT.SCHEDULE
    GOSUB GET.ARRS.ST.CHK.DATE

*** Last charge date cannot be less than 28 days - Skip charging
*** CHECK IF THE LOAN HAS BEEN CHARGED ARREARS FEE IN THE LAST 1 MONTH
    DIFF.DAYS = ''
    IF LAST.FEE.CHRG.DATE THEN
        DIFF.DAYS = 'C'
        CALL CDD('',LAST.FEE.CHRG.DATE,T24.DATE,DIFF.DAYS)
        GOSUB SET.SKIP.CHRG.FLAG
    END

*       IF NOT(SKIP.CHARGING) AND (PYMT.FREQ NE 'MONTHLY') THEN
    IF NOT(NOT(SKIP.CHARGING) AND (PYMT.FREQ NE 'MONTHLY')) THEN
        RETURN
    END

    GOSUB READ.ACCT.DETS
    GOSUB READ.ACCT.DETS.HIST
    GOSUB FORM.LIST.OF.BILLS
    GOSUB GET.BILL.PYMT.DATES.LIST
    GOSUB CHK.BILLS.IN.ARREARS
    GOSUB FINALISE.TO.CHARGE
*       END

    RETURN
*------------------------------------------------------------------------
SET.SKIP.CHRG.FLAG:
*------------------------------------------------------------------------
    BEGIN CASE
    CASE NOT(ARRS.FEE.ST.DATE)
        SKIP.CHARGING = ''

    CASE ARRS.FEE.ST.DATE AND (DIFF.DAYS LT '28') AND PYMT.FREQ NE 'MONTHLY'
        SKIP.CHARGING = 'TRUE'
    END CASE

    RETURN
*------------------------------------------------------------------------
FINALISE.TO.CHARGE:
*------------------------------------------------------------------------
    UNSETTLED.FLAG = ''
    LOOP
        REMOVE BILL.ARRS.STS.TMP FROM BILL.ARRS.STS.LIST SETTING B.STS.POS
    WHILE BILL.ARRS.STS.TMP : B.STS.POS AND NOT(UNSETTLED.FLAG)
        IF BILL.ARRS.STS.TMP NE 'SETTLED' THEN
            UNSETTLED.FLAG = 'YES'
        END
    REPEAT

    BEGIN CASE
    CASE PREV.BILL.DATE AND PREV.BILL.STS EQ 'SETTLED'
*** all bills settled so far. so, its a new cycle and has to be charged
        SKIP.CHARGING = ''

    CASE NOT(PREV.BILL.DATE)
*** if this is the very first bill then the loan has to be charged
        SKIP.CHARGING = ''

    CASE NOT(UNSETTLED.FLAG)
*** all bills settled so far. so, its a new cycle and has to be charged
        SKIP.CHARGING = ''

    CASE UNSETTLED.FLAG AND LAST.FEE.CHARGE.DATE

        GOSUB FLAG.ON.LAST.FEE.CHRG

    CASE UNSETTLED.FLAG
        SKIP.CHARGING = ''

    END CASE

    RETURN
*------------------------------------------------------------------------
FLAG.ON.LAST.FEE.CHRG:
*------------------------------------------------------------------------
    CHRG.DIFF.DAYS = 'C'
    CALL CDD('', LAST.FEE.CHARGE.DATE, T24.DATE, CHRG.DIFF.DAYS)
    IF CHRG.DIFF.DAYS GE '28' THEN
        SKIP.CHARGING = ''
    END ELSE
        SKIP.CHARGING = 'YES'
    END

    RETURN
*------------------------------------------------------------------------
CHK.BILLS.IN.ARREARS:
*------------------------------------------------------------------------
    BILL.COUNT = DCOUNT(BILL.FINAL.DATES, VM)
    Y.II = 1

    LOOP
    WHILE Y.II LE BILL.COUNT
        BILL.DUE.DATE = BILL.FINAL.DATES<1,Y.II>
        BILL.SETTLE.DATE = BILL.REPAY.DATE.LIST<1,Y.II>
        BILL.PART.SET.DATE = BILL.PARTIAL.RP.DT.LIST<1,Y.II>

        IF BILL.DUE.DATE THEN
            GOSUB CHK.ALL.DAYS.IN.ARRS
        END

        Y.II += 1
    REPEAT

    RETURN
*------------------------------------------------------------------------
CHK.ALL.DAYS.IN.ARRS:
*------------------------------------------------------------------------
* CHECK IF THE LOAN IS IN ARREARS EACH DAY IF THE PYMT FREQ IS WEEKLY OR FORTNIGHTLY
    IF Y.II EQ 1 THEN
        Y.JJ = ''
        BILL.NXT.DUE.DATE = ''
        BILL.NXT.SETTLE.DATE = ''
        BILL.NXT.PART.SET.DATE = ''
    END ELSE
        Y.JJ = Y.II - 1       ;*** Y.II + 1 BILLS ARE IN DESCENDING ORDER
        BILL.NXT.DUE.DATE = BILL.FINAL.DATES<1,Y.JJ>
        BILL.NXT.SETTLE.DATE = BILL.REPAY.DATE.LIST<1,Y.JJ>
        BILL.NXT.PART.SET.DATE = BILL.PARTIAL.RP.DT.LIST<1,Y.JJ>
    END

    BILL.SETTLE.STS = ''

    IF BILL.NXT.DUE.DATE THEN
*** ASSUME BILL.DUE.DATE is always less than the BILL.NXT.DUE.DATE as per the PAYMENT.SCHEDULE
        BEGIN CASE
        CASE BILL.SETTLE.DATE AND BILL.SETTLE.DATE GE BILL.DUE.DATE AND BILL.SETTLE.DATE LT BILL.NXT.DUE.DATE
*** BILL settled before the NEXT BILL GENERATION
            BILL.SETTLE.STS = 'SETTLED'
        CASE BILL.SETTLE.DATE AND BILL.SETTLE.DATE GE BILL.DUE.DATE AND BILL.SETTLE.DATE GE BILL.NXT.DUE.DATE
*** BILL settled after the NEXT BILL WAS GENERATED
            BILL.SETTLE.STS = 'ARREARS'
        CASE NOT(BILL.SETTLE.DATE)
*** BILL UNSETTLED TILL NOW
            BILL.SETTLE.STS = 'ARREARS'
*** CHECK FOR PARTIAL SETTLEMENT IF ANY
        CASE 1
            BILL.SETTLE.STS = 'ARREARS'
        END CASE
    END ELSE
*** This is specifically for the current bill from the LENDING-AGE-OVERDUE*OVD*PAYMENT
        BEGIN CASE
        CASE NOT(BILL.SETTLE.DATE)
*** BILL UNSETTLED TILL NOW
            BILL.SETTLE.STS = 'ARREARS'
*** CHECK FOR PARTIAL SETTLEMENT IF ANY
        CASE 1
            BILL.SETTLE.STS = 'ARREARS'
        END CASE
    END

    BILL.ARRS.STS.LIST<1,-1> = BILL.SETTLE.STS
    IF PREV.BILL.DATE AND (PREV.BILL.DATE EQ BILL.DUE.DATE) THEN
        PREV.BILL.STS = BILL.SETTLE.STS
    END

    RETURN
*------------------------------------------------------------------------
ADD.TO.BILL.LIST:
*------------------------------------------------------------------------
    Y.AAD = 1
    LOOP
    WHILE Y.AAD LE AAD.TMP.BILL.COUNT
        BILL.REF.ID = AAD.TMP.BILL.LIST<1,Y.AAD>

        LOCATE BILL.REF.ID IN AAD.BILL.LIST<1,1> SETTING BL.POS ELSE
            AAD.BILL.LIST<1,-1> = BILL.REF.ID
            AAD.BILL.DATES<1,-1> = AAD.TMP.BILL.DATES<1,Y.AAD>
            AAD.BILL.TYPES<1,-1> = AAD.TMP.BILL.TYPES<1,Y.AAD>
        END
        Y.AAD += 1
    REPEAT

    RETURN
*------------------------------------------------------------------------
FORM.LIST.OF.BILLS:
*------------------------------------------------------------------------
    AAD.BILL.LIST = '' ; AAD.BILL.DATES = '' ; AAD.BILL.TYPES = ''
    AAD.TMP.BILL.LIST = '' ; AAD.TMP.BILL.DATES = '' ; AAD.TMP.BILL.TYPES = ''
    AAD.TMP.BILL.COUNT = ''

    AAD.TMP.BILL.LIST = R.ACCT.DETS<AA.AD.BILL.ID>
    AAD.TMP.BILL.DATES = R.ACCT.DETS<AA.AD.BILL.PAY.DATE>
    AAD.TMP.BILL.TYPES = R.ACCT.DETS<AA.AD.BILL.TYPE>
    AAD.TMP.BILL.COUNT = DCOUNT(AAD.TMP.BILL.DATES,VM)

    IF R.ACCT.DETS.HIST<AA.AD.BILL.ID> THEN
*** Data & Dates are in the Ascending order with latest bills listed at the end
        AAD.BILL.LIST = R.ACCT.DETS.HIST<AA.AD.BILL.ID>     ;***  : VM : AAD.BILL.LIST
        AAD.BILL.DATES = R.ACCT.DETS.HIST<AA.AD.BILL.PAY.DATE>        ;*** : VM : AAD.BILL.DATES
        AAD.BILL.TYPES = R.ACCT.DETS.HIST<AA.AD.BILL.TYPE>  ;*** : VM : AAD.BILL.TYPES
    END

    IF AAD.BILL.LIST THEN     ;*** if there are bills in AA.ACCOUNT.DETAILS.HIST
        GOSUB ADD.TO.BILL.LIST
    END ELSE
        AAD.BILL.LIST = AAD.TMP.BILL.LIST
        AAD.BILL.DATES = AAD.TMP.BILL.DATES
        AAD.BILL.TYPES = AAD.TMP.BILL.TYPES
    END

    RETURN
*------------------------------------------------------------------------
GET.BILL.PYMT.DATES.LIST:
*------------------------------------------------------------------------

    BILL.FINAL.DATES = '' ; BILL.FINAL.ID.LIST = ''
    BILL.REPAY.DATE.LIST = '' ; BILL.PARTIAL.RP.DT.LIST = ''
    BILL.ID = '' ; BILL.DATE = ''
    BILL.LOOP = ''
    BILL.ARRS.STS.LIST = ''
    TOTAL.BILL.COUNT = ''
    TOTAL.BILL.COUNT = DCOUNT(AAD.BILL.DATES,VM)

    LAST.FEE.CHARGE.DATE = '' ; PREV.BILL.DATE = '' ; PREV.BILL.STS = ''
    CURR.BILL.DATE = ''

    Y.BB = TOTAL.BILL.COUNT
    LOOP
    WHILE (Y.BB GE 1) AND NOT(BILL.LOOP)
        BILL.ID = AAD.BILL.LIST<1,Y.BB>
        BILL.DATE = AAD.BILL.DATES<1,Y.BB>
        BILL.TYPE = AAD.BILL.TYPES<1,Y.BB>

        GOSUB GROUP.BILL.DATES
        Y.BB -= 1
    REPEAT

    RETURN
*------------------------------------------------------------------------
GROUP.BILL.DATES:
*------------------------------------------------------------------------
    BEGIN CASE
    CASE BILL.DATE AND BILL.DATE LT ARRS.FEE.ST.DATE        ;*** Skip Bills older than 30 to 35 days
        BILL.LOOP = 1
    CASE (BILL.TYPE EQ 'ACT.CHARGE') AND NOT(LAST.FEE.CHARGE.DATE)
*** If the bill type is a CHARGE and its MISS PAYMENT FEE then get the latest CHARGE DATE
        GOSUB READ.BILL
        IF R.BILL.DETS<AA.BD.PROPERTY,1> EQ 'MISSPAYMTFEE' THEN
            LAST.FEE.CHARGE.DATE = BILL.DATE
        END
    CASE BILL.TYPE NE 'PAYMENT'
*** Skip this bill
    CASE BILL.DATE GE ARRS.FEE.ST.DATE AND BILL.DATE LT T24.DATE
        BILL.FINAL.ID.LIST<1,-1> = BILL.ID
        BILL.FINAL.DATES<1,-1> = BILL.DATE
        GOSUB SET.CUR.PRV.BL.DATES

        GOSUB READ.BILL
        IF R.BILL.DETS THEN
            GOSUB GET.REPAY.DATE
        END

        GOSUB SET.PART.RPY.DATES
    END CASE

    RETURN
*------------------------------------------------------------------------
SET.PART.RPY.DATES:
*------------------------------------------------------------------------
    IF BILL.REPAY.DATE THEN
        BILL.REPAY.DATE.LIST<1,-1> = BILL.REPAY.DATE
    END ELSE
        BILL.REPAY.DATE.LIST<1,-1> = ' ' ; *** SPACE inserted to form the array
    END
    IF BILL.PARTIAL.RP.DATE THEN
        BILL.PARTIAL.RP.DT.LIST<1,-1> = BILL.PARTIAL.RP.DATE
    END ELSE
        BILL.PARTIAL.RP.DT.LIST<1,-1> = ' ' ; *** SPACE inserted to form the array
    END

    RETURN
*------------------------------------------------------------------------
SET.CUR.PRV.BL.DATES:
*------------------------------------------------------------------------
    IF NOT(CURR.BILL.DATE) THEN
        CURR.BILL.DATE = BILL.DATE
    END
    ELSE IF NOT(PREV.BILL.DATE) AND CURR.BILL.DATE THEN
        PREV.BILL.DATE = BILL.DATE
    END

    RETURN
*------------------------------------------------------------------------
READ.BILL:
*------------------------------------------------------------------------
    BILL.OUTS.AMT = '' ; BILL.REPAY.DATE = '' ; BILL.PARTIAL.RP.DATE = ''
    R.BILL.DETS = '' ; BILL.ERR = ''

    CALL F.READ(FN.AA.BILL.DETAILS, BILL.ID, R.BILL.DETS, F.AA.BILL.DETAILS, BILL.ERR)
    IF NOT(R.BILL.DETS) THEN
        CALL F.READ(FN.AA.BILL.DETAILS.HIST, BILL.ID, R.BILL.DETS, F.AA.BILL.DETAILS.HIST, BILL.ERR)
    END

    RETURN
*------------------------------------------------------------------------
GET.REPAY.DATE:
*------------------------------------------------------------------------
*       IF R.BILL.DETS THEN
    BILL.OUTS.AMT = R.BILL.DETS<AA.BD.OS.TOTAL.AMOUNT>
    IF BILL.OUTS.AMT THEN     ;*** BILL IS UNSETTLED
        GOSUB GET.PARTIAL.REPAY.DT
    END
    ELSE IF NOT(BILL.OUTS.AMT) THEN     ;*** BILL IS SETTLED
        LOCATE 'REPAID' IN R.BILL.DETS<AA.BD.SETTLE.STATUS,1> SETTING BD.STL.POS THEN
            BILL.REPAY.DATE = R.BILL.DETS<AA.BD.SET.ST.CHG.DT,BD.STL.POS>
        END ELSE
            GOSUB GET.PARTIAL.REPAY.DT
        END
    END
*       END

    RETURN
*------------------------------------------------------------------------
GET.PARTIAL.REPAY.DT:
*------------------------------------------------------------------------
    REPAY.REF.LIST = ''
    REPAY.REF.LIST = R.BILL.DETS<AA.BD.REPAY.REF>

    LOOP
        REMOVE REPAY.REF FROM REPAY.REF.LIST SETTING REPAY.POS
    WHILE REPAY.REF : REPAY.POS
        REPAY.DATE = REPAY.REF['-',2,1]
        IF REPAY.DATE THEN
            GOSUB GET.BILL.REPAY.DATE
        END
    REPEAT

    RETURN
*------------------------------------------------------------------------
GET.BILL.REPAY.DATE:
*------------------------------------------------------------------------
    IF BILL.PARTIAL.RP.DATE THEN
        IF REPAY.DATE GT BILL.PARTIAL.RP.DATE THEN
            BILL.PARTIAL.RP.DATE = REPAY.DATE
        END
    END ELSE
        BILL.PARTIAL.RP.DATE = REPAY.DATE
    END

    RETURN
*------------------------------------------------------------------------
GET.ARRS.ST.CHK.DATE:
*------------------------------------------------------------------------
    ARRS.FEE.ST.DATE = T24.DATE
    BEGIN CASE
    CASE PYMT.FREQ EQ 'MONTHLY'
        ARRS.DAY = ARRS.FEE.ST.DATE[7,2]
        IF ARRS.FEE.ST.DATE[5,2] EQ '01' THEN
            ARRS.YR = ARRS.FEE.ST.DATE[1,4] - 1
            ARRS.FEE.ST.DATE = ARRS.YR : '12' : ARRS.DAY
        END ELSE
            ARRS.MTH = ARRS.FEE.ST.DATE[5,2] - 1
            ARRS.FEE.ST.DATE = ARRS.FEE.ST.DATE[1,4] : ARRS.MTH : ARRS.DAY
        END

    CASE ARRS.CHK.DAYS EQ '33'
        CALL CDT('',ARRS.FEE.ST.DATE,'-33C')
    CASE 1
        CALL CDT('',ARRS.FEE.ST.DATE,'-33C')
    END CASE

    IF ARRS.FEE.ST.DATE AND (ARRS.FEE.ST.DATE LE AA$R.ARRANGEMENT<AA.ARR.START.DATE>) THEN
        ARRS.FEE.ST.DATE = AA$R.ARRANGEMENT<AA.ARR.START.DATE>
    END

    RETURN
*------------------------------------------------------------------------
GET.ARREARS.AMT:
*------------------------------------------------------------------------
    TOT.ARREARS.AMT = '' ; REPYMT.BAL.TYPE = 'TOTALDUE'
    REQUEST.DATE = T24.DATE
    REQUEST.TYPE = ''
    CURCOMMIT.BAL = ''
    AC.BALANCE.LIST = '' ; R.AC.BALANCE.TYPE = ''

    AC.BAL.ERR = ''
    CALL F.READ(FN.AC.BALANCE.TYPE, REPYMT.BAL.TYPE, R.AC.BALANCE.TYPE, F.AC.BALANCE.TYPE, AC.BAL.ERR)

    ACCOUNT.ID = '' ; R.AA.ARR = '' ; ARR.ERR = ''
    CALL F.READ(FN.AA.ARRANGEMENT, ARR.ID, R.AA.ARR, F.AA.ARRANGEMENT, ARR.ERR)
    LOCATE 'ACCOUNT' IN R.AA.ARR<AA.ARR.LINKED.APPL,1> SETTING ARR.LK.POS THEN
        ACCOUNT.ID = R.AA.ARR<AA.ARR.LINKED.APPL.ID,ARR.LK.POS>
    END ELSE
        ACCOUNT.ID = R.AA.ARR<AA.ARR.LINKED.APPL.ID,1>
    END

    AC.BALANCE.LIST = R.AC.BALANCE.TYPE<AC.BT.VIRTUAL.BAL>
    LOOP
        REMOVE AC.BAL.SUB.ID FROM AC.BALANCE.LIST SETTING AC.BAL.S.POS
    WHILE AC.BAL.SUB.ID : AC.BAL.S.POS
        GOSUB GET.SUB.BALANCE
    REPEAT

    TOT.ARREARS.AMT = ABS(TOT.ARREARS.AMT)

    RETURN

GET.SUB.BALANCE:
*-----------------------------------------------------------------------------
    BALANCE.DETAILS = ''
    CALL AA.GET.PERIOD.BALANCES(ACCOUNT.ID,AC.BAL.SUB.ID,REQUEST.TYPE,REQUEST.DATE,'','',BALANCE.DETAILS,'')

    TOT.ARREARS.AMT += BALANCE.DETAILS<4>

    RETURN
*------------------------------------------------------------------------
READ.ACCT.DETS:
*------------------------------------------------------------------------
    R.ACCT.DETS = '' ; ACCT.DETS.ERR = ''
    CALL F.READ(FN.AA.ACCOUNT.DETAILS, ARR.ID, R.ACCT.DETS, F.AA.ACCOUNT.DETAILS, ACCT.DETS.ERR)

    RETURN
*------------------------------------------------------------------------
READ.ACCT.DETS.HIST:
*------------------------------------------------------------------------
    R.ACCT.DETS.HIST = '' ; ACCT.DETS.HIST.ERR = ''
    CALL F.READ(FN.AA.ACCOUNT.DETAILS.HIST, ARR.ID, R.ACCT.DETS.HIST, F.AA.ACCOUNT.DETAILS.HIST, ACCT.DETS.HIST.ERR)

    RETURN
*------------------------------------------------------------------------
RAISE.ARREAR.FEE:
*------------------------------------------------------------------------
    IF NOT(SKIP.CHARGING) THEN
        GOSUB POST.OFS.MESSAGE
    END

    RETURN
*------------------------------------------------------------------------
POST.OFS.MESSAGE:
*------------------------------------------------------------------------
    APP.NAME = 'AA.ARRANGEMENT.ACTIVITY'
    PROCESS = 'PROCESS'
    OFS.VERSION = 'AA.ARRANGEMENT.ACTIVITY,ZERO.AUTH'
    OFS.FUNCTION = 'I'
    GTS.MODE = ''
    NO.OF.AUTH = '0'
    TRANSACTION.ID = ''
    OFS.MESSAGE = ''
    OFS.SOURCE.ID = 'HL.ARREAR.FEE'

    ARR.FIELD.NAME.LIST = "LOCAL.REF:":ARREAR.FEE.AMT.POS:":1"
    ARR.FIELD.VALUE.LIST = Y.CHG.AMT.VALUE
    OFS.AA.ACTIVITY = 'LENDING-RAISE-ARREARSFEE'

    R.APP.RECORD = ''
    R.APP.RECORD<AA.ARR.ACT.ARRANGEMENT> = ARR.ID
    R.APP.RECORD<AA.ARR.ACT.ACTIVITY> = OFS.AA.ACTIVITY
    R.APP.RECORD<AA.ARR.ACT.EFFECTIVE.DATE> = AA$ACTIVITY.EFF.DATE
    R.APP.RECORD<AA.ARR.ACT.CUSTOMER> = AA$R.ARRANGEMENT<AA.ARR.CUSTOMER>
    R.APP.RECORD<AA.ARR.ACT.CURRENCY> = AA$R.ARRANGEMENT<AA.ARR.CURRENCY>
    R.APP.RECORD<AA.ARR.ACT.PROPERTY> = 'ACCOUNT'
    R.APP.RECORD<AA.ARR.ACT.FIELD.NAME,1,1> = ARR.FIELD.NAME.LIST
    R.APP.RECORD<AA.ARR.ACT.FIELD.VALUE,1,1> = ARR.FIELD.VALUE.LIST

    CALL OFS.BUILD.RECORD(APP.NAME,OFS.FUNCTION,PROCESS,OFS.VERSION,GTS.MODE,NO.OF.AUTH,TRANSACTION.ID,R.APP.RECORD,OFS.MESSAGE)
    RET.ID = ''
    CALL OFS.POST.MESSAGE(OFS.MESSAGE,RET.ID,OFS.SOURCE.ID,'')

    RETURN
END

