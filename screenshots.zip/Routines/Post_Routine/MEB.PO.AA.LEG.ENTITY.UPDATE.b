*-----------------------------------------------------------------------------
* <Rating>-23</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE MEB.PO.AA.LEG.ENTITY.UPDATE
*-----------------------------------------------------------------------------
* Developed By : Capgemini pvt ltd
* Purpose      : Routine to capture the Entity Update details such as From Entity, To Entity, and Transferred Date.
* Date         :  23/10/2017
* Attached to  : ACTIVITY.API condition for LENDING product.
* Attached as  : Post Routine for activity>LENDING-UPDATE-LEGAL.ENTITY
*--------------------------------------------------------------------------------------------
* Modification History
*------------------------------------------------------------------------------------------------
* Date             Modified by              Reference        Description
******************************************************************************************
* 27th Nov 2018    Shakila N                SPRR-1002        Effective date is not updated in MEB.PO.AA.LEG.ENTITY.UPDATE if the record is already exist.
*
*---------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.AA.ACCOUNT
    $INSERT I_AA.APP.COMMON
    $INSERT I_AA.LOCAL.COMMON
    $INSERT I_F.AA.ACTIVITY.HISTORY
    $INSERT I_AA.ACTION.CONTEXT
    $INSERT I_F.AA.ARRANGEMENT
    $INSERT I_F.AA.ARRANGEMENT.ACTIVITY
    $INSERT I_F.MEB.L.LEGAL.ENTITY.UPDATE

    IF c_arrActivityStatus NE 'AUTH' THEN
        RETURN
    END

    IF AA$R.ARRANGEMENT.ACTIVITY<AA.ARR.ACT.REV.MASTER.AAA> NE '' OR AA$R.ARRANGEMENT.ACTIVITY<AA.ARR.ACT.SIM.RUN.REF> NE '' THEN
        RETURN
    END
    ARR.ACTIVITY.ID = c_arrActivityId   ;* Arrangement Activity Id
    R.ACTIVITY = c_arrActivityRec       ;* Arrangement Activity record.
    REPLAY.MODE = ''

    CALL AA.CHECK.REPLAY.MODE(ARR.ACTIVITY.ID, R.ACTIVITY, REPLAY.MODE)
    IF REPLAY.MODE THEN
        RETURN      ;* No need to Replay
    END


    GOSUB INIT
    GOSUB PROCESS

    RETURN
*-----------------------------------------------------------------------------
INIT:
*-----------------------------------------------------------------------------
    LOC.REF.APPLICATION = "AA.PRD.DES.ACCOUNT":FM:"ACCOUNT"
    LOC.REF.FIELDS= 'LEGAL.ENTITY':FM:'LEGAL.ENTITY'
    LOC.REF.POS = ''
    CALL MULTI.GET.LOC.REF(LOC.REF.APPLICATION,LOC.REF.FIELDS,LOC.REF.POS)

    LEGAL.ENT.POS = ''
    LEGAL.ENT.POS = LOC.REF.POS<1,1>
    LEGAL.ENT.ACC.POS = LOC.REF.POS<2,1>

    FN.ACCOUNT='F.ACCOUNT'
    F.ACCOUNT=''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.MEB.L.LEGAL.ENTITY.UPDATE = 'F.MEB.L.LEGAL.ENTITY.UPDATE'
    F.MEB.L.LEGAL.ENTITY.UPDATE = ''
    CALL OPF(FN.MEB.L.LEGAL.ENTITY.UPDATE,F.MEB.L.LEGAL.ENTITY.UPDATE)

    RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-----------------------------------------------------------------------------

    CURR.ACTIVITY  = c_aalocActivityId
    ARRANGEMENT.ID = c_aalocArrId
    AA.ARR.ACT.ID  = c_aalocArrActivityId
    EFFECTIVE.DATE = c_aalocActivityEffDate

    LEGAL.ENT.VAL = R.NEW(AA.AC.LOCAL.REF)<1,LEGAL.ENT.POS>
    ID.ACCOUNT=AA$LINKED.ACCOUNT
    CALL F.READ(FN.ACCOUNT,ID.ACCOUNT,R.ACCOUNT,F.ACCOUNT,E.ACCOUNT)

    LEGAL.ENT.VAL.OLD = R.ACCOUNT<AC.LOCAL.REF,LEGAL.ENT.ACC.POS>

    CONCAT.ID= ARRANGEMENT.ID:'-':LEGAL.ENT.VAL.OLD:'-':LEGAL.ENT.VAL
    R.MEB.L.LEGAL.ENTITY.UPDATE = '';LEG.ERR = ''
    CALL F.READ(FN.MEB.L.LEGAL.ENTITY.UPDATE,CONCAT.ID,R.MEB.L.LEGAL.ENTITY.UPDATE,F.MEB.L.LEGAL.ENTITY.UPDATE,LEG.ERR)
    IF R.MEB.L.LEGAL.ENTITY.UPDATE EQ '' THEN
        R.MEB.L.LEGAL.ENTITY.UPDATE<MEB.LEG.ENT.TRANSFERRED.DATE> = EFFECTIVE.DATE
*        CALL F.WRITE(FN.MEB.L.LEGAL.ENTITY.UPDATE,CONCAT.ID,R.MEB.L.LEGAL.ENTITY.UPDATE)
        WRITE R.MEB.L.LEGAL.ENTITY.UPDATE TO F.MEB.L.LEGAL.ENTITY.UPDATE,CONCAT.ID
    END ELSE
        R.MEB.L.LEGAL.ENTITY.UPDATE<MEB.LEG.ENT.TRANSFERRED.DATE> = EFFECTIVE.DATE        ;* Added for SPRR-1002
        WRITE R.MEB.L.LEGAL.ENTITY.UPDATE TO F.MEB.L.LEGAL.ENTITY.UPDATE,CONCAT.ID        ;* Added for SPRR-1002
    END   ;* Added for SPRR-1002
    RETURN
*-------------------------------------------------------------------------------------------
END



