    SUBROUTINE MEB.PO.AA.OSA.BONUS.UPD
*-------------------------------------------------------------------------
* Developed By    : Capgemini India Pvt Ltd
* Program Name    : MEB.PO.AA.OSA.BONUS.UPD
* Purpose         : The routine updates the MEB.L.OSA.BONUS.TODAY table which will be processed by Pre COB job
*                   to apply the bonus interest
*-------------------------------------------------------------------------
* Subroutine Type : S
* Attached To     : AA.PRD.DES.ACTIVITY.API>ACCOUNTS.OSA
* Attached As     : Post Routine
* In Parameter    : -NA-
* Out Parameter   : -NA-
*-------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date:         Reference              Developed By    Change Description
* 27-Feb-19     SPT1-1603              Anand           Initial draft
* 26-Mar-19     SPT1-1945              Deepti          To update the Bonus interest eligibility value
*                                                      for new OSA accounts.
* 04-Apr-19     SPT1-2297              Deepti          updation of Bonus eligibility value to new OSA accounts
*                                                      only if value is null.
* 13-Aug-19     PPDC-118               Anand           Blocking of reversal of the activity ACCOUNTS-UPDATE-BONUS.ELIGIBILITY
*UPCHANGE - Sangeetha - 20191030 - INCLUDE commented,INSERT added
*-------------------------------------------------------------------------
*START-UPCHANGE(20191030)
  *  $INCLUDE ../T24_BP I_COMMON
  *  $INCLUDE ../T24_BP I_EQUATE
  *  $INCLUDE ../T24_BP I_AA.APP.COMMON
  *  $INCLUDE ../T24_BP I_AA.LOCAL.COMMON
  *  $INCLUDE ../T24_BP I_AA.ACTION.CONTEXT
  *  $INCLUDE ../T24_BP I_F.AA.ARRANGEMENT
  *  $INCLUDE ../T24_BP I_F.AA.ARRANGEMENT.ACTIVITY
  *  $INCLUDE ../T24_BP I_F.AA.INTEREST
  *  $INCLUDE ME.BP I_F.MEB.L.OSA.BONUS.TODAY
  *  $INCLUDE ME.BP I_F.MEB.H.OSA.BONUS.INT.PARAM
  *  $INCLUDE ../T24_BP I_F.EB.LOOKUP
  *  $INCLUDE ../T24_BP I_F.USER
  $INSERT I_COMMON
  $INSERT I_EQUATE
  $INSERT I_AA.APP.COMMON
  $INSERT I_AA.LOCAL.COMMON
  $INSERT I_AA.ACTION.CONTEXT
  $INSERT I_F.AA.ARRANGEMENT
  $INSERT I_F.AA.ARRANGEMENT.ACTIVITY
  $INSERT I_F.AA.INTEREST
  $INSERT I_F.MEB.L.OSA.BONUS.TODAY
  $INSERT I_F.MEB.H.OSA.BONUS.INT.PARAM
  $INSERT I_F.EB.LOOKUP
  $INSERT I_F.USER
*END-UPCHANGE(20191030)

*-------------------------------------------------------------------------

* PPDC-118 - Start
    IF c_arrActivityStatus EQ 'REVERSE' THEN
        GOSUB INIT
        GOSUB OPEN.FILES
        GOSUB VALIDATE.REVERSAL
    END
* PPDC-118 - End
    IF AA$R.ARRANGEMENT.ACTIVITY<AA.ARR.ACT.REV.MASTER.AAA> NE '' OR AA$R.ARRANGEMENT.ACTIVITY<AA.ARR.ACT.SIM.RUN.REF> NE '' THEN
        RETURN
    END

    GOSUB INIT
    GOSUB OPEN.FILES

    IF c_arrActivityStatus NE 'AUTH' THEN
** SPT1-1945 --START

        GOSUB BONUS.ELIGIBLE

    END ELSE

        GOSUB PROCESS
    END
** SPT1-1945 --END

    RETURN
*-------------------------------------------------------------------------
INIT:
*****
    APPLN.NAME = 'AA.ARR.INTEREST'
    LOC.FLD.NAME = 'MEB.BONUS.ELGBL'
    LOC.FLD.POS = ''
    CALL MULTI.GET.LOC.REF(APPLN.NAME,LOC.FLD.NAME,LOC.FLD.POS)
    MEB.BONUS.ELGBL.POS = LOC.FLD.POS<1,1>

    RETURN
*-------------------------------------------------------------------------
OPEN.FILES:
***********
    FN.MEB.L.OSA.BONUS.TODAY = 'F.MEB.L.OSA.BONUS.TODAY'
    F.MEB.L.OSA.BONUS.TODAY = ''
    CALL OPF(FN.MEB.L.OSA.BONUS.TODAY,F.MEB.L.OSA.BONUS.TODAY)

* PPDC-118 - Start

    FN.EB.LOOKUP = 'F.EB.LOOKUP'
    F.EB.LOOKUP = ''
    CALL OPF(FN.EB.LOOKUP,F.EB.LOOKUP)

    FN.USER = 'F.USER'
    F.USER = ''
    CALL OPF(FN.USER,F.USER)

* PPDC-118 - End
    RETURN
*-------------------------------------------------------------------------
PROCESS:
********
    IF R.NEW(AA.INT.LOCAL.REF)<1,MEB.BONUS.ELGBL.POS> NE '' AND R.NEW(AA.INT.LOCAL.REF)<1,MEB.BONUS.ELGBL.POS> NE 'NOT.ELIGIBLE' THEN
        MEB.L.OSA.BONUS.TODAY.ID = 'OSA.':c_aalocArrangementRec<AA.ARR.LINKED.APPL.ID>
        R.MEB.L.OSA.BONUS.TODAY<OSA.BONUS.TODAY.RATE.EFF.DATE> = c_aalocArrActivityRec<AA.ARR.ACT.EFFECTIVE.DATE>
        CALL F.WRITE(FN.MEB.L.OSA.BONUS.TODAY,MEB.L.OSA.BONUS.TODAY.ID,R.MEB.L.OSA.BONUS.TODAY)
    END
    RETURN
*--------------------------------------------------------------------------
BONUS.ELIGIBLE:
****************
    PARAM.ID = 'SYSTEM'
    CALL MEB.S.GET.OSA.BONUS.PARAM(PARAM.ID,R.MEB.H.OSA.BONUS.INT.PARAM)
    BONUS.ELGBL = R.MEB.H.OSA.BONUS.INT.PARAM<OSA.BONUS.BONUS.ELIGIBILITY>
** SPT1-2297 -start
    IF c_aalocCurrActivity EQ 'ACCOUNTS-NEW-ARRANGEMENT' THEN

        R.NEW(AA.INT.LOCAL.REF)<1,MEB.BONUS.ELGBL.POS> = BONUS.ELGBL
    END
** SPT1-2297 -end

    RETURN
*-------------------------------------------------------------------------
VALIDATE.REVERSAL:
******************
    USER.ID = OPERATOR
    R.USER.REC = ''
    CALL F.READ(FN.USER,USER.ID,R.USER.REC,F.USER,USER.ERR)
    USER.ROLES = CHANGE(R.USER.REC<EB.USE.USER.ROLES>,SM,FM)

    IF USER.ROLES EQ '' THEN
        RETURN
    END

    EB.LOOKUP.ID = 'MEB.ALLOWED.USER*ROLES'
    R.EB.LOOKUP = ''
    EB.LOOKUP.ERR = ''
    CALL F.READ(FN.EB.LOOKUP,EB.LOOKUP.ID,R.EB.LOOKUP,F.EB.LOOKUP,EB.LOOKUP.ERR)
    ROLE.VALUE = CHANGE(R.EB.LOOKUP<EB.LU.DATA.VALUE>,VM,FM)
    LOOP
        REMOVE ROLE.ID FROM USER.ROLES SETTING POS
    WHILE ROLE.ID:POS
        LOCATE ROLE.ID IN ROLE.VALUE SETTING ROLE.POS ELSE
            AF = AA.INT.LOCAL.REF
            AV = MEB.BONUS.ELGBL.POS
            ETEXT = 'EB-SECURITY.VIOLATION.5'
            CALL STORE.END.ERROR
        END
    REPEAT

    RETURN
*-------------------------------------------------------------------------
END
*-------------------------------------------------------------------------














