    SUBROUTINE MEB.PO.AA.NEW.ARR.EVENT
*-----------------------------------------------------------------------------------------------------------------
*Description :
*---------------
*
*Date                   : 14 NOV 2019
*Development Ref        : Event trigger conditions for account activity
*Author                 : Suresh Poojary
*Type of the Routine    : Post routine
*Attached to            : ACCOUNTS-NEW-ARRANGEMENT
*Purpose                : This routine is used to update the staging Table "MEB.H.ACCT.EVENT.CAPTURE" and trigger the events.
*----------------------------------------------------------------------------------------------------------------
*Arguments :
*----------------
*Incoming           : N.A
*Outgoing           : N.A
*----------------------------------------------------------------------------
*
*-------------------------------------------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date:          Reference:                     Developed By:            Description:
* 06-DEC-2019    Defect fixes                   Suresh P                 NPP-1743 and NPP-1746.
* 20-FEB-2020    UPGCHANGE                      N D MANAVI               Replaced the MEB.COMMON.PARM to AUMB.COMMON.PARAM   
* 12-Feb-2020    Defect fixes NPP-2145          Suresh P                 Excluding TD Deposit wholesale products
* 16-Mar-2020    PL2-5212                       Suresh P                 Include PL Account Open Activity 
*-----------------------------------------------------------------------------------------------------------
*--------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_AA.APP.COMMON
    $INSERT I_AA.LOCAL.COMMON
    $INSERT I_F.ACCOUNT
    $INSERT I_F.AA.ARRANGEMENT
    $INSERT I_F.AA.ARRANGEMENT.ACTIVITY
    $INSERT I_F.AA.ACCOUNT
    $INSERT I_F.ACCOUNT.CLASS
    $INSERT I_F.CUSTOMER
    $INSERT I_System
    $INSERT I_F.MEB.H.ACCT.EVENT.CAPTURE
    $INSERT I_F.AUMB.COMMON.PARAM

    GOSUB INIT
    GOSUB OPENFILES
    GOSUB PROCESS
    RETURN

INIT:
*In this GOSUB we are intialising neccessary variables
*-------------------------------------------------------
    Y.AA.ID = AA$ARR.ID
    Y.PROCESS = c_aalocActivityStatus
    R.OFS.EVT.REC = ''
    Y.ACC.CLASS.ID.1 = 'U-CORPORATE'
    Y.ACC.CLASS.ID.2 = 'U-INDIVIDUAL'
    Y.PRD.GROUP = ''

    RETURN


*----------------------------------------------------------------------------------------------------------------------------
OPENFILES:
***********

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.ACCOUNT.CLASS = 'F.ACCOUNT.CLASS'
    F.ACCOUNT.CLASS = ''
    CALL OPF(FN.ACCOUNT.CLASS, F.ACCOUNT.CLASS)

    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ''
    CALL OPF(FN.CUSTOMER, F.CUSTOMER)

    FN.AUMB.COMMON.PARAM = 'F.AUMB.COMMON.PARAM'
    F.AUMB.COMMON.PARAM= ''
    CALL OPF(FN.AUMB.COMMON.PARAM,F.AUMB.COMMON.PARAM)

    RETURN

*----------------------------------------------------------
PROCESS:
*----------------------------------------------------------
    IF Y.PROCESS EQ 'AUTH' THEN
        Y.AA.REC = AA$R.ARRANGEMENT
        Y.LINKED.APPL =Y.AA.REC<AA.ARR.LINKED.APPL>
        Y.LINKED.APPL.ID = Y.AA.REC<AA.ARR.LINKED.APPL.ID>
        Y.ACC.NUMBER = Y.AA.REC<AA.ARR.LINKED.APPL.ID>

        Y.POST.RST = R.NEW(AA.AC.POSTING.RESTRICT)
*S - NPP-2145
        Y.PRD.GROUP = Y.AA.REC<AA.ARR.PRODUCT.GROUP>
        IF Y.PRD.GROUP NE 'TERM.DEPOSITS.WHOLESALE' THEN
            GOSUB FORM.PAYLOAD
        END
*E - NPP-2145
    END
    RETURN

*--------------------------------------------------------------
FORM.PAYLOAD:
* Form the payload required to post the event.
*---------------------------------------------------------------

*    Y.ARR.STATUS = Y.AA.REC<AA.ARR.ARR.STATUS>
    Y.ARR.STATUS = "AUTH"

* S - E Defect NPP-1746
*    Y.ARR.PRD = Y.AA.REC<AA.ARR.PRODUCT>
    Y.ARR.PRD = Y.AA.REC<AA.ARR.PRODUCT><1,1>
* E - Defect NPP-1746

    IF Y.ARR.PRD EQ 'OSA.RETAIL.NONMEMBER' OR Y.ARR.PRD EQ 'TRANS.ACCOUNT' OR Y.ARR.PRD EQ 'IMSA.ACCOUNT' OR Y.ARR.PRD EQ 'OSA.BUSINESS' THEN
        Y.PRODUCT.AVAIL = "Y"
    END ELSE
        Y.PRODUCT.AVAIL = "N"
    END


    Y.COM.PARAM.ID = 'AU0010001'
    CALL F.READ(FN.AUMB.COMMON.PARAM,Y.COM.PARAM.ID,R.COMM,F.AUMB.COMMON.PARAM,Y.ERR)
    Y.BSB = R.COMM<MCP.T24BSB.IDENTI.CODE>

    CUSTOMER.ID = Y.AA.REC<AA.ARR.CUSTOMER>
    CALL F.READ(FN.CUSTOMER,CUSTOMER.ID,R.CUS.REC,F.CUSTOMER,Y.ERR)
    Y.SECTOR = R.CUS.REC<EB.CUS.SECTOR>

    CALL F.READ(FN.ACCOUNT.CLASS,Y.ACC.CLASS.ID.1,R.ACC.CLASS.1,F.ACCOUNT.CLASS,Y.ERR)
    CALL F.READ(FN.ACCOUNT.CLASS,Y.ACC.CLASS.ID.2,R.ACC.CLASS.2,F.ACCOUNT.CLASS,Y.ERR)

    Y.ACCOUNT.TYPE = ""
* S - Defect NPP-1743
*    LOCATE Y.SECTOR IN R.ACC.CLASS.1<AC.CLS.SECTOR,1> SETTING Y.POS.1 THEN
*        Y.ACCOUNT.TYPE = 'NIND'
*    END
*    LOCATE Y.SECTOR IN R.ACC.CLASS.2<AC.CLS.SECTOR,1> SETTING Y.POS.2 THEN
*        Y.ACCOUNT.TYPE = 'INDV'
*    END

    GOSUB GET.ACCT.TYPE
* E - Defect NPP-1743

    R.OFS.EVT.REC<ACT.TRG.ARR.STATUS> = Y.ARR.STATUS
    R.OFS.EVT.REC<ACT.TRG.ACCT.NUMBER> = Y.ACC.NUMBER
    R.OFS.EVT.REC<ACT.TRG.PROD.ELIGIBILITY> = Y.PRODUCT.AVAIL
    R.OFS.EVT.REC<ACT.TRG.POST.RESTRICT> = Y.POST.RST
    R.OFS.EVT.REC<ACT.TRG.BSB> = Y.BSB
    R.OFS.EVT.REC<ACT.TRG.ACCT.TYPE> = Y.ACCOUNT.TYPE
    R.OFS.EVT.REC<ACT.TRG.T24.DATE> = TODAY

    GOSUB OFS.RECORD.FORMATION

    RETURN
*-------------------------------------------------------------
GET.ACCT.TYPE:
    Y.INDV.TYPE = 'OSA.RETAIL.NONMEMBER':FM:'IMSA.ACCOUNT':FM:'TRANS.ACCOUNT'
    Y.INDV.TYPE<-1> = 'TD.RETAIL.MBR.1MT':FM:'TD.RETAIL.MBR.1YRMAT':FM:'TD.RETAIL.MBR.3MT':FM:'TD.RETAIL.MBR.6MT'
    Y.INDV.TYPE<-1> = 'TD.RETAIL.MBR.MAT':FM:'TD.RETAIL.MBR.PARENT':FM:'TD.RETAIL.NMBR.1MT':FM:'TD.RETAIL.NMBR.1YRMAT'
    Y.INDV.TYPE<-1> = 'TD.RETAIL.NMBR.3MT':FM:'TD.RETAIL.NMBR.6MT':FM:'RATE.LOCK.HL':FM:'HL.BASIC.MBR.VAR'
    Y.INDV.TYPE<-1> = 'TD.RETAIL.NMBR.MAT':FM:'TD.RETAIL.PARENT':FM:'TD.RETAIL.NMBR.PARENT':FM:'HL.FLEX.MBR'
    Y.INDV.TYPE<-1> = 'HL.FLEX.MBR.PKG':FM:'HL.BASIC.MBR.VAR.SIM':FM:'HL.FLEX.MBR.SIM':FM:'HL.FLEX.MBR.PKG.SIM'
*S -  PL2-5212
    Y.INDV.TYPE<-1> = 'PL.UNSEC.MBR.VAR':FM:'PL.UNSEC.MBR.VAR.SIM'
 *E -  PL2-5212   

    Y.NIND.TYPE = 'OSA.BUSINESS':FM:'TD.BUSINESS.1MT':FM:'TD.BUSINESS.1YRMAT':FM:'TD.BUSINESS.3M':FM:'TD.BUSINESS.6MT':FM:'TD.BUSINESS.MAT':FM:'TD.BUSINESS.PARENT'

    LOCATE Y.ARR.PRD IN Y.INDV.TYPE SETTING Y.IND.POS THEN
        Y.ACCOUNT.TYPE = 'INDV'
    END

    LOCATE Y.ARR.PRD IN Y.NIND.TYPE SETTING Y.IND.POS THEN
        Y.ACCOUNT.TYPE = 'NIND'
    END

    RETURN
*------------------------------------------------------------
OFS.RECORD.FORMATION:
*-------------------------------------------------------------
    APPL.ID = 'MEB.H.ACCT.EVENT.CAPTURE'
    OFSRECORD = ''
    Y.PROCESS = 'PROCESS'
    OFS.SOURCE.ID = 'MEB.ACT.EVENT'
    txnCommitted = ''
    Y.FUNCTION.DECL = 'I'
    Y.VERSION.NAME = "MEB.H.ACCT.EVENT.CAPTURE,MEB.INPUT"
* Y.DT = TODAY
    Y.DT.1 = OCONV(DATE(),"D4/")
    Y.DT = FIELD(Y.DT.1,'/',3,1):FIELD(Y.DT.1,'/',1,1):FIELD(Y.DT.1,'/',2,1)

*    Y.TIME = TIME()
    Y.TIME = TIMEDATE()
    Y.TIMESTAMP = FIELD(Y.TIME, ' ',1)
*    Y.TIMESTAMP = OCONV(Y.TIME,'MTS')
    CHANGE ":" TO "" IN Y.TIMESTAMP
    Y.REC.ID = Y.DT:Y.TIMESTAMP:"-":Y.AA.ID

    CALL OFS.BUILD.RECORD(APPL.ID,Y.FUNCTION.DECL,Y.PROCESS,Y.VERSION.NAME, '' ,'0',Y.REC.ID,R.OFS.EVT.REC,OFSRECORD)

    CALL ofs.addLocalRequest(OFSRECORD,"add",OFS.ERR)

    IF OFS.ERR NE '' THEN
*      WRITELIST OFS.ERR:FM:OFSRECORD TO Y.REC.ID:'ACEVENT':TODAY
        Y.ER.ST = "Not posted"
    END

*   IF OFS.ERR EQ 'LOCALOFS' THEN
*    CALL OFS.POST.MESSAGE(OFSRECORD,OFS.MSG.ID,OFS.SOURCE.ID,OPTIONS)
*  END

    RETURN
END












