    SUBROUTINE MEB.PO.AA.CLOSURE.EVENT
*-----------------------------------------------------------------------------------------------------------------
*Description :
*---------------
*
*Date                   : 11 NOV 2019
*Development Ref        : Event trigger conditions for account activity
*Author                 : Suresh Poojary
*Type of the Routine    : Post routine
*Attached to            : Accounts request closure, HL settlement payoff and deposit redeem activities
*Purpose                : This routine is used to update the staging Table "MEB.H.ACCT.EVENT.CAPTURE" and trigger the events.
*----------------------------------------------------------------------------------------------------------------
*Arguments :
*----------------
*Incoming           : N.A
*Outgoing           : N.A
*----------------------------------------------------------------------------
*
*--------------------------------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date:          Reference:                     Developed By:            Description:
* 06-DEC-2019    Defect fixes                   Suresh P                 NPP-1743 and NPP-1746.
* 20-FEB-2020    UPGCHANGE                      N D MANAVI               Replaced the MEB.COMMON.PARM to AUMB.COMMON.PARAM   
* 12-Feb-2020    Defect fixes NPP-2145          Suresh P                 Excluding TD Deposit wholesale products
* 04-Jun-2020    T24UPGCHANGE(MTP ACTIVITY)     Pranitha Kovuru          Included AA.SIM.COMMON to get aaSimRef to exist from routine logic if running under simulation service 
* 31-Jul-2020    T24UPG - MTP Jun ER            Pranitha Kovuru          Added as part of R18 retrofit activity (Assigned Account type as INDV for PL Product)
* 08 -Feb-2021   PDR-1727						Mahesh KR 				 Account Type is blank in NPP extract for Pending Closure activity for SHL and SHLMP
*---------------------------------------------------------------------------------------------------
*--------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE 
    $INSERT I_AA.APP.COMMON
    $INSERT I_AA.LOCAL.COMMON
    $INSERT I_F.ACCOUNT
    $INSERT I_F.AA.ARRANGEMENT
    $INSERT I_F.AA.ARRANGEMENT.ACTIVITY
    $INSERT I_F.AA.ACCOUNT
    $INSERT I_F.ACCOUNT.CLASS
    $INSERT I_F.CUSTOMER
    $INSERT I_System
    $INSERT I_F.MEB.H.ACCT.EVENT.CAPTURE
    $INSERT I_F.AUMB.COMMON.PARAM
    $INSERT I_AA.SIM.COMMON

**T24UPGCHANGE -S
** If it is not running under simulation service then �aaSimRef� common variable holding the value as �0�
*------------------------------------------------------------------------------------------------------------
    Y.SIM.REF = ''
    Y.SIM.REF = aaSimRef
    IF Y.SIM.REF NE '0' OR AA$R.ARRANGEMENT.ACTIVITY<AA.ARR.ACT.SIM.RUN.REF> NE '' THEN  
      RETURN
    END
**T24UPGCHANGE -E
   
     GOSUB INIT
     GOSUB OPENFILES
     GOSUB PROCESS
    RETURN

INIT:

*In this GOSUB we are intialising neccessary variables
*-------------------------------------------------------

    Y.AA.ID = AA$ARR.ID
    Y.PROCESS = c_aalocActivityStatus
    R.OFS.EVT.REC = ''
    Y.ACC.CLASS.ID.1 = 'U-CORPORATE'
    Y.ACC.CLASS.ID.2 = 'U-INDIVIDUAL'
    Y.PRD.GROUP = ''

    RETURN


*----------------------------------------------------------------------------------------------------------------------------
OPENFILES:
***********

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.ACCOUNT.CLASS = 'F.ACCOUNT.CLASS'
    F.ACCOUNT.CLASS = ''
    CALL OPF(FN.ACCOUNT.CLASS, F.ACCOUNT.CLASS)

    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ''
    CALL OPF(FN.CUSTOMER, F.CUSTOMER)

    FN.AUMB.COMMON.PARAM = 'F.AUMB.COMMON.PARAM'
    F.AUMB.COMMON.PARAM = ''
    CALL OPF(FN.AUMB.COMMON.PARAM,F.AUMB.COMMON.PARAM)

    FN.MEB.ACCT.EVENT.CAPTURE ='F.MEB.H.ACCT.EVENT.CAPTURE'
    F.MEB.ACCT.EVENT.CAPTURE = ''
    CALL OPF(FN.MEB.ACCT.EVENT.CAPTURE,F.MEB.ACCT.EVENT.CAPTURE)

    RETURN

*----------------------------------------------------------
PROCESS:
*----------------------------------------------------------

    IF Y.PROCESS EQ 'AUTH' THEN
        Y.AA.REC = AA$R.ARRANGEMENT
        Y.LINKED.APPL =Y.AA.REC<AA.ARR.LINKED.APPL>
        Y.LINKED.APPL.ID = Y.AA.REC<AA.ARR.LINKED.APPL.ID>

        Y.ACC.NUMBER = Y.AA.REC<AA.ARR.LINKED.APPL.ID>
        CALL F.READ(FN.ACCOUNT,Y.ACC.NUMBER,R.ACC,F.ACCOUNT,E.ACC)
        Y.POST.RST =R.ACC<AC.POSTING.RESTRICT>

*        Y.POST.OLD = R.OLD(AA.AC.POSTING.RESTRICT)
*        Y.POST.RES = R.NEW(AA.AC.POSTING.RESTRICT)
*        IF Y.POST.RST NE Y.POST.RES THEN

*S - NPP-2145 Excluding TD Deposit wholesale products
        Y.PRD.GROUP = Y.AA.REC<AA.ARR.PRODUCT.GROUP>
        IF Y.PRD.GROUP NE 'TERM.DEPOSITS.WHOLESALE' THEN
            GOSUB FORM.PAYLOAD
        END
*E - NPP-2145
*        END
    END
    RETURN

*--------------------------------------------------------------
FORM.PAYLOAD:
* Form the payload required to post the event.
*---------------------------------------------------------------
*    Y.ARR.STATUS = Y.AA.REC<AA.ARR.ARR.STATUS>
*    Y.ARR.STATUS = R.NEW(AA.ARR.ARR.STATUS)
    Y.ARR.STATUS = "CLOSE"

* S - E Defect NPP-1746
*    Y.ARR.PRD = Y.AA.REC<AA.ARR.PRODUCT>
    Y.ARR.PRD = Y.AA.REC<AA.ARR.PRODUCT><1,1>
* E - Defect NPP-1746

    IF Y.ARR.PRD EQ 'OSA.RETAIL.NONMEMBER' OR Y.ARR.PRD EQ 'TRANS.ACCOUNT' OR Y.ARR.PRD EQ 'IMSA.ACCOUNT' OR Y.ARR.PRD EQ 'OSA.BUSINESS' THEN
        Y.PRODUCT.AVAIL = "Y"
    END ELSE
        Y.PRODUCT.AVAIL = "N"
    END

    Y.COM.PARAM.ID = 'AU0010001'
    CALL F.READ(FN.AUMB.COMMON.PARAM,Y.COM.PARAM.ID,R.COMM,F.AUMB.COMMON.PARAM,Y.ERR)
    Y.BSB = R.COMM<MCP.T24BSB.IDENTI.CODE>

    CUSTOMER.ID = Y.AA.REC<AA.ARR.CUSTOMER>
    CALL F.READ(FN.CUSTOMER,CUSTOMER.ID,R.CUS.REC,F.CUSTOMER,Y.ERR)
    Y.SECTOR = R.CUS.REC<EB.CUS.SECTOR>

    CALL F.READ(FN.ACCOUNT.CLASS,Y.ACC.CLASS.ID.1,R.ACC.CLASS.1,F.ACCOUNT.CLASS,Y.ERR)
    CALL F.READ(FN.ACCOUNT.CLASS,Y.ACC.CLASS.ID.2,R.ACC.CLASS.2,F.ACCOUNT.CLASS,Y.ERR)

    Y.ACCOUNT.TYPE = ""
* S - Defect NPP-1743
*    LOCATE Y.SECTOR IN R.ACC.CLASS.1<AC.CLS.SECTOR,1> SETTING Y.POS.1 THEN
*        Y.ACCOUNT.TYPE = 'NIND'
*    END
*    LOCATE Y.SECTOR IN R.ACC.CLASS.2<AC.CLS.SECTOR,1> SETTING Y.POS.2 THEN
*        Y.ACCOUNT.TYPE = 'INDV'
*    END

    GOSUB GET.ACCT.TYPE
* E - Defect NPP-1743

    R.OFS.EVT.REC<ACT.TRG.ARR.STATUS> = Y.ARR.STATUS
    R.OFS.EVT.REC<ACT.TRG.ACCT.NUMBER> = Y.ACC.NUMBER
    R.OFS.EVT.REC<ACT.TRG.PROD.ELIGIBILITY> = Y.PRODUCT.AVAIL
    R.OFS.EVT.REC<ACT.TRG.POST.RESTRICT> = Y.POST.RST
    R.OFS.EVT.REC<ACT.TRG.BSB> = Y.BSB
    R.OFS.EVT.REC<ACT.TRG.ACCT.TYPE> = Y.ACCOUNT.TYPE
    R.OFS.EVT.REC<ACT.TRG.T24.DATE> = TODAY

*    Y.DT = TODAY
*    Y.TIME = TIME()
*    Y.TIMESTAMP = OCONV(Y.TIME,'MTS')
*    Y.TIME = TIMEDATE()
*    Y.TIMESTAMP = FIELD(Y.TIME, ' ',1)
*    CHANGE ":" TO "" IN Y.TIMESTAMP
*    Y.REC.ID = Y.DT:Y.TIMESTAMP:"-":Y.AA.ID
*    CALL F.WRITE(FN.MEB.ACCT.EVENT.CAPTURE,Y.REC.ID,R.OFS.EVT.REC)

    GOSUB OFS.RECORD.FORMATION


    RETURN
*-------------------------------------------------------------
GET.ACCT.TYPE:
    Y.INDV.TYPE = 'OSA.RETAIL.NONMEMBER':FM:'IMSA.ACCOUNT':FM:'TRANS.ACCOUNT'
    Y.INDV.TYPE<-1> = 'TD.RETAIL.MBR.1MT':FM:'TD.RETAIL.MBR.1YRMAT':FM:'TD.RETAIL.MBR.3MT':FM:'TD.RETAIL.MBR.6MT'
    Y.INDV.TYPE<-1> = 'TD.RETAIL.MBR.MAT':FM:'TD.RETAIL.MBR.PARENT':FM:'TD.RETAIL.NMBR.1MT':FM:'TD.RETAIL.NMBR.1YRMAT'
    Y.INDV.TYPE<-1> = 'TD.RETAIL.NMBR.3MT':FM:'TD.RETAIL.NMBR.6MT':FM:'RATE.LOCK.HL':FM:'HL.BASIC.MBR.VAR'
    Y.INDV.TYPE<-1> = 'TD.RETAIL.NMBR.MAT':FM:'TD.RETAIL.PARENT':FM:'TD.RETAIL.NMBR.PARENT':FM:'HL.FLEX.MBR'
    Y.INDV.TYPE<-1> = 'HL.FLEX.MBR.PKG':FM:'HL.BASIC.MBR.VAR.SIM':FM:'HL.FLEX.MBR.SIM':FM:'HL.FLEX.MBR.PKG.SIM'
*S -  T24UPG - MTP Jun ER
    Y.INDV.TYPE<-1> = 'PL.UNSEC.MBR.VAR':FM:'PL.UNSEC.MBR.VAR.SIM'
*E -  T24UPG - MTP Jun ER 
*PDR-1727  Changes -Start
	Y.INDV.TYPE<-1> = 'HL.FLEX.MBR.ULTRACS':FM:'HL.FLEX.MBR.PKG.ULT'
*PDR-1727  Changes -End	
    Y.NIND.TYPE = 'OSA.BUSINESS':FM:'TD.BUSINESS.1MT':FM:'TD.BUSINESS.1YRMAT':FM:'TD.BUSINESS.3M':FM:'TD.BUSINESS.6MT':FM:'TD.BUSINESS.MAT':FM:'TD.BUSINESS.PARENT'

    LOCATE Y.ARR.PRD IN Y.INDV.TYPE SETTING Y.IND.POS THEN
        Y.ACCOUNT.TYPE = 'INDV'
    END

    LOCATE Y.ARR.PRD IN Y.NIND.TYPE SETTING Y.IND.POS THEN
        Y.ACCOUNT.TYPE = 'NIND'
    END

    RETURN
*-------------------------------------------------------------
OFS.RECORD.FORMATION:
*-------------------------------------------------------------
    APPL.ID = 'MEB.H.ACCT.EVENT.CAPTURE'
    OFSRECORD = ''
    Y.PROCESS1 = 'PROCESS'
    OFS.SOURCE.ID = 'MEB.ACT.EVENT'
    txnCommitted = ''
    Y.FUNCTION.DECL = 'I'
    Y.VERSION.NAME = "MEB.H.ACCT.EVENT.CAPTURE,MEB.INPUT"
*    Y.DT = TODAY
    Y.DT.1 = OCONV(DATE(),"D4/")
    Y.DT = FIELD(Y.DT.1,'/',3,1):FIELD(Y.DT.1,'/',1,1):FIELD(Y.DT.1,'/',2,1)
*    Y.TIME = TIME()
*    Y.TIMESTAMP = OCONV(Y.TIME,'MTS')
    Y.TIME = TIMEDATE()
    Y.TIMESTAMP = FIELD(Y.TIME, ' ',1)
    CHANGE ":" TO "" IN Y.TIMESTAMP
    Y.REC.ID = Y.DT:Y.TIMESTAMP:"-":Y.AA.ID


    CALL OFS.BUILD.RECORD(APPL.ID,Y.FUNCTION.DECL,Y.PROCESS1,Y.VERSION.NAME, '' ,'0',Y.REC.ID,R.OFS.EVT.REC,OFSRECORD)
    Y.OFS.RESPONSE = ''
    Y.OFS.COMMIT = ''


    CALL OFS.CALL.BULK.MANAGER(OFS.SOURCE.ID,OFSRECORD,Y.OFS.RESPONSE,Y.OFS.COMMIT)
*    IF Y.OFS.COMMIT NE "1" THEN
*        E = "Failed to capture Event": Y.OFS.COMMIT
*    END

*    CALL ofs.addLocalRequest(OFSRECORD,"add",OFS.ERR)
*    IF OFS.ERR NE '' THEN
*        E = OFS.ERR
*    END
*   IF OFS.ERR EQ 'LOCALOFS' THEN
*    CALL OFS.POST.MESSAGE(OFSRECORD,OFS.MSG.ID,OFS.SOURCE.ID,OPTIONS)
*   END



    RETURN
END

********************************END OF ROUTINE**********************************************




