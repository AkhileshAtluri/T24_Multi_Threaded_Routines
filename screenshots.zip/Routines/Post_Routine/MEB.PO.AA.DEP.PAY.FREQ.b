    SUBROUTINE MEB.PO.AA.DEP.PAY.FREQ
*-------------------------------------------------------------------------
* Developed By    : Shalini, Capgemini
* Purpose         : Purpose of this post routine is to pass the nth day to the frequency
*                   based on Activity Effective date.
* Subroutine Type : POST ROUTINE
* Attached to     : ACTIVITY.API>DEPOSITS
* Attached as     : POST.ROUTINE
* Dev Ref         : PDR-470
*-------------------------------------------------------------------------
* Modification History :
*-----------------------
*
* Date:         Reference:              Developed By:          Description:
*-----------------------------------------------------------------------------
*17-08-2020     DD-153                  Namratha               To ensure the payment schedule is aligned correctly based on the activity effective date when 
*									we change the product to yearly product within RTD & BTD using Change product Activity.
*--------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_AA.APP.COMMON
    $INSERT I_F.AA.PAYMENT.SCHEDULE
    $INSERT I_F.AA.ARRANGEMENT.ACTIVITY


    ARRANGEMENT.ID = ''
    ACT.EFF.DATE = ''
    Y.PYMT.FREQ = ''
    NEW.PAY.FREQ = ''
*DD-153 START:
    Y.PAYMENT.TYPE = ''
    Y.PYMT.FREQ.TRIM = ''
    Y.LENGTH = ''
    Y.PAYMENT.TYPE.POS = ''
*DD-153 END:
*
    ARRANGEMENT.ID = AA$ARR.ID
    ACT.EFF.DATE = AA$ACTIVITY.EFF.DATE
*	
*DD-153 START:
*   Y.PYMT.FREQ = R.NEW(AA.PS.PAYMENT.FREQ)
    Y.PAYMENT.TYPE = R.NEW(AA.PS.PAYMENT.TYPE)
    CHANGE VM TO FM IN Y.PAYMENT.TYPE
    LOCATE 'INTEREST.ONLY' IN Y.PAYMENT.TYPE SETTING Y.PAYMENT.TYPE.POS THEN
    Y.PYMT.FREQ = R.NEW(AA.PS.PAYMENT.FREQ)<1,Y.PAYMENT.TYPE.POS>
    Y.DUE.FREQ = R.NEW(AA.PS.DUE.FREQ)<1,Y.PAYMENT.TYPE.POS>
    END
	
    Y.PYMT.FREQ.TRIM = FIELD(Y.PYMT.FREQ," ",1,2) 
    Y.LENGTH = LEN(Y.PYMT.FREQ.TRIM)
	
    BEGIN CASE  
    CASE Y.LENGTH EQ "8" 
    NEW.PAY.FREQ = Y.PYMT.FREQ[1,13]:'o':ACT.EFF.DATE[2]:'D ':Y.PYMT.FREQ[3]
*
    CASE Y.LENGTH EQ "7"
    NEW.PAY.FREQ = Y.PYMT.FREQ[1,12]:'o':ACT.EFF.DATE[2]:'D ':Y.PYMT.FREQ[3]
    END CASE

    R.NEW(AA.PS.PAYMENT.FREQ)<1,Y.PAYMENT.TYPE.POS> = NEW.PAY.FREQ
    R.NEW(AA.PS.DUE.FREQ)<1,Y.PAYMENT.TYPE.POS> = NEW.PAY.FREQ

*    NEW.PAY.FREQ = Y.PYMT.FREQ[1,12]:'o':ACT.EFF.DATE[2]:'D ':Y.PYMT.FREQ[3]
*
*    R.NEW(AA.PS.PAYMENT.FREQ) = NEW.PAY.FREQ
*    R.NEW(AA.PS.DUE.FREQ) = NEW.PAY.FREQ	
 	
*DD-153 END:

RETURN
END       ;* Final End
