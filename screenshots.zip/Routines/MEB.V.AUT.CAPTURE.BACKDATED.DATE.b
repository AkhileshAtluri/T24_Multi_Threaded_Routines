*-----------------------------------------------------------------------------
* <Rating>-10</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE MEB.V.AUT.CAPTURE.BACKDATED.DATE
*-----------------------------------------------------------------------------
* Developed By    : Sundara Krishnan
* Program Name    : MEB.V.AUT.CAPTURE.BACKDATED.DATE
* Purpose         : *
*-----------------------------------------------------------------------------
* Subroutine Type : Auth Routine
* Attached To     : VERSION.CONTROL>AA.ARRANGEMENT.ACTIVITY
* Attached As     : Auth Routine
* In Parameter    : -NA-
* Out Parameter   : NA
*--------------------------------------------------------------------------------------------
*Modification History
*--------------------
* Date:            Reference:              Developed By:            Description:
*
* 2020/07/24       ODS-676                 Senthilkumar.P           - only small  number of back dated contracts captured in the concat file
*                                                                     but in the system there are more AAA backdated records are inputted.
*                                                                     And updation of info table logic has been changed to cover all the below scenario.
*                                                                     Scenario 1)If record already exists with T24.SYS.DATE as today then
*                                                                                Validate if the BKD.INFO>LAST.BAK.DTE is greaterthan AAA>EFFECTIVE.DATE then capture back dated dates info.
*                                                                     Scenario 2)If record already exists with T24.SYS.DATE not equal to today then capture back dated dates info.
*                                                                     Scenario 3)If record not avaible then capture back dated dates info.
*
* 2020/10/15       ODS-780                 Senthilkumar.P           - Chnages done to update the coresponding record in the  MEB.L.ARRANGEMENT.BACKDATE.INFO>AAA.ID with ctivity ID
*
* 2020/10/29       ODS-819                 Senthilkumar.P           - Chnages done to continue the process even in BATCH mode also.
*
* 2020/10/29       ODS-728                 Senthilkumar.P           - Update the Backdated info table to capture all the backdated dates activities instead of overwriting the dates.
*
* 2021/03/26       ODS-901                 Suresh Sekar             - For Backdated activity don't write for TRANS.PRODUCT product in MEB.L.ARRANGEMENT.BACKDATE.INFO table
*
* 2021/05/17       T24UP-12883             Varsha Shenoy            - LENDING-TRIGGER.MAINTAIN-PRINCIPALINT and ACCOUNTS-TRIGGER.MAINTAIN-CRINTEREST backdated activities must not be updated in MEB.L.ARRANGEMENT.BACKDATE.INFO table
*
* 2021/09/16       UPCHANGE            Varsha Shenoy            - Modified code to pick 1st MV of product if product line is Accounts.
*-------------------------------------------------------------------------------------------------------------------------------


    $INSERT  I_COMMON
    $INSERT  I_EQUATE
    $INSERT  I_F.AA.ACCOUNT
    $INSERT  I_AA.APP.COMMON
    $INSERT  I_AA.ACTION.CONTEXT
    $INSERT  I_AA.LOCAL.COMMON
    $INSERT  I_F.AA.ARRANGEMENT.ACTIVITY
    $INSERT  I_AA.RR.CONTROL
*---/ODS-728 Start.
    $INSERT I_F.AA.ARRANGEMENT
    $INSERT I_F.ACCOUNT
*---/ODS-728 End.

*---/Added as part of ODS.676  Start.
    $INSERT I_F.MEB.L.ARRANGEMENT.BACKDATE.INFO
*---/Added as part of ODS.676  End.

*---/ODS-819 Start.

*    IF RUNNING.UNDER.BATCH THEN RETURN

*---/ODS-819 End.

    GOSUB INIT
*---/ODS-728 Start.
    Y.AAA.ID = ID.NEW
    Y.MAST.AAA.ID = '' ; Y.MAST.AAA.ID = R.NEW(AA.ARR.ACT.MASTER.AAA)
*---/ODS.780 Start.
    Y.REV.MAST.AAA.ID = '' ; Y.REV.MAST.AAA.ID = R.NEW(AA.ARR.ACT.REV.MASTER.AAA)

*---/ODS.780 End.
*    IF EFFECTIVE.DATE LT TODAY THEN
*---/ODS.780 Start.
*    IF EFFECTIVE.DATE LT TODAY AND Y.AAA.ID EQ Y.MAST.AAA.ID THEN
    IF EFFECTIVE.DATE LT TODAY THEN
        IF Y.AAA.ID EQ Y.MAST.AAA.ID OR Y.AAA.ID EQ Y.REV.MAST.AAA.ID THEN
*---/ODS.780 End.
*---/ODS-728 End.
*---/T24UP-12883 Start
            IF Y.ACTIVITY NE 'LENDING-TRIGGER.MAINTAIN-PRINCIPALINT' AND Y.ACTIVITY NE 'ACCOUNTS-TRIGGER.MAINTAIN-CRINTEREST' THEN
*---/T24UP-12883 End
*---/ODS-901 Start
*GOSUB PROCESS

                IF Y.AA.PRODUCT.ID NE 'TRANS.ACCOUNT' THEN
                    GOSUB PROCESS
                END
*---/T24UP-12883 Start
            END
*---/T24UP-12883 End
*---ODS-901 End
*---/Added as part of ODS.676  Start.
        END ELSE
            RETURN
*---/Added as part of ODS.676  Start.
*---/ODS.780 Start.
        END
*---/ODS.780 End.
    END

    RETURN
*------------------------------------------------------------------------------------------------------------------------------------------------
INIT:
*===*
    AAA.ID = ''

*---/Added as part of ODS.676  Start.
*    ARR.ID = aaRR_AAAMasterActRec<1,AA.ARR.ACT.ARRANGEMENT>
    ARR.ID = R.NEW(AA.ARR.ACT.ARRANGEMENT)
*---/Added as part of ODS.676  End.
    Y.ACTIVITY = R.NEW(AA.ARR.ACT.ACTIVITY)

    REPLAY.MODE = ''
*---/Added as part of ODS.676  Start.
*    EFFECTIVE.DATE = aaRR_AAAMasterActRec<1,AA.ARR.ACT.EFFECTIVE.DATE>
    EFFECTIVE.DATE = R.NEW(AA.ARR.ACT.EFFECTIVE.DATE)
*---/Added as part of ODS.676  End.

*---/ODS.780 Start.

    FN.AA.ARRANGEMENT = 'F.AA.ARRANGEMENT'
    F.AA.ARRANGEMENT = ''
    CALL OPF(FN.AA.ARRANGEMENT,F.AA.ARRANGEMENT)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    GOSUB GET.ACCOUNT.ID

*---/ODS.780 End.

    FN.MEB.AA.BDTE = 'F.MEB.L.ARRANGEMENT.BACKDATE.INFO'
    F.MEB.AA.BDTE = ''

    CALL OPF(FN.MEB.AA.BDTE,F.MEB.AA.BDTE)

    RETURN
*----------------------------------------------------------------------------------------------------------------------------------
*---/ODS.780 Start.
GET.ACCOUNT.ID:
*=============*

    R.AA.ARRANGEMENT = '' ; ERR.AA.ARRANGEMENT = ''
    Y.AA.PRODUCT.ID = ''      ;*ODS-901 S/E
    CALL F.READ(FN.AA.ARRANGEMENT,ARR.ID,R.ARR.ARRANGEMENT,F.AA.ARRANGEMENT,ERR.AA.ARRANGEMENT)
    IF R.ARR.ARRANGEMENT THEN


        Y.LINKED.APPLS = R.ARR.ARRANGEMENT<AA.ARR.LINKED.APPL>
        Y.LINKED.APPL.IDS = R.ARR.ARRANGEMENT<AA.ARR.LINKED.APPL.ID>
        Y.AA.PRODUCT.ID = R.ARR.ARRANGEMENT<AA.ARR.PRODUCT> ;*ODS-901 S/E
*UPGCHANGE:S 2021/09/16
        IF R.ARR.ARRANGEMENT<AA.ARR.PRODUCT.LINE> EQ 'ACCOUNTS' THEN
            Y.AA.PRODUCT.ID= R.ARR.ARRANGEMENT<AA.ARR.PRODUCT,1>
        END
*UPGCHANGE:E 2021/09/16

        LOCATE 'ACCOUNT' IN Y.LINKED.APPLS<1,1> SETTING ACCOUNT.POS THEN
            Y.T24.ACCOUNT = Y.LINKED.APPL.IDS<1,ACCOUNT.POS>
            R.ACCOUNT = ''
            ERR.ACCOUNT = ''

            CALL F.READ(FN.ACCOUNT,Y.T24.ACCOUNT,R.ACCOUNT,F.ACCOUNT,ERR.ACCOUNT)

            IF R.ACCOUNT THEN
                Y.ALT.ACCT.ID = '' ; Y.ALT.ACCT.ID = R.ACCOUNT<AC.ALT.ACCT.ID,1>

            END
        END

    END

    RETURN
*---/ODS.780 End.
*--------------------------------------------------------------------------------------------------------------------------------------
PROCESS:
*======*


*---/Added as part of ODS.676  Start.
*    ARR.ACTIVITY.ID = ARR.ID  ;* Arrangement Activity Id
*    R.ACTIVITY = aaRR_AAAMasterActRec   ;* Arrangement Activity record.

    R.MEB.AA.BDTE = ''
    ERR.BDTE = ''
*---/Added as part of ODS.676  End.

    CALL F.READ(FN.MEB.AA.BDTE,ARR.ID,R.MEB.AA.BDTE,F.MEB.AA.BDTE,ERR.BDTE)
*---/ODS.728 Start.
    GOSUB WRITE.BACK.DATED.INFO
*---/ODS.728 End.

*---/Added as part of ODS.676  Start.
*---/ODS.728 Start.
*--All the below lines commented as part of ODS.728.
*    IF R.MEB.AA.BDTE THEN
*        Y.ARRANGEMENT = R.MEB.AA.BDTE<MEB.BACKDATE.ACCOUNT.ID>
*        Y.LAST.BAK.DTE = R.MEB.AA.BDTE<MEB.BACKDATE.LAST.BAK.DTE>
*        Y.T24.SYS.DTE =  R.MEB.AA.BDTE<MEB.BACKDATE.T24.SYS.DTE>
*        IF Y.T24.SYS.DTE EQ TODAY THEN
*            IF Y.LAST.BAK.DTE GT EFFECTIVE.DATE THEN
*           /If record already exists with T24.SYS.DATE as today then
*           /Validate if the BKD.INFO>LAST.BAK.DTE is greaterthan AAA>EFFECTIVE.DATE then capture back dated dates info.
*                GOSUB WRITE.BACK.DATED.INFO
*            END
*        END ELSE
*           /If record already exists with T24.SYS.DATE not equal to today then capture back dated dates info.
*            GOSUB WRITE.BACK.DATED.INFO
*        END
*    END ELSE
*           /If record not avaible then capture back dated dates info.
*        GOSUB WRITE.BACK.DATED.INFO
*    END
*---/ODS.728 End.
**---/ All the below 22 lines commented.
*    BACKDATED.DTE = R.MEB.AA.BDTE<1>
*    IF ERR.BDTE THEN
*        IF aaRR_AAAMasterActRec NE '' THEN
*            R.MEB.AA.BDTE<1> = ARR.ID
*            R.MEB.AA.BDTE<2>  = EFFECTIVE.DATE
*            R.MEB.AA.BDTE<3> = TODAY
*            Y.ID.REC = ARR.ID
*             CALL F.WRITE(FN.MEB.AA.BDTE,Y.ID.REC,R.MEB.AA.BDTE)
*        END
*    END ELSE
*        IF BACKDATED.DTE GT EFFECTIVE.DATE THEN
*            IF aaRR_AAAMasterActRec NE '' THEN
*                R.MEB.AA.BDTE<1> = ARR.ID
*                R.MEB.AA.BDTE<2>  = EFFECTIVE.DATE
*                R.MEB.AA.BDTE<3> = TODAY
*                Y.ID.REC = ARR.ID
*                CALL F.WRITE(FN.MEB.AA.BDTE,Y.ID.REC,R.MEB.AA.BDTE)
*            END
*        END ELSE
*            RETURN
*        END
*    END

*---/Added as part of ODS.676  End.
    RETURN
*----------------------------------------------------------------------------------------------------------
*---/Added as part of ODS.676  Start.
WRITE.BACK.DATED.INFO:
*--------------------*
*---/ODS.728 Start.
    IF NOT(R.MEB.AA.BDTE) THEN
*---/ODS.728 End.
*---/ODS.780 Start.

*       R.MEB.AA.BDTE<MEB.BACKDATE.ACCOUNT.ID> = ARR.ID
        R.MEB.AA.BDTE<MEB.BACKDATE.ACCOUNT.ID> = Y.ALT.ACCT.ID
*---/ODS.780 End.
        R.MEB.AA.BDTE<MEB.BACKDATE.LAST.BAK.DTE> = EFFECTIVE.DATE
        R.MEB.AA.BDTE<MEB.BACKDATE.T24.SYS.DTE> = TODAY

*---/ODS.780 Start.
        R.MEB.AA.BDTE<MEB.BACKDATE.AAA.ID> = Y.AAA.ID
*---/ODS.780 End.
*---/ODS.728 Start.

    END ELSE
*---/ODS.780 Start.
        R.MEB.AA.BDTE<MEB.BACKDATE.ACCOUNT.ID> = Y.ALT.ACCT.ID
*---/ODS.780 End.
        R.MEB.AA.BDTE<MEB.BACKDATE.LAST.BAK.DTE,-1> = EFFECTIVE.DATE
        R.MEB.AA.BDTE<MEB.BACKDATE.T24.SYS.DTE,-1> = TODAY
        R.MEB.AA.BDTE<MEB.BACKDATE.AAA.ID,-1> = Y.AAA.ID
    END

*---/ODS.728 End.

    Y.ID.REC = ARR.ID
    CALL F.WRITE(FN.MEB.AA.BDTE,Y.ID.REC,R.MEB.AA.BDTE)

    RETURN
*---/Added as part of ODS.676  End.
*----------------------------------------------------------------------------------------------------------
END

