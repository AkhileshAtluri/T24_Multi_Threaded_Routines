*-----------------------------------------------------------------------------
* <Rating>-61</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE MEB.V.VAL.ALLPAY.CRD.AC
*-------------------------------------------------------------------------
* Developed By    : Techmill Technologies
* Program Name    : MEB.V.VAL.ACTR.CRD.AC
* Purpose         :
*-------------------------------------------------------------------------
* Subroutine Type : S
* Attached To     : Version - FUNDS.TRANSFER,ACTR.ME
* Attached As     : Validation Routine.
* In Parameter    : -NA-
* Out Parameter   : -NA-
*-------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date:         Reference              Developed By:
*-------------------------------------------------------------------------
* 27-May-2013                        vijaykumar.ks@techmilltechnologies.com
*
* 13-Jul-2016   Changed for issue    rathan.r@techmilltechnologies.com
*               2313
*
* UPGCHANGE - Sweta - 20190402 - Replaced MEB.COMMON.PARAM to AUMB.COMMON.PARAM
* UPGCHANGE - Sweta - 20190402 - In case COMI is blank, pick up the account from DES.ACCT.NO
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.CATEGORY
    $INSERT I_F.AUMB.COMMON.PARAM

!

    GOSUB INITIALISE
    GOSUB PROCESS
    RETURN
*-------------------------------------------------------------------------
INITIALISE:
*-------------------------------------------------------------------------
    FN.AUMB.COMMON.PARAM = 'F.AUMB.COMMON.PARAM'   ;   F.AUMB.COMMON.PARAM = ''
    CALL OPF(FN.AUMB.COMMON.PARAM,F.AUMB.COMMON.PARAM)
!
    FN.ACCOUNT = 'F.ACCOUNT'                     ;   F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)
!
    FN.ALTERNATE.ACCOUNT = 'F.ALTERNATE.ACCOUNT'
    F.ALTERNATE.ACCOUNT = ''
    CALL OPF(FN.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT)

    FN.ACCOUNT.HIS = 'F.ACCOUNT$HIS'
    F.ACCOUNT.HIS =''
    CALL OPF(FN.ACCOUNT.HIS,F.ACCOUNT.HIS)

    FN.CATEGORY = 'F.CATEGORY'
    F.CATEGORY = ''
    CALL OPF(FN.CATEGORY,F.CATEGORY)

    Y.FLAG = 0
!
    Y.APP='FUNDS.TRANSFER'
    Y.FLD = 'DES.ACCT.MEB.NO':VM:'DES.ACCT.BSB':VM:'DES.ACCT.NO':VM:'DES.ACCT.NAME'
    Y.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP,Y.FLD,Y.POS)
    Y.DES.ACCT.MEB.NO = Y.POS<1,1>
    Y.DES.ACCT.BSB = Y.POS<1,2>
    Y.DES.ACCT.NO = Y.POS<1,3>
    Y.DES.ACCT.NAME=Y.POS<1,4>
    COMP.ID = ID.COMPANY
    RETURN
*-------------------------------------------------------------------------
PROCESS:
*-------------------------------------------------------------------------

    Y.DES.ACT.MEB.NO = R.NEW(FT.LOCAL.REF)<1,Y.DES.ACCT.MEB.NO>
!
    IF Y.DES.ACT.MEB.NO EQ '' THEN
        Y.FT.TYPE=R.NEW(FT.TRANSACTION.TYPE)
        Y.DES.BSB = R.NEW(FT.LOCAL.REF)<1,Y.DES.ACCT.BSB>
!
        R.AUMB.COMMON.PARAM = ''
        CALL F.READ(FN.AUMB.COMMON.PARAM,COMP.ID,R.AUMB.COMMON.PARAM,F.AUMB.COMMON.PARAM,MEB.ERR)
        IF R.AUMB.COMMON.PARAM THEN
            Y.ACCT.ID=COMI
* (Start-UPGCHANGE-20190402)
			IF Y.ACCT.ID EQ '' THEN
                Y.ACCT.ID = R.NEW(FT.LOCAL.REF)<1,Y.DES.ACCT.NO>
            END
* (End-UPGCHANGE-20190402)
            IF COMI[1,2] EQ 'PL' THEN
                GOSUB PL.PROCESS
            END ELSE
                GOSUB CHECK.ACCT



                IF Y.FLAG NE 1 THEN
                    GOSUB DEFAULT.CREDIT.ACCT
                END
            END
        END
    END
    RETURN
*-------------------------------------------------------------------------
DEFAULT.CREDIT.ACCT:
*-------------------------------------------------------------------------
    IF Y.DES.BSB EQ R.AUMB.COMMON.PARAM<MCP.T24BSB.IDENTI.CODE> THEN
        R.NEW(FT.CREDIT.ACCT.NO) = Y.ACCT.ID
        R.NEW(FT.LOCAL.REF)<1,Y.DES.ACCT.NAME>=Y.NAME
        OFS$ENRI<FT.LOCAL.REF,Y.DES.ACCT.NO>=Y.NAME
    END ELSE
        LOCATE Y.DES.BSB IN R.AUMB.COMMON.PARAM<MCP.BSB.IDENTI.CODE,1> SETTING Y.POS1 THEN
            R.NEW(FT.CREDIT.ACCT.NO) = R.AUMB.COMMON.PARAM<MCP.INTERN.SYS.ACCT,Y.POS1>
        END ELSE
            LOCATE Y.FT.TYPE IN R.AUMB.COMMON.PARAM<MCP.TRANSACTION.TYP,1>SETTING Y.POS2 THEN
                R.NEW(FT.CREDIT.ACCT.NO) = R.AUMB.COMMON.PARAM<MCP.CLEARING.AC,Y.POS2>
            END
        END
    END
    RETURN
*-------------------------------------------------------------------------
CHECK.ACCT:
*-------------------------------------------------------------------------
    R.ACCOUNT = ''
    CALL F.READ(FN.ACCOUNT,Y.ACCT.ID,R.ACCOUNT,F.ACCOUNT,ERROR.ACC)
    IF R.ACCOUNT EQ '' THEN
        GOSUB GET.ALT.ID
    END ELSE
        Y.ACC.NAME=R.ACCOUNT<AC.SHORT.TITLE>
        Y.NAME=Y.ACC.NAME[1,32]

**changes made***
        IF Y.DES.BSB EQ '' THEN
            Y.DES.BSB = R.AUMB.COMMON.PARAM<MCP.T24BSB.IDENTI.CODE>
            R.NEW(FT.LOCAL.REF)<1,Y.DES.ACCT.BSB> = Y.DES.BSB
        END ELSE
            R.NEW(FT.LOCAL.REF)<1,Y.DES.ACCT.BSB> = Y.DES.BSB
        END
*****************
    END
    Y.T24.BSB = R.AUMB.COMMON.PARAM<MCP.T24BSB.IDENTI.CODE>

    IF (Y.DES.BSB EQ Y.T24.BSB AND R.ACCOUNT EQ '') THEN
        GOSUB ACCT.HISTORY
    END

    RETURN

**************
ACCT.HISTORY:
**************

    CALL EB.READ.HISTORY.REC(F.ACCOUNT.HIS,Y.ACCT.ID,R.ACCOUNT,Y.ACC.HIS.ERR)
    IF R.ACCOUNT THEN
        Y.FLAG=1
        ETEXT = "AC-ACCOUNT.CLOSED.STATUS"
        CALL STORE.END.ERROR
    END ELSE
        Y.FLAG=1
        ETEXT='EB-MEB.BSB.ACC.INVALID'
        CALL STORE.END.ERROR
    END
    RETURN

GET.ALT.ID:
**********
    ACCT.ERR = ''
    R.ACCOUNT = ''
    CALL F.READ(FN.ALTERNATE.ACCOUNT,Y.ACCT.ID,R.ALTERNATE.ACCOUNT,F.ALTERNATE.ACCOUNT,ACCT.ERR)
    IF R.ALTERNATE.ACCOUNT THEN
        Y.ACCT.ID = R.ALTERNATE.ACCOUNT<1>
        GOSUB CHECK.ACCT
    END

    RETURN

***********
*Added below Gosub for Issue 2313
PL.PROCESS:
***********
    R.CATEGORY = '' ; CATEG.ERR = ''  ; CATEG.ID = COMI[3,99]
    CALL F.READ(FN.CATEGORY, CATEG.ID, R.CATEGORY, F.CATEGORY, CATEG.ERR)
!
    IF R.CATEGORY THEN
        R.NEW(FT.LOCAL.REF)<1,Y.DES.ACCT.BSB>    = R.AUMB.COMMON.PARAM<MCP.T24BSB.IDENTI.CODE>
        R.NEW(FT.LOCAL.REF)<1,Y.DES.ACCT.NAME>   = R.CATEGORY<EB.CAT.DESCRIPTION>
        OFS$ENRI<FT.LOCAL.REF,Y.DES.ACCT.NO>= R.CATEGORY<EB.CAT.DESCRIPTION>
        R.NEW(FT.CREDIT.ACCT.NO) = COMI

    END ELSE
        ETEXT = 'FT-INVALID.CAT.CODE'
        CALL STORE.END.ERROR
    END
!
    RETURN


END
*--------------------------------END OF ROUTINE-----------------------------------------
















