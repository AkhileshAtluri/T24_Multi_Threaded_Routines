*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE MEB.V.AUT.CHANGE.STATUS
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DD.DDI
    $INSERT I_F.ACCOUNT
    $INSERT I_F.AA.ARRANGEMENT

    IF V$FUNCTION NE 'I' AND V$FUNCTION NE 'A' THEN
        RETURN
    END

    IF R.NEW(DD.DDI.STATUS) NE 'AVAILABLE' AND R.NEW(DD.DDI.STATUS) NE 'NEW' THEN
        RETURN
    END

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.AA.ARR = 'F.AA.ARRANGEMENT'
    F.AA.ARR = ''
    CALL OPF(FN.AA.ARR,F.AA.ARR)

    FN.OFS.MSG.QUEUE = 'F.OFS.MESSAGE.QUEUE'
    F.OFS.MSG.QUEUE = ''
    CALL OPF(FN.OFS.MSG.QUEUE,F.OFS.MSG.QUEUE)

    ACCT.ID = FIELD(ID.NEW,'.',1)

    CALL F.READ(FN.ACCOUNT,ACCT.ID,R.ACC,F.ACCOUNT,ACC.ERR)
    IF R.ACC THEN
        ARR.ID = R.ACC<AC.ARRANGEMENT.ID>
        R.ARRANGEMENT = '' ; ARR.ERR = ''
        CALL F.READ(FN.AA.ARR,ARR.ID,R.ARRANGEMENT,F.AA.ARR,ARR.ERR)
        IF R.ARRANGEMENT<AA.ARR.PRODUCT.LINE> EQ 'LENDING' THEN
            OFS.MSG = 'DD.DDI,/I/PROCESS/1/0,,':ID.NEW:',STATUS=HOLD'

            CALL ALLOCATE.UNIQUE.TIME(OFS.MSG.ID)
            OFS.MSG.ID = DATE():OFS.MSG.ID
            MSG.ID = OFS.MSG.ID:'-DOC'
            WRITE OFS.MSG TO F.OFS.MSG.QUEUE,MSG.ID
        END
    END
    RETURN
END

 
