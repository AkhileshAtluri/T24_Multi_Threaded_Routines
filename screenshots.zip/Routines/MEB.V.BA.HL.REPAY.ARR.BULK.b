    SUBROUTINE MEB.V.BA.HL.REPAY.ARR.BULK
*-------------------------------------------------------------------------
* Developed By    : Capgemini India Pvt Ltd
* Program Name    : MEB.V.BA.HL.REPAY.ARR.BULK
* Purpose         : This routine triggers the loan repayment if the loan
*                   is in arrears while performing Interest adjustment.
*-------------------------------------------------------------------------
* Subroutine Type : Version before auth routine
* Attached To     : VERSION>FUNDS.TRANSFER,MEB.AA.ACVQ.BULK
* Attached As     : Before Auth Routine
* In Parameter    : -NA-
* Out Parameter   : -NA- 
*-------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date:         Reference              Developed By    Change Description
* 20-Mar-19     PPLX-4101              Vidhya          TPR was run to correct to refund the interest
*                                                      in case of incorrect offset accrual calculation
*                                                      This routine triggers the loan repayment if the loan
*                                                      is in arrears while performing Interest adjustment
*                                                      in the TPR version FUNDS.TRANSFER,MEB.AA.ACVQ.BULK
*                                                      This is a copy of existing routine MEB.V.BA.HL.REPAY.ARREARS
*                                                      which is attached to manual interest adjustment version FUNDS.TRANSFER,MEB.AA.ACVQ.BULK
*                                                      As the Manual version uses Current variables the same version cannot be used in TPR , also
*                                                      Hence created a version which is a copy of manual version above 
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.ACCOUNT
    $INSERT I_F.AA.ARRANGEMENT
    $INSERT I_F.EB.LOOKUP
*-------------------------------------------------------------------------
    GOSUB OPEN.FILES
    GOSUB PROCESS
    RETURN
*-------------------------------------------------------------------------
OPEN.FILES:
***********
    FN.EB.LOOKUP = 'F.EB.LOOKUP'
    F.EB.LOOKUP = ''
    CALL OPF(FN.EB.LOOKUP,F.EB.LOOKUP)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT,F.ACCOUNT)

    FN.AA.ARRANGEMENT = 'F.AA.ARRANGEMENT'
    F.AA.ARRANGEMENT = ''
    CALL OPF(FN.AA.ARRANGEMENT,F.AA.ARRANGEMENT)

    Y.APP = "FUNDS.TRANSFER"
    Y.FIELDS = "SRC.ACCT.NO":VM:"DES.ACCT.NO"
    Y.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP,Y.FIELDS,Y.POS)
    Y.SRC.ACCT.NO.POS = Y.POS<1,1>
    Y.DES.ACCT.NO.POS = Y.POS<1,2>


    RETURN
*-------------------------------------------------------------------------
PROCESS:
********

    EB.LOOKUP.ID = 'MEB.HL.INT.ADJ*TXN.TYPE'
    R.EB.LOOKUP = ''
    EB.LOOKUP.ERR = ''
    CALL F.READ(FN.EB.LOOKUP,EB.LOOKUP.ID,R.EB.LOOKUP,F.EB.LOOKUP,EB.LOOKUP.ERR)
    
    TRANSACTION.TYPE = R.NEW(FT.TRANSACTION.TYPE)

    LOCATE TRANSACTION.TYPE IN R.EB.LOOKUP<EB.LU.DATA.VALUE,1> SETTING POS THEN
        ACCOUNT.ID = R.NEW(FT.CREDIT.ACCT.NO)
        R.ACCOUNT = ''
        ACCOUNT.ERR = ''
        CALL F.READ(FN.ACCOUNT,ACCOUNT.ID,R.ACCOUNT,F.ACCOUNT,ACCOUNT.ERR)
        Y.ALT.POS = ''
        AA.ARRANGEMENT.ID = R.ACCOUNT<AC.ARRANGEMENT.ID>
        LOCATE 'CUST.AC.NO' IN R.ACCOUNT<AC.ALT.ACCT.TYPE,1> SETTING Y.ALT.POS THEN
          Y.SRC.ALT.ACCT.ID = R.ACCOUNT<AC.ALT.ACCT.ID,Y.ALT.POS> 
        END
        R.AA.ARRANGEMENT = ''
        AA.ARRANGEMENT.ERR = ''
        CALL F.READ(FN.AA.ARRANGEMENT,AA.ARRANGEMENT.ID,R.AA.ARRANGEMENT,F.AA.ARRANGEMENT,AA.ARRANGEMENT.ERR)
        IF R.AA.ARRANGEMENT<AA.ARR.PRODUCT.GROUP> EQ 'HOME.LOAN' THEN
            BALANCE.TYPE = 'TOTALDUE'
            REQUEST.DATE = TODAY
            ARREARS.AMT = ''
            RETURN.ERR = ''
            CALL AA.GET.ECB.BALANCE.AMOUNT(ACCOUNT.ID,BALANCE.TYPE,REQUEST.DATE,ARREARS.AMT,RETURN.ERR)
            ARREARS.AMT = ABS(ARREARS.AMT)
            IF ARREARS.AMT THEN
                GOSUB POST.FT.OFS
            END
        END
    END
    RETURN
*-------------------------------------------------------------------------
POST.FT.OFS:
************
   
   INT.ADJ.AMT = R.NEW(FT.DEBIT.AMOUNT)
    IF ARREARS.AMT GE INT.ADJ.AMT THEN
        DEBIT.AMOUNT = INT.ADJ.AMT
    END ELSE
        DEBIT.AMOUNT = ARREARS.AMT
    END
    APP.NAME = 'FUNDS.TRANSFER'
    PROCESS = 'PROCESS'
    OFS.VERSION = 'FUNDS.TRANSFER,AA.ACLB.BULK'
    OFS.FUNCTION = 'I'
    GTS.MODE = ''
    NO.OF.AUTH = '0'
    TRANSACTION.ID = ''
    OFS.MESSAGE = ''
    R.APP.RECORD = ''
    R.APP.RECORD<FT.DEBIT.AMOUNT> = DEBIT.AMOUNT
	R.APP.RECORD<FT.CREDIT.ACCT.NO> = ACCOUNT.ID
	R.APP.RECORD<FT.DEBIT.ACCT.NO> = ACCOUNT.ID
        R.APP.RECORD<FT.LOCAL.REF,Y.SRC.ACCT.NO.POS> = Y.SRC.ALT.ACCT.ID
        R.APP.RECORD<FT.LOCAL.REF,Y.DES.ACCT.NO.POS> = Y.SRC.ALT.ACCT.ID
    CALL OFS.BUILD.RECORD(APP.NAME,OFS.FUNCTION,PROCESS,OFS.VERSION,GTS.MODE,NO.OF.AUTH,TRANSACTION.ID,R.APP.RECORD,OFS.MESSAGE)
    OFS.ERROR = ''
    CALL ofs.addLocalRequest(OFS.MESSAGE,'ADD',OFS.ERROR)

    RETURN
END
*-------------------------------------------------------------------------
