    SUBROUTINE MEB.VAL.AA.CHK.FLOATING.MV
*-------------------------------------------------------------------------
* Developed By    : Capgemini India Pvt Ltd
* Program Name    : MEB.VAL.AA.CHK.FLOATING.MV
* Purpose         : Validate the value in the floating index field during ACCOUNTS-UPDATE-BONUSETAOSA activity in BROWSER
*-------------------------------------------------------------------------
* Subroutine Type : S
* Attached To     : AA.PRD.DES.ACTIVITY.API>ACCOUNTS.OSA-20120101
* Attached As     : Activity validate routine
* In Parameter    : -NA-
* Out Parameter   : -NA-
*-------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date:         Reference              Developed By    Change Description
* 23-Oct-18     SPT1-1315              Anand           Initial Draft
*
* UPGCHANGE - Sweta - 20190327 - Replaced $INCLUDE with $INSERT
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_AA.APP.COMMON
    $INSERT I_AA.LOCAL.COMMON
    $INSERT I_AA.ACTION.CONTEXT
    $INSERT I_F.AA.INTEREST
    $INSERT I_GTS.COMMON
    $INSERT I_F.USER
    $INSERT I_F.AA.ACTIVITY
    $INSERT I_F.EB.LOOKUP
    $INSERT I_F.AA.ARRANGEMENT.ACTIVITY
*-------------------------------------------------------------------------

    IF OFS$BROWSER THEN
        IF AA$R.ARRANGEMENT.ACTIVITY<AA.ARR.ACT.REV.MASTER.AAA> NE '' OR AA$R.ARRANGEMENT.ACTIVITY<AA.ARR.ACT.SIM.RUN.REF> NE '' THEN
            RETURN
        END
        IF c_arrActivityStatus NE 'UNAUTH' THEN
            RETURN
        END
        AA.ARRANGEMENT.ACTIVITY.ID = c_arrActivityId
        R.AA.ARRANGEMENT.ACTIVITY = c_arrActivityRec
        REPLAY.MODE = ''

        CALL AA.CHECK.REPLAY.MODE(AA.ARRANGEMENT.ACTIVITY.ID,R.AA.ARRANGEMENT.ACTIVITY,REPLAY.MODE)
        IF REPLAY.MODE THEN
            RETURN  ;* No need to Replay
        END
        OLD.FLOATING.CNT = DCOUNT(R.OLD(AA.INT.FLOATING.INDEX),VM)
        NEW.FLOATING.CNT = DCOUNT(R.NEW(AA.INT.FLOATING.INDEX),VM)
        IF OLD.FLOATING.CNT NE NEW.FLOATING.CNT THEN
            GOSUB OPEN.FILES
            GOSUB PROCESS
        END
    END
    RETURN
*-------------------------------------------------------------------------
OPEN.FILES:
***********

    FN.EB.LOOKUP = 'F.EB.LOOKUP'
    F.EB.LOOKUP = ''
    CALL OPF(FN.EB.LOOKUP,F.EB.LOOKUP)

    FN.USER = 'F.USER'
    F.USER = ''
    CALL OPF(FN.USER,F.USER)

    RETURN
*-------------------------------------------------------------------------
PROCESS:
********
    USER.ID = OPERATOR
    R.USER.REC = ''
    CALL F.READ(FN.USER,USER.ID,R.USER.REC,F.USER,USER.ERR)
    USER.ROLES = CHANGE(R.USER.REC<EB.USE.USER.ROLES>,SM,FM)

    IF USER.ROLES EQ '' THEN
        RETURN
    END

    EB.LOOKUP.ID = 'MEB.ACTIVITY.FLD.DISP*ROLES'
    R.EB.LOOKUP = ''
    EB.LOOKUP.ERR = ''
    CALL F.READ(FN.EB.LOOKUP,EB.LOOKUP.ID,R.EB.LOOKUP,F.EB.LOOKUP,EB.LOOKUP.ERR)
    ENABLE.ROLE.LIST = CHANGE(R.EB.LOOKUP<EB.LU.DATA.VALUE>,VM,FM)
    VALIDATE.FLAG = 1
    LOOP
        REMOVE ROLE.ID FROM USER.ROLES SETTING POS
    WHILE ROLE.ID:POS
        LOCATE ROLE.ID IN ENABLE.ROLE.LIST SETTING USER.POS THEN
            VALIDATE.FLAG = 0
        END
    REPEAT
    IF VALIDATE.FLAG THEN
        AF = AA.INT.FLOATING.INDEX
        ETEXT = 'AA-MEB.NO.MODIFY.MV.FLD'
        CALL STORE.END.ERROR
    END

    RETURN
*-------------------------------------------------------------------------
END
*-------------------------------------------------------------------------





