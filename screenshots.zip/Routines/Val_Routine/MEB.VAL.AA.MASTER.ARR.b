* @ValidationCode : MjotMTU3NTc3MDM3NDpDcDEyNTI6MTU2NjIwODgzNDE3NjptZTgwMTU4MV90c3Q6LTE6LTE6MDowOmZhbHNlOk4vQTpSMThfU1AxMy4wOi0xOi0x
* @ValidationInfo : Timestamp         : 19 Aug 2019 20:00:34
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : me801581_tst
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R18_SP13.0
SUBROUTINE MEB.VAL.AA.MASTER.ARR
*-------------------------------------------------------------------------
* Developed By    : Sweta Singh
* Purpose         : JIRA Ref:
*                   To default Loan id given for HOME.LOAN group to MASTER.ARRANGEMENT.1
*------------------------------------------------------------------------
* Subroutine Type : Pre Validation Routine.
* Attached to     : AA.PRD.DES.ACTIVITY.API>BUNDLE
*
* Attached as     : Validation Routine
* In Parameter    : -NA-
* Out Parameter   : -NA-
*
*-------------------------------------------------------------------------
* Modification History :
*-----------------------
* UPGCHANGE - <developer> - <date> - <change description>
*------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.AA.PRODUCT.BUNDLE
    !
    GOSUB INITALISE
    GOSUB PROCESS
    !
RETURN
*-------------------------------------------------------------------------
INITALISE:
*-------------------------------------------------------------------------
    Y.ARR.ID = ''
    Y.POS = ''
RETURN
*-------------------------------------------------------------------------
PROCESS:
*-------------------------------------------------------------------------
    LOCATE 'HOME.LOAN' IN R.NEW(AA.BUN.PRODUCT.GROUP)<1,1> SETTING Y.POS THEN
        Y.ARR.ID = R.NEW(AA.BUN.ARRANGEMENT)<1,Y.POS,1>
        R.NEW(AA.BUN.MASTER.ARRANGEMENT)<1,1> = Y.ARR.ID
    END
    
    
    
RETURN
*-------------------------------------------------------------------------
END