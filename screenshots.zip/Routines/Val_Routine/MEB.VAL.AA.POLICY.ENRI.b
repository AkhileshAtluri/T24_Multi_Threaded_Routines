*-----------------------------------------------------------------------------
    SUBROUTINE MEB.VAL.AA.POLICY.ENRI
*-------------------------------------------------------------------------
* Developed By    : Capgemini India Technologies Pvt. Ltd.
* Program Name    : MEB.VAL.AA.POLICY.ENR
* Purpose         :
*-------------------------------------------------------------------------
* Subroutine Type : S
* Attached To     : -NA-
* Attached As     : Validation routine
* In Parameter    : -NA-
* Out Parameter   : -NA-
*-------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------
* Date:         Reference              Developed By:
*-------------------------------------------------------------------------
* 20-July-2017                           Soumya P
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.ACCOUNT
    $INSERT I_F.AA.ACCOUNT
    $INSERT I_GTS.COMMON
    $INSERT I_F.EB.LOOKUP
    $INSERT I_F.AUMB.POLICY.DETAILS

    GOSUB INITIALISE
    GOSUB PROCESS

    RETURN
*-------------------------------------------------------------------------
INITIALISE:
*-------------------------------------------------------------------------

    Y.APP='AA.PRD.DES.ACCOUNT'
    Y.FIELD='POLICY.ID':VM:'FROM.LEG.ENT'
    Y.POS = ''

    CALL MULTI.GET.LOC.REF(Y.APP,Y.FIELD,Y.POS)
    Y.POLICY.POS = Y.POS<1,1>
    ARR.NAME = Y.POS<1,2>

    FN.AA.ARR.ACCOUNT = "F.AA.ARR.ACCOUNT"
    F.AA.ARR.ACCOUNT = ""
    CALL OPF(FN.AA.ARR.ACCOUNT,F.AA.ARR.ACCOUNT)

    FN.AUMB.POLICY.DETAILS = 'F.AUMB.POLICY.DETAILS'
    F.AUMB.POLICY.DETAILS = ''
    CALL OPF(FN.AUMB.POLICY.DETAILS,F.AUMB.POLICY.DETAILS)

    FN.EB.LOOKUP = 'F.EB.LOOKUP'
    F.EB.LOOKUP = ''
    CALL OPF(FN.EB.LOOKUP,F.EB.LOOKUP)

    RETURN

*--------------------------------------------------------------------------
PROCESS:
*--------------------------------------------------------------------------

    Y.CNT = ''
    Y.POLICY.LIST = R.NEW(AA.AC.LOCAL.REF)<1,Y.POLICY.POS>

    CHANGE SM TO VM IN Y.POLICY.LIST

    LOOP
        REMOVE Y.POLICY.ID FROM Y.POLICY.LIST SETTING Y.POL.POS
    WHILE Y.POLICY.ID:Y.POL.POS

        CALL F.READ(FN.AUMB.POLICY.DETAILS,Y.POLICY.ID,R.POLICY.DETAILS,F.AUMB.POLICY.DETAILS,ERR.DETAILS)

        Y.CNT ++

        Y.LMI.STAT = R.POLICY.DETAILS<AUMB.POL.DET.INSURANCE.STATUS>
        Y.LMI.ID = "INSURANCE.STATUS*":Y.LMI.STAT
        CALL F.READ(FN.EB.LOOKUP,Y.LMI.ID,R.LMI.STATUS,F.EB.LOOKUP,LMI.ERROR)

        Y.LMI.STATUS = R.LMI.STATUS<EB.LU.DESCRIPTION>

        Y.LMI.INSURER.NAME = R.POLICY.DETAILS<AUMB.POL.DET.INSURER.NAME>

        Y.ENRI = Y.LMI.STATUS:" - ":Y.LMI.INSURER.NAME
        COMI.ENRI = ''
        OFS$ENRI<AA.AC.LOCAL.REF,Y.POLICY.POS,Y.CNT> = Y.ENRI

        COMI.ENRI = Y.ENRI

    REPEAT
    RETURN
END

*--------------------END OF ROUTINE---------------------------------------

