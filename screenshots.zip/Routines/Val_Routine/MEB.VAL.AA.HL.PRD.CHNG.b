*-----------------------------------------------------------------------------
* <Rating>-23</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE MEB.VAL.AA.HL.PRD.CHNG
*-----------------------------------------------------------------------------
* Developed By : Capgemini pvt ltd
* Jira Ref	   : DD-776
* Purpose      : Restrict product change for Ultimate HL product switch
* Date         : 12/05/2021
* Attached to  : ACTIVITY.API condition for HL.FLEX and HL.FLEX.ULTRACS product.
* Attached as  : Validation Routine for  activity api listed in the ACCOUNT conditions.
*--------------------------------------------------------------------------------------------
* Modification History
*------------------------------------------------------------------------------------------------
* Modified By :
*---------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_AA.APP.COMMON
    $INSERT I_AA.LOCAL.COMMON
	$INSERT I_AA.ACTION.CONTEXT
    $INSERT I_F.AA.ARRANGEMENT.ACTIVITY
	$INSERT I_F.AA.ARRANGEMENT
	$INSERT I_F.EB.LOOKUP
	$INSERT I_F.AA.ACCOUNT

*    IF c_arrActivityStatus EQ 'AUTH' THEN
		GOSUB INIT
		GOSUB PROCESS
* 	 END

    RETURN
*-----------------------------------------------------------------------------
INIT:
*-----------------------------------------------------------------------------
    FN.AA.ARRANGEMENT = 'F.AA.ARRANGEMENT'
    F.AA.ARRANGEMENT = ''
    CALL OPF(FN.AA.ARRANGEMENT,F.AA.ARRANGEMENT)
	
	FN.EB.LOOKUP = 'F.EB.LOOKUP'
    F.EB.LOOKUP = ''
    CALL OPF(FN.EB.LOOKUP,F.EB.LOOKUP)
	
	Y.APPL = 'AA.ARR.ACCOUNT'
	Y.APPL.FLDS = 'MEB.UOTA'
	CALL MULTI.GET.LOC.REF(Y.APPL,Y.APPL.FLDS,APP.LREF.POS)
	
		
    RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-----------------------------------------------------------------------------

    CURR.ACTIVITY  = c_aalocActivityId
    ARRANGEMENT.ID = c_aalocArrId
    AA.ARR.ACT.ID  = c_aalocArrActivityId
    EFFECTIVE.DATE = c_aalocActivityEffDate
	R.ARR.REC = ''
    CALL F.READ(FN.AA.ARRANGEMENT,ARRANGEMENT.ID,R.ARR.REC,F.AA.ARRANGEMENT, Y.ERR)
	Y.PRODUCT.ID = R.ARR.REC<AA.ARR.PRODUCT>
	Y.PRODUCT.ID = Y.PRODUCT.ID<1,2>

	Y.EB.LOOKUP.ID = 'MEB.UOA.PRD*ALLOW.PRD.CHG'
	CALL F.READ(FN.EB.LOOKUP,Y.EB.LOOKUP.ID,R.EB.LOOKUP,F.EB.LOOKUP, Y.EB.ERR)
	Y.PRD.ID = R.EB.LOOKUP<EB.LU.DATA.NAME>

	Y.MEB.UOTA.POS = APP.LREF.POS<1,1>
	Y.UOA.FLAG = R.NEW(AA.AC.LOCAL.REF)<1,Y.MEB.UOTA.POS>
	Y.PRD.CHNG = AA$R.ARRANGEMENT.ACTIVITY<AA.ARR.ACT.PRODUCT>
	
	IF UPCASE(Y.UOA.FLAG)= 'YES' THEN
		LOCATE Y.PRODUCT.ID IN Y.PRD.ID<1,1> SETTING Y.ID.POS THEN
			Y.ALLOW.PRD.ID = R.EB.LOOKUP<EB.LU.DATA.VALUE,Y.ID.POS>
		END
		IF Y.PRD.CHNG NE Y.ALLOW.PRD.ID THEN
			GOSUB RAISE.ERR.MSG
		END
	END

    RETURN
*-------------------------------------------------------------
RAISE.ERR.MSG:
    AF = AA.AC.LOCAL.REF
    AV = Y.MEB.UOTA.POS
    ETEXT = 'AA-MEB.UOA.PRD.CHG.VAL'
    CALL STORE.END.ERROR
    RETURN

*-------------------------------------------------------------------------------------------
END

