*-----------------------------------------------------------------------------
* <Rating>-61</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE MEB.VAL.AA.FEEWAIVER.CHECK
*-----------------------------------------------------------------------------
* Developed By    : SUDISH RAMAKRISHNAN-Capgemini
* Program Name    : MEB.VAL.AA.FEEWAIVER.CHECK
* Purpose         : To validate FEEWAIVER.START and FEEWAIVER.END fields of AA.ARR.ACCOUNT
*-----------------------------------------------------------------------------
* Subroutine Type : S
* Attached To     : LENDING-UPDATE-FEEWAIVER activity
* Attached As     : VALIDATION Routine
* In Parameter    : -NA-
* Out Parameter   : -NA-
*-------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date:         Reference              Developed By: SUDISH RAMAKRISHNAN-Capgemini
*-------------------------------------------------------------------------
* 16/06/2021    UPGCHANGE        Manavi      - Removed DEBUG line
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.AA.ACCOUNT
    $INSERT I_AA.APP.COMMON
    $INSERT I_AA.ACTION.CONTEXT
    $INSERT I_AA.LOCAL.COMMON
    $INSERT I_F.AA.ARRANGEMENT.ACTIVITY
    $INSERT I_AA.RR.CONTROL
    $INSERT I_F.AUMB.GENERIC.PARAM

    GOSUB CHK.IF.RR
    IF EXIT.FLAG THEN RETURN

    GOSUB CHK.IF.BDATED
    IF NOT(ACT.BDATED) THEN
        GOSUB INITIALISE
        GOSUB READ.MAX.SUSP.PERIOD
        GOSUB CHECK.FEEWAIVER
    END

    RETURN
*-----------------------------------------------------------------------------
CHK.IF.RR:
*-----------------------------------------------------------------------------

    EXIT.FLAG = ''
    ARR.ACTIVITY.ID = c_arrActivityId   ;* Arrangement Activity Id
    R.ACTIVITY = c_arrActivityRec       ;* Arrangement Activity record

    REPLAY.MODE = ''
    CALL AA.CHECK.REPLAY.MODE(ARR.ACTIVITY.ID, R.ACTIVITY, REPLAY.MODE)
    IF REPLAY.MODE THEN
        EXIT.FLAG = 1         ;* No need to Replay
    END

    RETURN
*-----------------------------------------------------------------------------
CHK.IF.BDATED:
*-----------------------------------------------------------------------------
    ACT.BDATED = ''
    Y.EFF.DATE = AA$ACTIVITY.EFF.DATE

    BEGIN CASE
    CASE Y.EFF.DATE LT TODAY
        ETEXT = 'EB-MEB.ACT.EFF.DTE.CANT.BE.BKD'
        CALL STORE.END.ERROR
        ACT.BDATED = 'Y'

    CASE Y.EFF.DATE GT TODAY
*** Fee Waiver effective date can't be future dated
        ETEXT = 'EB-MEB.ACT.EFF.DATE.CANT.BE.FUT.DTE'
        CALL STORE.END.ERROR
        ACT.BDATED = 'Y'

*    CASE c_aalocActivityStatus EQ 'REVERSE'
*        ETEXT = 'EB-MEB.FEEWAIVER.ACT.CANT.BE.REV'
*        CALL STORE.END.ERROR
*  ACT.BDATED = 'Y'
    END CASE

    RETURN
*-----------------------------------------------------------------------------
INITIALISE:
*-----------------------------------------------------------------------------
    AUMB.GEN.PARAM.ID = 'HL.ARREAR.FEE' ; ERR.GEN.PARAM = '' ; MAX.SUSP.MTH.POS = '' ; GEN.PARAM.TYPE = 'MAX.SUSP.MONTHS'

    Y.APP = 'AA.PRD.DES.ACCOUNT'
    Y.FLD = 'FEEWAIVER.START':VM:'FEEWAIVER.END'
    Y.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP,Y.FLD,Y.POS)

    FEEWAIVER.START.POS = Y.POS<1,1>
    FEEWAIVER.END.POS   = Y.POS<1,2>

    FN.AUMB.GENERIC.PARAM = 'F.AUMB.GENERIC.PARAM'
    F.AUMB.GENERIC.PARAM = ''
    CALL OPF(FN.AUMB.GENERIC.PARAM,F.AUMB.GENERIC.PARAM)

    RETURN
*-----------------------------------------------------------------------------
READ.MAX.SUSP.PERIOD:
*-----------------------------------------------------------------------------
    CALL F.READ(FN.AUMB.GENERIC.PARAM,AUMB.GEN.PARAM.ID,R.GENERIC.PARAM,F.AUMB.GENERIC.PARAM,ERR.GEN.PARAM)

    LOCATE GEN.PARAM.TYPE IN R.GENERIC.PARAM<GEN.PARM.PARAM.NAME,1> SETTING MAX.SUSP.MTH.POS THEN
        Y.WAIVER.MAX.SUSP.MTH = R.GENERIC.PARAM<GEN.PARM.PARAM.VALUE,MAX.SUSP.MTH.POS>
    END

    RETURN
*-----------------------------------------------------------------------------
GET.FUT.MAX.DATE:
*-----------------------------------------------------------------------------
    IF FEEWAIVER.START AND FEEWAIVER.END THEN
        FUT.DTE.FREQ = 'e0Y':' ':'e':Y.WAIVER.MAX.SUSP.MTH:' ':'e0W e0D e0F'
        COMI = FEEWAIVER.START:FUT.DTE.FREQ

        CALL CFQ
        FUT.DTE.MAX.SUSP = COMI[1,8]
    END

    RETURN
*-----------------------------------------------------------------------------
GET.FEEWAIVER.PERIOD:
*-----------------------------------------------------------------------------
*** Current Fee Waiver Period
    FEEWAIVER.START = R.NEW(AA.AC.LOCAL.REF)<1,FEEWAIVER.START.POS>
    FEEWAIVER.END = R.NEW(AA.AC.LOCAL.REF)<1,FEEWAIVER.END.POS>

*** Previous Fee Waiver Period
    FEEWAIVER.START.OLD = R.OLD(AA.AC.LOCAL.REF)<1,FEEWAIVER.START.POS>
    FEEWAIVER.END.OLD = R.OLD(AA.AC.LOCAL.REF)<1,FEEWAIVER.END.POS>

    RETURN
*-----------------------------------------------------------------------------
CHECK.FEEWAIVER:
*-----------------------------------------------------------------------------
    GOSUB GET.FEEWAIVER.PERIOD

    IF NOT(FEEWAIVER.START) AND NOT(FEEWAIVER.END) THEN
        RETURN      ;*** End the Suspension Period by blanking out both fields
    END

    GOSUB GET.FUT.MAX.DATE
    GOSUB VALIDATE.FEEWAIVER.PRD

    RETURN
*-----------------------------------------------------------------------------
CHK.WITH.OLD.PERIOD:
*-----------------------------------------------------------------------------
    ERROR.FLAG = ''

    BEGIN CASE
    CASE (AA$ACTIVITY.EFF.DATE GE FEEWAIVER.START.OLD) AND (AA$ACTIVITY.EFF.DATE LE FEEWAIVER.END.OLD)
*** If the current date is within the period then we can change only the End Date
        IF FEEWAIVER.START AND (FEEWAIVER.START NE FEEWAIVER.START.OLD) THEN
*** If the fee waiver period is active then the Start date should NOT be modified
            ETEXT = 'EB-MEB.FEEWAIVER.CANT.CHG.ST.DATE'
            AF = AA.AC.LOCAL.REF
            AV = FEEWAIVER.START.POS
            CALL STORE.END.ERROR

            ERROR.FLAG = 'Y'
        END

    CASE AA$ACTIVITY.EFF.DATE GE FEEWAIVER.END.OLD
        IF FEEWAIVER.START AND FEEWAIVER.END THEN
            IF (FEEWAIVER.START LE AA$ACTIVITY.EFF.DATE) THEN
                ETEXT = 'EB-MEB.FEEWAIVER.CANT.BDATE.ST.DT'
                AF = AA.AC.LOCAL.REF
                AV = FEEWAIVER.START.POS
                CALL STORE.END.ERROR

                ERROR.FLAG = 'Y'
            END
        END
    END CASE

    RETURN
*-----------------------------------------------------------------------------
VALIDATE.FEEWAIVER.PRD:
*-----------------------------------------------------------------------------
    IF FEEWAIVER.START.OLD AND FEEWAIVER.END.OLD THEN
        GOSUB CHK.WITH.OLD.PERIOD
    END

    IF ERROR.FLAG THEN
        RETURN
    END

    BEGIN CASE
    CASE FEEWAIVER.START EQ '' AND FEEWAIVER.END
        ETEXT = 'EB-MEB.FEE.START.END.DTE.NULL'
        AF = AA.AC.LOCAL.REF
        AV = FEEWAIVER.START.POS
        CALL STORE.END.ERROR

    CASE FEEWAIVER.END EQ '' AND FEEWAIVER.START
        ETEXT = 'EB-MEB.FEE.START.END.DTE.NULL'
        AF = AA.AC.LOCAL.REF
        AV = FEEWAIVER.END.POS
        CALL STORE.END.ERROR

    CASE NOT(FEEWAIVER.START.OLD) AND (FEEWAIVER.START LE TODAY)
*** if this is a New Input with NO previous Fee Waiver config then start date can't be
*** less than or equal to Today's date
        ETEXT = 'EB-MEB.FEEWAIVER.CANT.BDATE.ST.DT'
        AF = AA.AC.LOCAL.REF
        AV = FEEWAIVER.START.POS
        CALL STORE.END.ERROR

    CASE FEEWAIVER.END LE FEEWAIVER.START
*** Fee Waiver End Date can't be less than or equal to Start Date
        ETEXT = 'EB-MEB.FEEWAIVER.END.DT.GT.START'
        AF = AA.AC.LOCAL.REF
        AV = FEEWAIVER.END.POS
        CALL STORE.END.ERROR

    CASE FEEWAIVER.END GT FUT.DTE.MAX.SUSP
*** Fee Waiver period can't be more than the configured Max Period
        ETEXT = 'EB-MEB.WAIVE.PERIOD.EXCEEDS.MAX'
        AF = AA.AC.LOCAL.REF
        AV = FEEWAIVER.END.POS
        CALL STORE.END.ERROR

    END CASE

    RETURN
END

