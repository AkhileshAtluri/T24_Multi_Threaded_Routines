* @ValidationCode : MjotMTg1OTc4NjMwOkNwMTI1MjoxNTU0NzExMTc5Mzk5Om1lODAwNTg4X3RzdDotMTotMTowOjA6ZmFsc2U6Ti9BOlIxOF9TUDIuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 08 Apr 2019 18:12:59
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : me800588_tst
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R18_SP2.0
*-----------------------------------------------------------------------------
* <Rating>111</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE E.MEB.NOF.GET.LN.PAY(FINAL.ARRAY)
*-------------------------------------------------------------------------
* Developed By    : Techmill technologies
* Purpose         : Nofile enquiry to get the Loan Repayment Details
*
*
*------------------------------------------------------------------------
* Subroutine Type : NOFILE routine
* Attached to     : STANDARD.SELECTION>NOFILE.MEB.NOF.GET.LN.PAY
* Attached as     : NA
* In Parameter    : D.FIELDS
* Out Parameter   : FINAL.ARRAY
*
*-------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date:       Reference                Developed By        Reason
* 3-Jul-2014  IDD-Loan Payment         Vijaya baskar A.R   Initial
*
* 22-JUL-2014 IDD-Loan Payment V2.0                       Added Next expected repayment amount
*
* 31-OCT-2014 IDD-Loan Payment V4.0                       Changed the mapping for "Next Repayment Date"
*             (Ref-20141031)
* 13-NOV-2018 STP3-1654                Rashmitha M        Date range for schedule projector is changed
*                                                         to exclude today's payment details and get next payment date
* 08-Feb-2019 SPT3-1546                 Priyanka          Modified to calculate the date based on the frequency to 2 cycles
*                                                         and pass TODAY+1C:calculated date in the schedule proector.

* UPGCHANGE - T Sidharth - 20190408 -replaced the MEB.COMMON.PARM to AUMB.COMMON.PARAM
* UPGCHANGE  - Shakila - 20190730 - A new output argument(DUE.DEFER.DATES) is added in AA.SCHEDULE.PROJECTOR API.
* 05-Mar-2020 PL2-4581                 Prashen A          If the product group is personal loan then interest property is 'PERSONALLOANINT'
*
*------------------------------------------------------------------------


    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.AA.ACCOUNT
    $INSERT I_F.ACCOUNT
    $INSERT I_F.AA.SETTLEMENT
    $INSERT I_F.AA.PAYMENT.SCHEDULE
    $INSERT I_F.AA.INTEREST
    $INSERT I_F.EB.CONTRACT.BALANCES
    $INSERT I_F.AA.ACCOUNT.DETAILS
     $INSERT I_F.AA.ARRANGEMENT         ;*PL2-4581 -S/E
    $INSERT I_F.AUMB.COMMON.PARAM
*
    GOSUB INIT.OPEN
    GOSUB MAIN.PROCESS
*
RETURN
*-------------------------------------------------------------------------
MAIN.PROCESS:
*-----------
    IF NOT(YCUS.AC.NO) THEN
        RETURN
    END
*
    ! Account BSB
    R.AUMB.COMMON.PARAM = '' ; ERR.COMMON.PARAM = ''
    CALL CACHE.READ('F.AUMB.COMMON.PARAM', ID.COMPANY, R.AUMB.COMMON.PARAM, ERR.COMMON.PARAM)
    YFA.AC.BSB = R.AUMB.COMMON.PARAM<MCP.T24BSB.IDENTI.CODE>
*
    ! Account Name
    R.ACC.ID = '' ; ALT.ERR = ''
    Y.TEMP.ID = YCUS.AC.NO
    CALL F.READ(FN.ALT.ACCT,YCUS.AC.NO,R.ACC.ID,F.ALT.ACCT,ALT.ERR)
    IF R.ACC.ID THEN
        YCUS.AC.NO = R.ACC.ID
    END
    R.ACCOUNT = '' ; ERR.ACCOUNT = ''
    CALL F.READ(FN.ACCOUNT, YCUS.AC.NO, R.ACCOUNT, F.ACCOUNT, ERR.ACCOUNT)
    IF NOT(R.ACCOUNT) THEN
        RETURN
    END
    YFA.AC.NAME = ''
    YFA.AC.NAME = R.ACCOUNT<AC.ACCOUNT.TITLE.1>
    YAA.ID      = R.ACCOUNT<AC.ARRANGEMENT.ID>
*
    Y.ARR.IDS = '' ; R.AA.SETTLEMENT = '' ; ERR.SETTLEMENT = '' ; EFF.DATE = TODAY
    CALL AA.GET.ARRANGEMENT.CONDITIONS(YAA.ID, 'SETTLEMENT', '', EFF.DATE, Y.ARR.IDS, R.AA.SETTLEMENT, ERR.SETTLEMENT)
    R.AA.SETTLEMENT = RAISE(R.AA.SETTLEMENT)

    ! Get Arrangement details
    R.AA.ACCOUNT.DETAILS = '' ; ERR.AA.ACCOUNT.DETAILS = ''
    CALL F.READ(FN.AA.ACCOUNT.DETAILS, YAA.ID, R.AA.ACCOUNT.DETAILS, F.AA.ACCOUNT.DETAILS, ERR.AA.ACCOUNT.DETAILS)

    ! Nominated Amount & Additional Amount
    YFA.NOM.AMT = '' ; YFA.ADD.AMT = ''
    PMT.TYPE.CNT = DCOUNT(R.AA.SETTLEMENT<AA.SET.LOCAL.REF, YPMT.TYPE.POS>, SM)
    YFA.NOM.AMT  = R.AA.SETTLEMENT<AA.SET.LOCAL.REF, YNOM.AMT.POS, 1>
    YFA.ADD.AMT  = R.AA.SETTLEMENT<AA.SET.LOCAL.REF, YADD.AMT.POS, 1>
*
    Y.ARR.IDS = '' ; R.AA.PAYMENT.SCHEDULE = '' ; ERR.PAYMENT.SCHEDULE = ''
    CALL AA.GET.ARRANGEMENT.CONDITIONS(YAA.ID, 'PAYMENT.SCHEDULE', '', EFF.DATE, Y.ARR.IDS, R.AA.PAYMENT.SCHEDULE, ERR.PAYMENT.SCHEDULE)
    R.AA.PAYMENT.SCHEDULE = RAISE(R.AA.PAYMENT.SCHEDULE)
    PAYMENT.METHOD.CNT    = DCOUNT(R.AA.PAYMENT.SCHEDULE<AA.PS.PAYMENT.METHOD>, VM)
    YFA.BASE.DATE = ''
    YFA.BASE.DATE = R.AA.ACCOUNT.DETAILS<AA.AD.PAYMENT.START.DATE>    ;! Ref-20141031/S/E
    IF PAYMENT.METHOD.CNT EQ 1 THEN
        YFA.PAY.FREQ      = R.AA.PAYMENT.SCHEDULE<AA.PS.PAYMENT.FREQ>
    END ELSE
        ! Dont know, need to check
    END
*
    SIM.REF = '' ; DATE.RNGE = TODAY


    Y.ARR.IDS = '' ; R.AA.PAYMENT.SCHEDULE = '' ; ERR.PAYMENT.SCHEDULE = ''
    CALL AA.GET.ARRANGEMENT.CONDITIONS(YAA.ID, 'PAYMENT.SCHEDULE', '', EFF.DATE, Y.ARR.IDS, R.AA.PAYMENT.SCHEDULE, ERR.PAYMENT.SCHEDULE)
    R.AA.PAYMENT.SCHEDULE = RAISE(R.AA.PAYMENT.SCHEDULE)
    ARR.PAY.TYPE=R.AA.PAYMENT.SCHEDULE<AA.PS.PAYMENT.TYPE>
*    CHANGE VM TO FM IN ARR.PAY.TYPE
*    LOCATE 'CONSTANT' IN ARR.PAY.TYPE SETTING ARR.PAY.POS THEN
*    YFA.SCH.REPAYMENT=R.AA.PAYMENT.SCHEDULE<AA.PS.CALC.AMOUNT>
    CALL MEB.GET.NEXT.PAY.DATE(YAA.ID,YFA.BASE.DATE)
*    END ELSE
*    CALL AA.SCHEDULE.PROJECTOR(YAA.ID, SIM.REF, '', DATE.RNGE, TOT.PAY, Y.DUE.DTE, Y.DUE.TYPE, Y.DUE.MET, Y.DUE.TYP.AMT, DUE.PROP, DUE.PRP.AMT, DUE.OUTS)

*   SPT3 -1546-08-Feb-2019-Start  ; added the logic calculate the date based on frequency upto 2 cycles.
* STP3-1654-20181113-S
*    Y.NEXT.DAY=TODAY
*    CALL CDT('',Y.NEXT.DAY,'+1C')
*    Y.MAT.DATE=R.AA.ACCOUNT.DETAILS<AA.AD.MATURITY.DATE>
*   DATE.RNGE=Y.NEXT.DAY:FM:Y.MAT.DATE
* STP3-1654-20181113-E
    Y.NEXT.DAY = TODAY
    CALL CDT('',Y.NEXT.DAY,'+1C')
    CURR.PYMT.FREQ = R.AA.PAYMENT.SCHEDULE<AA.PS.PAYMENT.FREQ,1>
    FREQ.DATE = TODAY:" ":CURR.PYMT.FREQ
    COMI = FREQ.DATE
    CALL CFQ
    FREQ.CYCLE = COMI
    FREQ.CYCLE.DATE = FREQ.CYCLE[1,8]

    FREQ.DATE.2 = FREQ.CYCLE.DATE:" ":CURR.PYMT.FREQ
    COMI = FREQ.DATE.2
    CALL CFQ
    FREQ.CYCLE.2 = COMI
    FREQ.CYCLE.DATE.2 = FREQ.CYCLE.2[1,8]

    DATE.RNGE = Y.NEXT.DAY:FM:FREQ.CYCLE.DATE.2
*   SPT3 -1546-08-Feb-2019-End

*UPGCHANGE:S 20190730
*    CALL AA.SCHEDULE.PROJECTOR(YAA.ID, SIM.REF, '', DATE.RNGE, TOT.PAY, Y.DUE.DTE, Y.DUE.TYPE, Y.DUE.MET, Y.DUE.TYP.AMT, DUE.PROP, DUE.PRP.AMT, DUE.OUTS)
    DUE.DEFER.DATES = ''
    CALL AA.SCHEDULE.PROJECTOR(YAA.ID, SIM.REF, '', DATE.RNGE, TOT.PAY, Y.DUE.DTE, DUE.DEFER.DATES, Y.DUE.TYPE, Y.DUE.MET, Y.DUE.TYP.AMT, DUE.PROP, DUE.PRP.AMT, DUE.OUTS)
*UPGCHANGE:E 20190730	
    IF Y.DUE.TYPE<1> EQ 'CHARGE' THEN
        YFA.SCH.REPAYMENT = TOT.PAY<2>
        YFA.BASE.DATE     = Y.DUE.DTE<2>
    END ELSE
        YFA.SCH.REPAYMENT = TOT.PAY<1>
        YFA.BASE.DATE     = Y.DUE.DTE<1>
    END

*END
*
    YFA.UNC.TOTAL = '' ; YFA.CURR.TOTAL = ''
    BAL.TYPES = "UNCACCOUNT":FM:"CURACCOUNT"
    NO.OF.REC = DCOUNT(BAL.TYPES, FM)
*
    LOOP
        BAL.TYPE = BAL.TYPES<NO.OF.REC, 1>
    WHILE BAL.TYPE
        CALL AC.GET.ECB.BALANCE(YCUS.AC.NO, BAL.TYPE, SUB.TYPE, BAL.DATE,ECB.BALANCE,ECB.BAL.LCY)
        BEGIN CASE
            CASE BAL.TYPE EQ "UNCACCOUNT"
                YFA.UNC.TOTAL = ECB.BALANCE
            CASE BAL.TYPE EQ "CURACCOUNT"
                YFA.CURR.TOTAL = ECB.BALANCE
        END CASE
        NO.OF.REC -= 1
    REPEAT
*
    R.EB.CONTRACT.BALANCES = '' ; ERR.ECB = '' ; YFA.ACTUAL.BAL = ''
    CALL F.READ(FN.EB.CONTRACT.BALANCES, YCUS.AC.NO, R.EB.CONTRACT.BALANCES, F.EB.CONTRACT.BALANCES, ERR.ECB)
    YFA.ACTUAL.BAL = R.EB.CONTRACT.BALANCES<ECB.WORKING.BALANCE>
*
*PL2-4581 - Start
    Y.ARR.PROPERTY = 'PRINCIPALINT'
    CALL AA.GET.ARRANGEMENT(YAA.ID,R.ARRANGEMENT,ARR.READ.ERR)
    Y.AA.PROD.GRP = R.ARRANGEMENT<AA.ARR.PRODUCT.GROUP>
    IF Y.AA.PROD.GRP EQ "PERSONAL.LOAN" THEN
        Y.ARR.PROPERTY = 'PERSONALLOANINT'
    END
    Y.ARR.IDS = '' ; R.AA.INTEREST = '' ; ERR.INTEREST = ''
    CALL AA.GET.ARRANGEMENT.CONDITIONS(YAA.ID, 'INTEREST', Y.ARR.PROPERTY, '', Y.ARR.IDS, R.AA.INTEREST, ERR.INTEREST)
*PL2-4581 - End
    R.AA.INTEREST = RAISE(R.AA.INTEREST)
    YFA.INT.RATE = '' ; YFA.INT.TYPE = ''
    YFA.INT.RATE = R.AA.INTEREST<AA.INT.EFFECTIVE.RATE>
    BEGIN CASE
        CASE R.AA.INTEREST<AA.INT.FLOATING.INDEX> NE ''
            YFA.INT.TYPE = 'Variable Rate'
        CASE R.AA.INTEREST<AA.INT.PERIODIC.INDEX> NE ''
            YFA.INT.TYPE = 'Fixed Rate'
        CASE R.AA.INTEREST<AA.INT.FIXED.RATE> NE ''
            YFA.INT.TYPE = ''
    END CASE

    YFA.NEXT.REP.AMT=''
    IF YFA.NOM.AMT GT YFA.SCH.REPAYMENT THEN
        YFA.NEXT.REP.AMT=YFA.NOM.AMT
    END ELSE
        IF YFA.ADD.AMT GT 0 THEN
            YFA.NEXT.REP.AMT=YFA.SCH.REPAYMENT+YFA.ADD.AMT
        END ELSE
            YFA.NEXT.REP.AMT=YFA.SCH.REPAYMENT
        END
    END
*
    FINAL.ARRAY = Y.TEMP.ID
    FINAL.ARRAY:= "*" : YFA.AC.BSB
    FINAL.ARRAY:= "*" : YFA.AC.NAME
    FINAL.ARRAY:= "*" : YFA.NOM.AMT
    FINAL.ARRAY:= "*" : YFA.ADD.AMT
    FINAL.ARRAY:= "*" : YFA.SCH.REPAYMENT
    FINAL.ARRAY:= "*" : YFA.BASE.DATE
    FINAL.ARRAY:= "*" : YFA.PAY.FREQ
    FINAL.ARRAY:= "*" : YFA.UNC.TOTAL
    FINAL.ARRAY:= "*" : YFA.ACTUAL.BAL
    FINAL.ARRAY:= "*" : YFA.CURR.TOTAL
    FINAL.ARRAY:= "*" : YFA.INT.RATE
    FINAL.ARRAY:= "*" : YFA.INT.TYPE
    FINAL.ARRAY:= "*" : YFA.NEXT.REP.AMT
*
RETURN
*-------------------------------------------------------------------------
INIT.OPEN:
*--------
    ! Get Customer Account from selection
    YCUS.AC.NO = ''
    LOCATE 'CUS.AC.NO' IN D.FIELDS<1, 1> SETTING AC.POS THEN
        YCUS.AC.NO = D.RANGE.AND.VALUE <1, AC.POS>
    END ELSE
        RETURN
    END
*
    ! Open required files
    FN.ACCOUNT = 'F.ACCOUNT' ; F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT, F.ACCOUNT)
    FN.AA.ACCOUNT = 'F.AA.ACCOUNT' ; F.AA.ACCOUNT = ''
    CALL OPF(FN.AA.ACCOUNT, F.AA.ACCOUNT)
    FN.AA.SETTLEMENT = 'F.AA.ARR.SETTLEMENT' ; F.AA.SETTLEMENT = ''
    CALL OPF(FN.AA.SETTLEMENT, F.AA.SETTLEMENT)
    FN.AA.PAYMENT.SCHEDULE  = 'F.AA.ARR.PAYMENT.SCHEDULE' ; F.AA.PAYMENT.SCHEDULE = ''
    CALL OPF(FN.AA.PAYMENT.SCHEDULE, F.AA.ARR.PAYMENT.SCHEDULE)
    FN.EB.CONTRACT.BALANCES = 'F.EB.CONTRACT.BALANCES' ; F.EB.CONTRACT.BALANCES = ''
    CALL OPF(FN.EB.CONTRACT.BALANCES, F.EB.CONTRACT.BALANCES)
    FN.AA.INTEREST = 'F.AA.ARR.INTEREST' ; F.AA.INTEREST = ''
    CALL OPF(FN.AA.INTEREST, F.AA.INTEREST)
    FN.ALT.ACCT = 'F.ALTERNATE.ACCOUNT'; F.ALT.ACCT  = ''
    CALL OPF(FN.ALT.ACCT,F.ALT.ACCT)
    FN.AA.ACCOUNT.DETAILS = 'F.AA.ACCOUNT.DETAILS' ; F.AA.ACCOUNT.DETAILS = ''
    CALL OPF(FN.AA.ACCOUNT.DETAILS, F.AA.ACCOUNT.DETAILS)
*
    ! Get Local ref fields positions
    YAPP.LST = 'AA.PRD.DES.SETTLEMENT'
    YFLD.LST = 'PMT.TYPE' :VM: 'TRAN.TYPE' :VM: 'NOMINATED.AMT' :VM: 'ADDITIONAL.AMT'
    YFLD.POS = ''
    CALL MULTI.GET.LOC.REF(YAPP.LST, YFLD.LST, YFLD.POS)
    YPMT.TYPE.POS   = YFLD.POS<1, 1>
    YTRAN.TYPE.POS  = YFLD.POS<1, 2>
    YNOM.AMT.POS    = YFLD.POS<1, 3>
    YADD.AMT.POS    = YFLD.POS<1, 4>
*
    ! Intialize variables
    FINAL.ARRAY = ''
    SUB.TYPE = ''
    BAL.DATE =''
*
RETURN
*-------------------------------------------------------------------------
END       ;!!! Final END


 
