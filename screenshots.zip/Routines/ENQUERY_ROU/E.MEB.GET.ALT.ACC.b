* @ValidationCode : Mjo4OTgyNjM1MDQ6Q3AxMjUyOjE1NTQ3MTEwOTQ1MDQ6bWU4MDA1ODhfdHN0Oi0xOi0xOjA6MDpmYWxzZTpOL0E6UjE4X1NQMi4wOi0xOi0x
* @ValidationInfo : Timestamp         : 08 Apr 2019 18:11:34
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : me800588_tst
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R18_SP2.0
*-----------------------------------------------------------------------------
* <Rating>-30</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE E.MEB.GET.ALT.ACC
*-------------------------------------------------------------------------
* Modification History:
*
* UPGCHANGE - T Sidharth - 20190408 -replaced the MEB.COMMON.PARM to AUMB.COMMON.PARAM
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.ACCOUNT
    $INSERT I_F.AUMB.COMMON.PARAM

    GOSUB INIT
    GOSUB OPEN.FILES
    GOSUB PROCESS
RETURN
*-------------------------------------------------------------------------
INIT:
****
    Y.ID.COMPANY = ''
    Y.MEB.ACC = ''
    Y.ALT.ACCT.PARAM = ''
    Y.ALT.TYPE = ''
    Y.ALT.ID = ''

    Y.ACC.ID = O.DATA
RETURN
*-------------------------------------------------------------------------
OPEN.FILES:
***********
    FN.AUMB.COMMON.PARAM = 'F.AUMB.COMMON.PARAM'
    F.AUMB.COMMON.PARAM = ''
    CALL OPF(FN.AUMB.COMMON.PARAM,F.AUMB.COMMON.PARAM)

    FN.ACCOUNT = 'F.ACCOUNT'
    F.ACCOUNT = ''
    CALL OPF(FN.ACCOUNT, F.ACCOUNT)

RETURN
*-------------------------------------------------------------------------
PROCESS:
********
    ERR.ACC = ''
    R.ACCOUNT = ''
    CALL F.READ(FN.ACCOUNT, Y.ACC.ID, R.ACCOUNT, F.ACCOUNT, ERR.ACC)

    IF R.ACCOUNT THEN
        Y.ID.COMPANY = ID.COMPANY
        CALL F.READ(FN.AUMB.COMMON.PARAM,Y.ID.COMPANY,R.AUMB.COMMON.PARAM,F.AUMB.COMMON.PARAM,ERR.MEB.COMMON)
        IF R.AUMB.COMMON.PARAM NE '' THEN
            Y.ALT.ACCT.PARAM =  R.AUMB.COMMON.PARAM<MCP.ALT.ACCT.PARAM>
        END
        Y.ALT.TYPE = R.ACCOUNT<AC.ALT.ACCT.TYPE >
        Y.ALT.ID = R.ACCOUNT<AC.ALT.ACCT.ID>
        LOCATE Y.ALT.ACCT.PARAM IN Y.ALT.TYPE<1,1> SETTING ALT.POS THEN
            Y.MEB.ACC = Y.ALT.ID<1,ALT.POS>
        END
    END

    IF Y.MEB.ACC THEN
        O.DATA = Y.MEB.ACC
    END
RETURN
*-------------------------------------------------------------------------
END