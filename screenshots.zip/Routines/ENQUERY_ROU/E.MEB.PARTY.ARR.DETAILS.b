*-----------------------------------------------------------------------------
* <Rating>-31</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE E.MEB.PARTY.ARR.DETAILS(FIN.ARRAY)
*-----------------------------------------------------------------------------
* ------------------------------------------------------------------------
* Generic Comments    :-
*------------------------------------------------------------------------
* Company Name        : M E B
* Developer Name      : Abhishek/Nindya
* Subroutine Type     : H
* Attached as         : Nofile Enquiry Routine
* Attached to         : STANDARAD.SELECTION
* Primary Purpose     : To fetch the details from Customer, AA.ARR.CUSTOMER & EB.RELATIONSHIP.DEF tables
* Incoming Parameters : NA
* Outgoing Parameters : FIN.ARRAY
* Development date    : 10 FEB 2014
*-------------------------------------------------------------------------
* Modification History:-
*-------------------------------------------------------------------------
* Date                : 22/06/2020
* Modified by         : Sweta
* Reference           : T24UP-8316
* Description         : TRIM function is fixed
*-------------------------------------------------------------------------
* ----------------------------------------------------------------------------
* <region name= Inserts>
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_System
    $INSERT I_F.CUSTOMER
    $INSERT I_F.AA.CUSTOMER
    $INSERT I_AA.APP.COMMON
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.EB.RELATIONSHIP.DEF
* </region>
*-----------------------------------------------------------------------------

    GOSUB INITIALISE
    GOSUB PROCESS
    GOSUB READ.APP
*-------------------------------------------------------------------------
    RETURN
*-----------------------------------------------------------------------------
INITIALISE:
*-----------------------------------------------------------------------------
    Y.ARRAY = ''
    Y.ARR.ID = ''

    Y.ARR.ID = ENQ.SELECTION<4,1>
    Y.FLD.NAME = 'NAME.TITLE':FM:'RELATION.TYPE':VM:'RELATED.PARTY'
    Y.APPLICATION = 'CUSTOMER':FM:'AA.PRD.DES.CUSTOMER'
    Y.FLD.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APPLICATION,Y.FLD.NAME,Y.FLD.POS)
    Y.NAME.TITLE.POS = Y.FLD.POS<1,1>
    Y.RELATION.TYPE.POS = Y.FLD.POS<2,1>
    Y.RELATED.TO.PRTY.POS = Y.FLD.POS<2,2>

    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ''
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)

    FN.AA.CUSTOMER = 'F.AA.ARR.CUSTOMER'
    F.AA.CUSTOMER = ''
    CALL OPF(FN.AA.CUSTOMER,F.AA.CUSTOMER)

    FN.EB.RELATIONSHIP.DEF = 'F.EB.RELATIONSHIP.DEF'
    F.EB.RELATIONSHIP.DEF = ''
    CALL OPF(FN.EB.RELATIONSHIP.DEF,F.EB.RELATIONSHIP.DEF)
*-------------------------------------------------------------------------
    RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-----------------------------------------------------------------------------
    Y.RELATION.TYPE = ''
    Y.RELATED.PARTY = ''

    PROPERTY.RECORD = ''
    PROPERTY.CLASS = 'CUSTOMER'

    CALL AA.GET.ARRANGEMENT.CONDITIONS(Y.ARR.ID,PROPERTY.CLASS,'','',PR.IDS,PROPERTY.RECORD,ERR.COND)
    PROPERTY.RECORD = RAISE(PROPERTY.RECORD)

    IF PROPERTY.RECORD NE '' THEN
        Y.RELATION.TYPE= PROPERTY.RECORD<AA.CUS.LOCAL.REF,Y.RELATION.TYPE.POS>
        CHANGE SM TO FM IN Y.RELATION.TYPE
        Y.RELATED.PARTY = PROPERTY.RECORD<AA.CUS.LOCAL.REF,Y.RELATED.TO.PRTY.POS>
    END

    Y.REL.CNT = DCOUNT(Y.RELATION.TYPE,FM)
    Y.REL.PRTY.CNT = DCOUNT(Y.RELATED.PARTY,SM)
    Y.CNT = 1
    LOOP
    WHILE Y.CNT LE Y.REL.CNT
        Y.RELATION.TYPE = PROPERTY.RECORD<AA.CUS.LOCAL.REF,Y.RELATION.TYPE.POS,Y.CNT>
        Y.RELATED.PARTY = PROPERTY.RECORD<AA.CUS.LOCAL.REF,Y.RELATED.TO.PRTY.POS,Y.CNT>
        IF Y.RELATION.TYPE[1,3] EQ 'PTA' THEN
            GOSUB READ.APP
        END
        Y.CNT += 1
    REPEAT

*T24UP-8316(S)
*FIN.ARRAY<-1> = TRIM(Y.ARRAY,FM,L)
	FIN.ARRAY<-1> = TRIM(Y.ARRAY,FM,"L")
*T24UP-8316(E)
*-------------------------------------------------------------------------
    RETURN
*-------------------------------------------------------------------------
READ.APP:
*-------------------------------------------------------------------------

    Y.NAME.TITLE = ''
    Y.NAME = ''

    CALL F.READ(FN.CUSTOMER,Y.RELATED.PARTY,R.CUSTOMER,F.CUSTOMER,ERR.CUSTOMER)
    IF R.CUSTOMER THEN
        Y.NAME.TITLE = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.NAME.TITLE.POS>
        Y.NAME = R.CUSTOMER<EB.CUS.NAME.1>
    END
*
    CALL F.READ(FN.EB.RELATIONSHIP.DEF,Y.RELATION.TYPE,R.EB.RELATIONSHIP.DEF,F.EB.RELATIONSHIP.DEF,ERR.EB.RELATIONSHIP.DEF)
    IF R.EB.RELATIONSHIP.DEF THEN
        Y.RELATION.NAME = R.EB.RELATIONSHIP.DEF<EB.REL92.REL.NAME>
        Y.SORT = R.EB.RELATIONSHIP.DEF<EB.REL92.SORT>

        Y.ARRAY<-1> = Y.SORT:"*":Y.NAME.TITLE:"*":Y.NAME:"*":Y.RELATION.NAME:"*":Y.RELATED.PARTY
        Y.ARRAY = SORT(Y.ARRAY)

*        Y.ARRAY<Y.SORT> = Y.NAME.TITLE:"*":Y.NAME:"*":Y.RELATION.NAME:"*":Y.RELATED.PARTY
    END
*
    RETURN

*-------------------------------------------------------------------------
    RETURN
*-------------------------------------------------------------------------
END





 
