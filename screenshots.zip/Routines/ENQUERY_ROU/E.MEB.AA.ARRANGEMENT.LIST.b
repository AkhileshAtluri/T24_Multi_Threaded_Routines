*-----------------------------------------------------------------------------
* <Rating>-68</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE E.MEB.AA.ARRANGEMENT.LIST(ENQ.DATA)
*-------------------------------------------------------------------------
* Developed By    : Techmill technologies
* Purpose         : The routine will build the selection criteria of AA.ARRANGEMENT
*                   provided in fields RELATED.TO.ACC
*                   of EB.RELATIONSHIP.DEF for PARTY.ID.
*------------------------------------------------------------------------
* Subroutine Type : ENQUIRY
* Attached to     : ENQUIRY>MEB.AA.ARRANGEMENT.LIST
* Attached as     : BUILD routine
* In Parameter    : -NA-
* Out Parameter   : ENQ.DATA
*
*-------------------------------------------------------------------------
* Modification History :
*-----------------------
* Date:         Reference              Developed By:
* 18-jul-2013   Sales Management 001_TSD_20130613
*
* 22-May-2014   Performance changes    ssenthamil@temenos.com
*
*-------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.CUSTOMER
    $INSERT I_F.EB.RELATIONSHIP.DEF
    $INSERT I_F.EB.RELATION.DETS

*** </region>
*------------------------------------------------------------------------------------------------------------------
*** <region name= MAIN PROCESS LOGIC>
*** <desc> </desc>

    GOSUB INITIALIZE
    GOSUB PROCESS

    RETURN
*** </region>
*------------------------------------------------------------------------------------------------------------------
*** <region name= INITIALIZE>
*** <desc> </desc>
INITIALIZE:
*
    ENQ.DATA<16> = 'YES'
*
! Performance change - Start
*   FN.EB.RELATIONSHIP.DEF='F.EB.RELATIONSHIP.DEF'
*   F.EB.RELATIONSHIP.DEF=''
*   CALL OPF(FN.EB.RELATIONSHIP.DEF,F.EB.RELATIONSHIP.DEF)
! Performance change - End
*
    Y.REL.PRODS = ''
    Y.ID.DEF = R.NEW(EB.REL26.RELATION.TYPE)
*
    RETURN
*** </region>
*------------------------------------------------------------------------------------------------------------------
*** <region name= PROCESS>
*** <desc> </desc>
PROCESS:
*
! Performance change - Start
*
*   CALL F.READ(FN.EB.RELATIONSHIP.DEF,Y.ID.DEF,R.REC.REL,F.EB.RELATIONSHIP.DEF,ERR.CODE)
    R.REC.REL = '' ; ERR.CODE = ''
    CALL CACHE.READ('F.EB.RELATIONSHIP.DEF',Y.ID.DEF,R.REC.REL,ERR.CODE)

    Y.REL.PRODS = R.REC.REL<EB.REL92.REL.TO.PRODS>
    IF Y.REL.PRODS NE '' THEN
        ENQ.DATA<2,1> = 'PRODUCT'
        ENQ.DATA<3,1> = 'EQ'
        ENQ.DATA<4,1> = Y.REL.PRODS
    END ELSE
        IF ENQ.DATA<2> NE '' THEN
            GOSUB process_party_details
        END ELSE
            ENQ.ERROR = "EB-USE.SEL.CRITERIA"
        END
    END

    RETURN
*** </region>
*------------------------------------------------------------------------------------------------------------------
*** <region name= process_party_details>
*** <desc> </desc>
    process_party_details:

    PartyNamePos = ''
    LOCATE "PRODUCT.GROUP" IN ENQ.DATA<2,1> SETTING PartyNamePos THEN
        fnCustomer = "F.CUSTOMER"
        fCustomer = ""
        CALL OPF(fnCustomer,fCustomer)

        PartyIdPos = ''
        LOCATE "CUSTOMER" IN ENQ.DATA<2,1> SETTING PartyIdPos THEN
            GOSUB party_id_process
        END ELSE
            GOSUB party_name_process
        END
    END

    RETURN
*** </region>
*------------------------------------------------------------------------------------------------------------------
*** <region name= party_id_process>
*** <desc> </desc>
    party_id_process:

    IF DCOUNT(ENQ.DATA<4,PartyIdPos>,SPACE(1)) EQ 1 THEN
        rCustomer = '' ; eCustomer = ''
        CALL F.READ(fnCustomer,ENQ.DATA<4,PartyIdPos>,rCustomer,fCustomer,eCustomer)
        FINDSTR ENQ.DATA<4,PartyNamePos> IN rCustomer<EB.CUS.SHORT.NAME,1> SETTING fm,vm THEN
            DEL ENQ.DATA<2,PartyNamePos>
            DEL ENQ.DATA<3,PartyNamePos>
            DEL ENQ.DATA<4,PartyNamePos>
        END ELSE
            ENQ.ERROR = "EB-PARTY.NAME.NOT.MATCH.PARTY.ID"
        END
    END ELSE
        IF PartyNamePos THEN
            ENQ.ERROR = "EB-PARTY.NAME.NOT.ALLOWED"
        END
    END

    RETURN
*** </region>
*------------------------------------------------------------------------------------------------------------------
*** <region name= party_name_process>
*** <desc> </desc>
    party_name_process:

    IF ENQ.DATA<3,PartyNamePos> EQ "EQ" THEN
        selCmmd = "SELECT ":fnCustomer:" WITH SHORT.NAME EQ '":ENQ.DATA<4,PartyNamePos>:"'"
    END ELSE
        IF ENQ.DATA<3,PartyNamePos> EQ "LK" THEN
            selCmmd = "SELECT ":fnCustomer:" WITH SHORT.NAME LIKE '...":ENQ.DATA<4,PartyNamePos>:"...'"
        END
    END

    selList = ""
    CALL EB.READLIST(selCmmd,selList,"","","")
    IF selList THEN
        CHANGE FM TO SPACE(1) IN selList
        ENQ.DATA<2,PartyNamePos> = "CUSTOMER"
        ENQ.DATA<3,PartyNamePos> = "EQ"
        ENQ.DATA<4,PartyNamePos> = selList
    END ELSE
        DEL ENQ.DATA<2,PartyNamePos>
        DEL ENQ.DATA<3,PartyNamePos>
        DEL ENQ.DATA<4,PartyNamePos>
        ENQ.ERROR = "EB-WRONG.PARTY.NAME"
    END
*
! Performance change - End
*
    RETURN
*** </region>
*------------------------------------------------------------------------------------------------------------------
END
